import { supabase } from "@/integrations/supabase/client";

export async function uploadCommunityImage(
  userId: string,
  file: File,
  folder: "posts" | "comments",
): Promise<{ url: string | null; error: string | null }> {
  if (!file.type.startsWith("image/")) return { url: null, error: "Solo se permiten imágenes." };
  if (file.size > 5 * 1024 * 1024) return { url: null, error: "Imagen muy grande (máx 5MB)." };
  const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
  const path = `${userId}/${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from("community-media").upload(path, file, { cacheControl: "3600", upsert: false });
  if (error) return { url: null, error: error.message };
  const { data } = supabase.storage.from("community-media").getPublicUrl(path);
  return { url: data.publicUrl, error: null };
}
