import { Capacitor } from "@capacitor/core";
import { SocialLogin } from "@capgo/capacitor-social-login";
import { supabase } from "@/integrations/supabase/client";

/**
 * Web Client ID de Google Cloud (tipo "Aplicación web", el cliente "CYRA").
 * Se usa también en Android porque el plugin necesita el Web Client ID
 * para generar un idToken válido para Supabase.
 *
 * 👉 Reemplaza este valor con tu Client ID real de Google Cloud.
 */
const GOOGLE_WEB_CLIENT_ID =
  import.meta.env.VITE_GOOGLE_WEB_CLIENT_ID ||
  "847788812238-05lnkc4neas386ckhv9j6qdqc64sgij4.apps.googleusercontent.com";

let initialized = false;

async function ensureInit() {
  if (initialized || !Capacitor.isNativePlatform()) return;
  await SocialLogin.initialize({
    google: {
      webClientId: GOOGLE_WEB_CLIENT_ID,
      mode: "online",
    },
  });
  initialized = true;
}

/**
 * Inicia sesión con Google.
 * - En Web: usa el OAuth tradicional de Supabase (redirect).
 * - En Android/iOS: usa el selector nativo de cuentas y entrega el idToken a Supabase.
 */
export async function googleSignIn(): Promise<{ error: any }> {
  if (!Capacitor.isNativePlatform()) {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/`,
        queryParams: { access_type: "offline", prompt: "select_account" },
      },
    });
    return { error };
  }

  try {
    await ensureInit();
    const res: any = await SocialLogin.login({
      provider: "google",
      options: { scopes: ["email", "profile"] },
    });
    const idToken: string | undefined =
      res?.result?.idToken ?? res?.idToken ?? res?.result?.responseType?.idToken;

    if (!idToken) {
      return { error: new Error("No idToken devuelto por Google") };
    }

    const { error } = await supabase.auth.signInWithIdToken({
      provider: "google",
      token: idToken,
    });
    return { error };
  } catch (err) {
    return { error: err };
  }
}

export async function googleSignOut() {
  if (Capacitor.isNativePlatform()) {
    try {
      await ensureInit();
      await SocialLogin.logout({ provider: "google" });
    } catch {
      /* noop */
    }
  }
}
