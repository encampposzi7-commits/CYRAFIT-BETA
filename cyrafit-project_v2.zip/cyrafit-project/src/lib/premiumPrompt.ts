const STORAGE_KEY = "cyra_premium_prompt_seen";
const COOLDOWN_MS = 30 * 60 * 1000;

type Seen = Record<string, number>;
function readSeen(): Seen {
  try { const raw = sessionStorage.getItem(STORAGE_KEY); return raw ? JSON.parse(raw) : {}; } catch { return {}; }
}
function writeSeen(seen: Seen) {
  try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(seen)); } catch {}
}
export function shouldShowPremiumPrompt(trigger: string, force = false): boolean {
  if (force) return true;
  const seen = readSeen();
  const last = seen[trigger];
  if (!last) return true;
  return Date.now() - last > COOLDOWN_MS;
}
export function markPremiumPromptShown(trigger: string) {
  const seen = readSeen();
  seen[trigger] = Date.now();
  writeSeen(seen);
}
