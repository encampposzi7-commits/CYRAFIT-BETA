export type CyclePhase = 'menstrual' | 'follicular' | 'ovulatory' | 'luteal';
export type CycleMode = 'cycle' | 'postpartum';

export interface PhaseInfo {
  name: string;
  emoji: string;
  color: string;
  bgColor: string;
  days: string;
  description: string;
  symptoms: string[];
  cravings: string[];
  hydrationTip: string;
  microNutrients: string;
  trainingTip: string;
  trainingType: string;
  intensity: string;
  nutritionTip: string;
}

export interface CycleSettings {
  avgCycleLength: number;       // default 28
  avgPeriodLength: number;      // default 5
  mode: CycleMode;
  postpartumStartDate?: Date | null;
  trackPeriodPostpartum?: boolean;
  lastPeriodDate?: Date | null;
}

export const DEFAULT_CYCLE_SETTINGS: CycleSettings = {
  avgCycleLength: 28,
  avgPeriodLength: 5,
  mode: 'cycle',
  postpartumStartDate: null,
  trackPeriodPostpartum: false,
  lastPeriodDate: null,
};

export const PHASES: Record<CyclePhase, PhaseInfo> = {
  menstrual: {
    name: 'Menstrual',
    emoji: '🌙',
    color: 'text-rosa-deep',
    bgColor: 'bg-rosa-light/30',
    days: 'Inicio del ciclo',
    description: 'Tu cuerpo se renueva. Los niveles hormonales están en su punto más bajo: es un momento natural para ir más lento.',
    symptoms: ['Fatiga', 'Calambres', 'Sensibilidad', 'Retención de líquidos'],
    cravings: ['Chocolate', 'Carbohidratos calientes', 'Bebidas dulces'],
    hydrationTip: 'Suma 500 ml extra de agua e infusiones tibias (jengibre, manzanilla).',
    microNutrients: 'Hierro, magnesio, vitamina B6 y omega 3.',
    trainingTip: 'Hoy descansar también es entrenar. Si te apetece moverte, hazlo suave: movilidad, yoga o una caminata corta.',
    trainingType: 'Yoga · Caminata · Movilidad',
    intensity: 'Baja',
    nutritionTip: 'Suma alimentos cálidos con hierro y magnesio. Sé amable con lo que tu cuerpo te pide.',
  },
  follicular: {
    name: 'Folicular',
    emoji: '🌱',
    color: 'text-rosa-deep',
    bgColor: 'bg-secondary',
    days: 'Energía en ascenso',
    description: 'El estrógeno sube poco a poco. Puede que te sientas con más ánimo, creatividad y ganas de probar cosas nuevas.',
    symptoms: ['Energía creciente', 'Mejor ánimo', 'Mayor concentración', 'Menor apetito'],
    cravings: ['Frutas frescas', 'Snacks crujientes'],
    hydrationTip: 'Mantén 2 L de agua para acompañar tu energía.',
    microNutrients: 'Vitamina B12, zinc, proteínas magras.',
    trainingTip: 'Si te animas, sube la intensidad poco a poco. Buen momento para sumar fuerza o probar algo distinto.',
    trainingType: 'Fuerza · HIIT · Cardio moderado',
    intensity: 'Alta',
    nutritionTip: 'Proteína magra y carbohidratos complejos sostienen tu energía sin pesadez.',
  },
  ovulatory: {
    name: 'Ovulatoria',
    emoji: '🔥',
    color: 'text-accent',
    bgColor: 'bg-accent/10',
    days: 'Pico hormonal',
    description: 'Pico de estrógeno y testosterona. Es un momento de fuerza, confianza y conexión.',
    symptoms: ['Energía alta', 'Mayor fuerza', 'Confianza elevada', 'Libido alta'],
    cravings: ['Comidas livianas', 'Frutos rojos'],
    hydrationTip: 'Hidrátate antes, durante y después del entrenamiento.',
    microNutrients: 'Antioxidantes (vitamina C, E), magnesio, proteína de alta calidad.',
    trainingTip: 'Tu cuerpo está fuerte. Si te apetece, retarte con cariño puede sentirse muy bien hoy.',
    trainingType: 'Fuerza · Sprint · Potencia',
    intensity: 'Máxima',
    nutritionTip: 'Proteína de calidad y antioxidantes acompañan tu pico de energía.',
  },
  luteal: {
    name: 'Lútea',
    emoji: '🍂',
    color: 'text-muted-foreground',
    bgColor: 'bg-muted',
    days: 'Recuperación previa',
    description: 'La progesterona toma el mando. Antojos, cambios de ánimo o cansancio son normales: es química, no debilidad.',
    symptoms: ['Antojos', 'Hinchazón', 'Cambios de humor', 'Cansancio gradual'],
    cravings: ['Dulces', 'Salados', 'Chocolate', 'Carbohidratos densos'],
    hydrationTip: 'Reduce sodio y suma agua con limón para sentirte menos hinchada.',
    microNutrients: 'Magnesio, calcio, vitamina B6, triptófano.',
    trainingTip: 'Baja la intensidad sin culpa. Fuerza moderada, pilates o cardio suave cuidan tu cuerpo en esta fase.',
    trainingType: 'Fuerza moderada · Pilates · Cardio suave',
    intensity: 'Moderada',
    nutritionTip: 'Grasas saludables, fibra y comidas cada 3-4 horas ayudan a estabilizar antojos y ánimo.',
  },
};

export const POSTPARTUM_INFO: PhaseInfo = {
  name: 'Post parto',
  emoji: '🤱',
  color: 'text-primary',
  bgColor: 'bg-primary/10',
  days: 'Recuperación',
  description: 'Estás en una etapa de reconstrucción. Vamos paso a paso, con paciencia: respiración, core profundo, suelo pélvico y movilidad para volver con seguridad.',
  symptoms: ['Fatiga acumulada', 'Diástasis posible', 'Suelo pélvico sensible', 'Postura adaptada'],
  cravings: ['Comidas tibias', 'Snacks nutritivos frecuentes'],
  hydrationTip: 'Mínimo 2,5 L al día, sobre todo si estás lactando.',
  microNutrients: 'Hierro, calcio, vitamina D, omega 3, proteína de calidad.',
  trainingTip: 'Vuelve a tu ritmo. Respiración, core profundo, suelo pélvico, caminatas y movilidad son tu mejor base ahora.',
  trainingType: 'Respiración · Core profundo · Suelo pélvico · Caminatas',
  intensity: 'Baja',
  nutritionTip: 'Comidas frecuentes, tibias y nutritivas te sostienen mejor que cualquier restricción.',
};

// ---------- Date helpers ----------
const MS_DAY = 1000 * 60 * 60 * 24;

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function daysBetween(a: Date, b: Date): number {
  return Math.floor((startOfDay(b).getTime() - startOfDay(a).getTime()) / MS_DAY);
}

export function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

// ---------- Cycle calc ----------
export function getCycleDay(lastPeriodDate: Date, avgCycleLength = 28, today = new Date()): number {
  const diff = daysBetween(lastPeriodDate, today);
  const len = Math.max(18, avgCycleLength);
  return ((diff % len) + len) % len + 1;
}

export function getCurrentPhase(
  cycleDay: number,
  avgCycleLength = 28,
  avgPeriodLength = 5,
): CyclePhase {
  if (cycleDay <= avgPeriodLength) return 'menstrual';
  const ovulationDay = avgCycleLength - 14;
  if (cycleDay < ovulationDay - 1) return 'follicular';
  if (cycleDay <= ovulationDay + 1) return 'ovulatory';
  return 'luteal';
}

// Backwards compat helper (defaults 28/5)
export function getCycleDayFromStart(startDate: Date): number {
  return getCycleDay(startDate, 28);
}

export function getPhaseInfo(settings: CycleSettings): PhaseInfo {
  if (settings.mode === 'postpartum' && !settings.trackPeriodPostpartum) {
    return POSTPARTUM_INFO;
  }
  if (!settings.lastPeriodDate) return PHASES.follicular;
  const day = getCycleDay(settings.lastPeriodDate, settings.avgCycleLength);
  const phase = getCurrentPhase(day, settings.avgCycleLength, settings.avgPeriodLength);
  return PHASES[phase];
}

export interface CycleProjection {
  cycleDay: number;
  phase: CyclePhase;
  nextPeriodDate: Date;
  daysUntilNextPeriod: number;
  ovulationDate: Date;
  fertileWindow: { start: Date; end: Date };
}

export function projectCycle(settings: CycleSettings, today = new Date()): CycleProjection | null {
  if (!settings.lastPeriodDate) return null;
  const start = settings.lastPeriodDate;
  const len = settings.avgCycleLength;
  const cycleDay = getCycleDay(start, len, today);
  const phase = getCurrentPhase(cycleDay, len, settings.avgPeriodLength);

  // Walk forward to find the next period start strictly >= today
  let next = new Date(start);
  while (next <= today) next = addDays(next, len);
  const nextPeriodDate = next;
  const daysUntilNextPeriod = daysBetween(today, nextPeriodDate);

  const ovulationDate = addDays(nextPeriodDate, -14);
  const fertileWindow = {
    start: addDays(ovulationDate, -5),
    end: addDays(ovulationDate, 1),
  };

  return { cycleDay, phase, nextPeriodDate, daysUntilNextPeriod, ovulationDate, fertileWindow };
}

export type Regularity = 'unknown' | 'regular' | 'irregular';

export function getRegularity(periodStarts: Date[]): Regularity {
  if (periodStarts.length < 3) return 'unknown';
  const sorted = [...periodStarts].sort((a, b) => a.getTime() - b.getTime());
  const gaps: number[] = [];
  for (let i = 1; i < sorted.length; i++) gaps.push(daysBetween(sorted[i - 1], sorted[i]));
  const max = Math.max(...gaps);
  const min = Math.min(...gaps);
  return max - min <= 5 ? 'regular' : 'irregular';
}

// Weighted moving average over last N period gaps (most recent weighs more)
export function estimateAvgCycleLength(periodStarts: Date[], fallback = 28): number {
  if (periodStarts.length < 2) return fallback;
  const sorted = [...periodStarts].sort((a, b) => a.getTime() - b.getTime());
  const gaps: number[] = [];
  for (let i = 1; i < sorted.length; i++) gaps.push(daysBetween(sorted[i - 1], sorted[i]));
  const recent = gaps.slice(-6);
  let totalW = 0;
  let acc = 0;
  recent.forEach((g, i) => {
    const w = i + 1;
    acc += g * w;
    totalW += w;
  });
  const est = Math.round(acc / totalW);
  if (est < 18 || est > 60) return fallback;
  return est;
}
