/**
 * Cyra · Voz de marca
 * ---------------------------------------------------------------
 * Centraliza tono, slogans, microcopy y mensajes dinámicos.
 * Regla de oro: Cyra acompaña, no exige. Nunca usa lenguaje
 * militar, culposo, estético-tóxico ni "sin excusas".
 *
 * Habla como una guía cálida, una amiga experta y una entrenadora
 * consciente que entiende cómo cambia el cuerpo femenino.
 *
 * Cómo habla Cyra:
 *  - en segunda persona, cercana ("tú", "hoy", "tu cuerpo")
 *  - frases cortas, claras, premium
 *  - menciona ciclo, energía y emoción, no estética
 *  - propone, nunca obliga ("podemos", "te propongo", "si te apetece")
 *
 * Palabras que evita: "debes", "tienes que", "sin excusas", "fallar",
 * "castigo", "perfecta", "summer body", "quemar", "bikini", "rebote",
 * "culpa", "vergüenza", "disciplina militar".
 */

import type { CyclePhase } from "@/lib/cycle";

export type VoiceContext =
  | "phase"
  | "rest"
  | "training"
  | "hydration"
  | "nutrition"
  | "recovery"
  | "energy"
  | "emotion"
  | "postpartum"
  | "empty";

// ──────────────────────────────────────────────────────────────
// SLOGANS DE MARCA
// ──────────────────────────────────────────────────────────────
export const SLOGANS = [
  "Entrena con tu cuerpo, no contra él.",
  "Tu energía cambia. Tu entrenamiento también.",
  "Fitness alineado con tu ciclo.",
  "Tu cuerpo cambia y nosotras nos adaptamos a ti.",
  "Movimiento consciente, bienestar real.",
];

export const TAGLINE = "Tu cuerpo cambia. Tu entrenamiento también.";

// ──────────────────────────────────────────────────────────────
// SALUDOS DINÁMICOS (según hora del día)
// ──────────────────────────────────────────────────────────────
export function getGreeting(name?: string): string {
  const hour = new Date().getHours();
  const safe = name?.trim() || "linda";
  if (hour < 6) return `Aún es temprano, ${safe} 🌙`;
  if (hour < 12) return `Buenos días, ${safe} ☀️`;
  if (hour < 19) return `Hola, ${safe} 💕`;
  return `Buenas noches, ${safe} 🌸`;
}

// ──────────────────────────────────────────────────────────────
// MENSAJES POR FASE — tono empático, no exigente
// ──────────────────────────────────────────────────────────────
type PhaseVoice = {
  /** Frase corta para tarjeta flotante / dashboard */
  headline: string[];
  /** Sugerencia de entrenamiento sin presión */
  training: string[];
  /** Mensajes emocionales / autocuidado */
  emotion: string[];
  /** Antojos y nutrición */
  nutrition: string[];
  /** Descanso / recuperación */
  rest: string[];
};

export const PHASE_VOICE: Record<CyclePhase, PhaseVoice> = {
  menstrual: {
    headline: [
      "Hoy tu cuerpo puede necesitar ir más lento.",
      "Estás iniciando un nuevo ciclo. Sé suave contigo.",
      "Descansar también es entrenar.",
    ],
    training: [
      "Movilidad, respiración o una caminata corta es más que suficiente.",
      "Si te apetece moverte, hazlo con cariño. Si no, escucha a tu cuerpo.",
      "Yoga suave o estiramientos pueden sentirse muy bien hoy.",
    ],
    emotion: [
      "Es válido sentirte más sensible. Tu cuerpo está renovando energía.",
      "No te exijas como ayer. Hoy es un día para escucharte.",
    ],
    nutrition: [
      "Suma alimentos cálidos, hierro y magnesio para reponerte sin esfuerzo.",
      "Un snack tibio puede reconfortarte más que cualquier dieta estricta.",
    ],
    rest: [
      "Dormir bien hoy vale más que cualquier entrenamiento intenso.",
      "Una infusión de jengibre o manzanilla te acompañará.",
    ],
  },
  follicular: {
    headline: [
      "Tu energía está volviendo a subir. Aprovéchala con calma.",
      "Buen momento para probar algo nuevo sin presión.",
      "Tu cuerpo está listo para crecer, paso a paso.",
    ],
    training: [
      "Si te animas, sube la intensidad poco a poco. Sin prisa.",
      "Fuerza o cardio moderado pueden sentirse muy bien.",
      "Es un buen día para sumar peso o repeticiones, sólo si te apetece.",
    ],
    emotion: [
      "Te puedes sentir más creativa y enfocada. Disfrútalo.",
      "Tu confianza está en ascenso. Confía en lo que tu cuerpo te pide.",
    ],
    nutrition: [
      "Proteína magra y carbohidratos complejos potencian tu energía.",
      "Suma frutas frescas y vegetales coloridos. Tu cuerpo lo va a agradecer.",
    ],
    rest: [
      "Aunque tu energía sube, dormir bien sigue siendo prioridad.",
    ],
  },
  ovulatory: {
    headline: [
      "Tu energía está en su mejor momento. Disfrútala.",
      "Hoy puedes brillar con fuerza y suavidad al mismo tiempo.",
      "Tu cuerpo está fuerte. Confía y muévete con gusto.",
    ],
    training: [
      "Si te animas, es un gran día para entrenamientos de fuerza o potencia.",
      "Aprovecha para retarte con cariño, no con dureza.",
      "Tu rendimiento es alto: muévete con foco y disfrútalo.",
    ],
    emotion: [
      "Tu confianza está en su punto más alto. Hónrala.",
      "Buen día para socializar, crear y conectar.",
    ],
    nutrition: [
      "Proteína de calidad y antioxidantes (frutos rojos, hojas verdes) acompañan tu pico.",
      "Hidrátate más de lo habitual: tu metabolismo está activo.",
    ],
    rest: [
      "Aunque te sientas con todo, respetar el descanso evita el bajón después.",
    ],
  },
  luteal: {
    headline: [
      "Tu cuerpo está pidiendo más calma. Es normal.",
      "Antojos y emociones son parte del ciclo. No las juzgues.",
      "Bajar la intensidad hoy es cuidarte, no retroceder.",
    ],
    training: [
      "Fuerza moderada, pilates o cardio suave pueden ser tu mejor opción.",
      "Si te sientes cansada, descansar es una decisión inteligente.",
      "Escucha tu cuerpo: no todo día tiene que ser productivo.",
    ],
    emotion: [
      "Si te sientes más sensible o irritable, es química, no debilidad.",
      "Tu tolerancia al estrés baja en esta fase. Date más espacio.",
      "Los antojos son una señal de tu cuerpo, no un fracaso.",
    ],
    nutrition: [
      "Suma grasas saludables, magnesio y fibra para estabilizar tu ánimo.",
      "Si te apetece dulce, elige opciones con proteína para saciarte mejor.",
      "Comer cada 3-4 horas ayuda a controlar antojos sin restricciones.",
    ],
    rest: [
      "Permítete dormir 30 minutos más. Tu cuerpo lo necesita.",
      "Reduce sodio y suma agua con limón para sentirte menos hinchada.",
    ],
  },
};

// ──────────────────────────────────────────────────────────────
// POST PARTO — recuperación con paciencia, sin culpa
// ──────────────────────────────────────────────────────────────
export const POSTPARTUM_VOICE = {
  headline: [
    "Estás reconstruyéndote. Cada paso cuenta.",
    "Tu cuerpo hizo algo enorme. Hoy lo acompañamos con paciencia.",
    "No hay prisa. Tu recuperación tiene su propio tiempo.",
    "Volver no es regresar al de antes: es construir lo nuevo.",
  ],
  training: [
    "Respiración, suelo pélvico y movilidad son tu mejor base ahora.",
    "Una caminata corta también es un entrenamiento real.",
    "Si dormiste poco, hoy puede ser sólo movilidad. Está perfecto.",
  ],
  emotion: [
    "Pedir ayuda no es debilidad, es inteligencia maternal.",
    "Tu cuerpo cambió porque hizo algo extraordinario. Sé amable.",
    "Los días difíciles no borran tu progreso.",
  ],
  nutrition: [
    "Comidas frecuentes, tibias y nutritivas te van a sostener mejor que cualquier dieta.",
    "Si lactas, suma hidratación y proteína sin restricciones extremas.",
  ],
  rest: [
    "Cuando el bebé descansa, tú también. Es parte del entrenamiento.",
    "Dormir poco afecta tu recuperación: prioriza lo que puedas.",
  ],
};

// ──────────────────────────────────────────────────────────────
// MICROCOPY UX — botones, estados vacíos, onboarding
// ──────────────────────────────────────────────────────────────
export const MICROCOPY = {
  buttons: {
    start: "Empezar",
    continue: "Continuar",
    save: "Guardar",
    skip: "Hoy no, gracias",
    later: "Lo veo más tarde",
    confirm: "Listo",
    edit: "Ajustar",
    explore: "Explorar",
    ready: "Estoy lista",
  },
  empty: {
    training: "Aún no tienes entrenamientos registrados. Cuando te apetezca, estoy aquí.",
    nutrition: "Hoy es un buen día para escuchar a tu cuerpo. Empezamos cuando quieras.",
    cycle: "Cuéntame cuándo fue tu último periodo y arman juntas tu calendario.",
    progress: "Tu progreso aparecerá aquí. Sin métricas tóxicas, sólo cómo te sientes.",
  },
  onboarding: {
    welcome: "Bienvenida 💕 Soy Cyra, tu guía de bienestar.",
    intro: "No estás aquí para castigarte. Estás aquí para entenderte y moverte mejor.",
    consent: "Cuéntame un poco sobre ti para adaptar todo a tu cuerpo y momento.",
  },
  reminders: {
    hydration: "Un vaso de agua ahora puede sentirse muy bien 💧",
    movement: "¿Una pausa de 2 minutos para estirar? Tu cuerpo te lo agradecerá.",
    rest: "Si hoy estás cansada, descansar también es entrenar.",
    nutrition: "Recuerda comer cada 3-4 horas para sostener tu energía.",
  },
};

// ──────────────────────────────────────────────────────────────
// MOTIVACIÓN NO TÓXICA — rotativa
// ──────────────────────────────────────────────────────────────
export const MOTIVATION = [
  "Constancia flexible vence disciplina rígida.",
  "Tu cuerpo no es un proyecto, es tu hogar.",
  "Pequeños pasos son grandes resultados.",
  "Lo que se cuida, florece.",
  "Tu progreso no se mide en el espejo.",
  "Cuidarte es un acto de inteligencia, no de vanidad.",
  "Hoy es un buen día para escucharte.",
  "Entrenar contenta vale más que entrenar perfecta.",
];

// ──────────────────────────────────────────────────────────────
// HELPERS — selección estable por día (rota sin parecer aleatorio)
// ──────────────────────────────────────────────────────────────
function pickStable<T>(arr: T[], seed = 0): T {
  if (!arr.length) return undefined as unknown as T;
  const day = Math.floor(Date.now() / (1000 * 60 * 60 * 24));
  return arr[(day + seed) % arr.length];
}

export function getPhaseMessage(
  phase: CyclePhase,
  context: keyof PhaseVoice = "headline",
  seed = 0,
): string {
  return pickStable(PHASE_VOICE[phase][context], seed);
}

export function getPostpartumMessage(
  context: keyof typeof POSTPARTUM_VOICE = "headline",
  seed = 0,
): string {
  return pickStable(POSTPARTUM_VOICE[context], seed);
}

export function getDailyMotivation(seed = 0): string {
  return pickStable(MOTIVATION, seed);
}

export function getDailySlogan(seed = 0): string {
  return pickStable(SLOGANS, seed);
}
