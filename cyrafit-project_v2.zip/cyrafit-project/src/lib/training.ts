import { CyclePhase, CycleMode } from "./cycle";

// ============================================================
// TYPES
// ============================================================

export type TrainingFrequency = 3 | 4 | 5;
export type WorkoutType = "full_body" | "lower" | "upper" | "core_stability" | "rest";
export type TrainingLevel = "beginner" | "intermediate" | "advanced";

export interface Exercise {
  name: string;
  sets: number;
  reps: string;
  rest: string;
  completed: boolean;
  /** Tempo en formato excéntrica-pausa-concéntrica, p. ej. "3-1-1" */
  tempo?: string;
  note?: string;
  videoId?: string;
}

export interface ExerciseLog {
  weight: number;
  actualSets: number;
  actualReps: string;
  rpe: number;
}

export interface WorkoutDay {
  type: WorkoutType;
  label: string;
  emoji: string;
  exercises: Exercise[];
}

export const LEVEL_LABELS: Record<TrainingLevel, string> = {
  beginner: "Principiante",
  intermediate: "Intermedio",
  advanced: "Avanzado",
};

export const LEVEL_DESCRIPTIONS: Record<TrainingLevel, string> = {
  beginner: "No has entrenado, llevas menos de 6 meses o retomas después de 2+ años",
  intermediate: "Llevas ~1 año entrenando o retomas con experiencia previa",
  advanced: "Más de 1 año entrenando de forma continua",
};

export const DAY_NAMES = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
export const DAY_NAMES_FULL = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

// ============================================================
// PROGRESSION (week + block)
// ============================================================

export interface MesocycleInfo {
  week: number;
  block: "A" | "B" | "C";
  weekInBlock: number;
  month: number;
  label: string;
}

export function getProgramWeek(startDateISO: string | null | undefined): number {
  if (!startDateISO) return 1;
  const start = new Date(startDateISO);
  const now = new Date();
  const days = Math.floor((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(1, Math.floor(days / 7) + 1);
}

export function getMesocycleInfo(level: TrainingLevel, mode: CycleMode, week: number): MesocycleInfo {
  // Principiante (sólo ciclo regular): primeras 8 semanas con A/B/C fijos, luego rota A/B/C mensual
  if (level === "beginner" && mode !== "postpartum") {
    if (week <= 2) return { week, block: "A", weekInBlock: week, month: 1, label: "Bloque A · Técnica" };
    if (week <= 4) return { week, block: "B", weekInBlock: week - 2, month: 1, label: "Bloque B · Carga ligera" };
    if (week <= 8) return { week, block: "C", weekInBlock: week - 4, month: 2, label: "Bloque C · Control" };
  }
  // Resto: bloques mensuales A/B/C que rotan indefinidamente
  const month = Math.floor((week - 1) / 4) + 1;
  const blockIndex = (month - 1) % 3;
  const block = (["A", "B", "C"] as const)[blockIndex];
  const weekInBlock = ((week - 1) % 4) + 1;
  const labels: Record<"A" | "B" | "C", string> = {
    A: "Bloque A · Base funcional",
    B: "Bloque B · Volumen",
    C: "Bloque C · Intensidad",
  };
  return { week, block, weekInBlock, month, label: labels[block] };
}

// ============================================================
// RPE OBJETIVO POR FASE
// ============================================================

export function getTargetRPE(phase: CyclePhase, mode: CycleMode = "cycle"): { min: number; max: number; label: string } {
  if (mode === "postpartum") return { min: 4, max: 6, label: "Suave · escucha tu cuerpo" };
  switch (phase) {
    case "menstrual": return { min: 5, max: 6, label: "Moderado · respeta el día" };
    case "follicular": return { min: 7, max: 8, label: "Energía en alza" };
    case "ovulatory": return { min: 8, max: 9, label: "Pico de fuerza" };
    case "luteal": return { min: 6, max: 7, label: "Mantén la técnica" };
  }
}

// ============================================================
// FUNCTIONAL PATTERNS + EXERCISE POOLS
// ============================================================
// Idea: cada (nivel, patrón) tiene 3-6 ejercicios. Cada mes elegimos un ejercicio
// distinto del pool para cada slot del entrenamiento, así nunca se repite la
// misma rutina y volvemos a estímulos ya conocidos en otros meses.

export type Pattern =
  | "squat"        // Sentadilla bilateral (knee dominant)
  | "hinge"        // Bisagra de cadera (hip dominant)
  | "sl_squat"     // Unilateral knee
  | "sl_hinge"     // Unilateral hip
  | "lunge"        // Zancadas / locomoción
  | "push_h"       // Empuje horizontal (pecho)
  | "push_v"       // Empuje vertical (hombro)
  | "pull_h"       // Tracción horizontal (remo)
  | "pull_v"       // Tracción vertical (face pull / dorsal)
  | "carry"        // Carries / acarreos funcionales
  | "anti_ext"     // Anti-extensión (planchas)
  | "anti_rot"     // Anti-rotación (pallof, ...)
  | "anti_lat"     // Anti-flexión lateral (plancha lateral, suitcase)
  | "rotation"     // Rotación controlada
  | "core_dyn"    // Core dinámico (dead bug, bird dog, jackknife)
  | "glute_iso"    // Aislamiento glúteo (abducción, kickback)
  | "mobility"     // Movilidad activa
  | "breath"       // Respiración / activación
  | "pelvic";      // Suelo pélvico

interface PoolDef {
  name: string;
  sets: number;
  reps: string;
  rest: string;
  tempo?: string;
  note?: string;
}

// Helper para definir un ejercicio del pool
const p = (name: string, sets: number, reps: string, rest: string, tempo?: string, note?: string): PoolDef =>
  ({ name, sets, reps, rest, tempo, note });

// ----------------------------------------------------------
// BEGINNER POOLS
// ----------------------------------------------------------
const POOL_BEG: Partial<Record<Pattern, PoolDef[]>> = {
  squat: [
    p("Sentadilla a silla", 3, "10", "60s", "3-1-1", "Tocá la silla sin sentarte del todo"),
    p("Sentadilla con banda en rodillas", 3, "12", "60s", "3-1-1", "Empuja rodillas contra la banda"),
    p("Sentadilla con fitball en pared", 3, "12", "60s", "3-1-1", "Rueda la pelota por la espalda"),
    p("Sentadilla sumo con peso casero", 3, "12", "60s", "3-1-1", "Pies anchos, agarra una jarra/mochila"),
  ],
  hinge: [
    p("Puente de glúteo", 3, "12", "45s", "2-2-1", "Aprieta glúteo 2s arriba"),
    p("Puente de glúteo con banda en rodillas", 3, "12", "45s", "2-2-1"),
    p("Peso muerto rumano con mochila", 3, "10", "60s", "3-1-1", "Caderas atrás, espalda neutra"),
    p("Buenos días con banda", 3, "12", "45s", "3-1-1", "Banda bajo los pies, sobre los hombros"),
  ],
  lunge: [
    p("Zancada estática asistida", 3, "8 c/lado", "60s", "3-0-1", "Apoya una mano en silla"),
    p("Zancada inversa", 3, "10 c/lado", "60s", "3-0-1"),
    p("Step up bajo (silla firme)", 3, "10 c/lado", "60s", "2-0-1"),
    p("Marcha de granjero en el sitio", 2, "30s", "45s", "controlado", "Levanta rodilla a la cadera"),
  ],
  push_h: [
    p("Flexiones en pared", 3, "8", "60s", "3-0-1"),
    p("Flexiones inclinadas (sofá/mesa)", 3, "10", "60s", "3-0-1"),
    p("Press de pecho con banda", 3, "10", "60s", "3-0-1", "Banda detrás de la espalda"),
    p("Flexiones en rodillas", 3, "8", "60s", "3-0-1"),
  ],
  push_v: [
    p("Press hombro con banda ligera", 3, "10", "60s", "3-0-1"),
    p("Press hombro alterno con banda", 3, "8 c/lado", "60s", "3-0-1"),
    p("Pike push up en banco", 3, "8", "60s", "3-0-1", "Caderas altas, mira al suelo"),
  ],
  pull_h: [
    p("Remo sentada con banda", 3, "12", "45s", "2-1-2", "Anclar banda en pie"),
    p("Remo con banda anclada de pie", 3, "12", "60s", "2-1-2"),
    p("Remo a 1 mano con banda", 3, "10 c/lado", "60s", "2-1-2"),
    p("Remo invertido bajo mesa firme", 3, "8", "60s", "3-0-1"),
  ],
  pull_v: [
    p("Pull apart con banda", 3, "12", "45s", "2-2-1", "Aprieta omóplatos"),
    p("Face pull con banda", 3, "12", "45s", "2-1-2"),
    p("Pull over con banda", 3, "10", "45s", "2-1-2"),
  ],
  carry: [
    p("Marcha de granjero (2 mochilas)", 3, "30s", "45s", "controlado", "Caminar erguida, hombros bajos"),
    p("Caminata suitcase (1 mano)", 3, "20s c/lado", "45s", "controlado"),
    p("Caminata sobre los talones", 2, "20s", "30s", "controlado"),
  ],
  anti_ext: [
    p("Plancha en rodillas", 3, "20s", "45s", "isométrico", "Cuerpo en línea"),
    p("Plancha frontal", 3, "20s", "45s", "isométrico"),
    p("Plancha con antebrazos en fitball", 3, "20s", "45s", "isométrico"),
  ],
  anti_rot: [
    p("Pallof press con banda (rodillas)", 3, "10 c/lado", "30s", "2-1-2"),
    p("Pallof press de pie con banda", 3, "10 c/lado", "30s", "2-1-2"),
    p("Banda anclada, paso lateral con resistencia", 3, "8 c/lado", "30s", "controlado"),
  ],
  core_dyn: [
    p("Bird dog", 3, "8 c/lado", "45s", "controlado"),
    p("Dead bug", 3, "8 c/lado", "45s", "2-1-2"),
    p("Dead bug con banda en manos", 3, "10 c/lado", "45s", "2-1-2"),
    p("Bird dog con banda", 3, "8 c/lado", "45s", "controlado"),
  ],
  glute_iso: [
    p("Abducción de cadera tumbada", 3, "12 c/lado", "30s", "2-1-2"),
    p("Abducción de pie con banda", 3, "12 c/lado", "30s", "2-1-2"),
    p("Patada de glúteo con banda", 3, "12 c/lado", "30s", "2-1-2"),
    p("Concha (clamshell) con banda", 3, "12 c/lado", "30s", "2-1-2"),
  ],
  mobility: [
    p("Gato-vaca", 2, "10", "20s", "lento"),
    p("Apertura torácica de rodillas", 2, "8 c/lado", "20s", "lento"),
    p("Movilidad de cadera 90/90", 2, "6 c/lado", "20s", "lento"),
  ],
  breath: [
    p("Respiración diafragmática", 2, "8", "30s", "4-2-4", "Expandir costillas, no la barriga"),
  ],
};

// ----------------------------------------------------------
// INTERMEDIATE POOLS
// ----------------------------------------------------------
const POOL_INT: Partial<Record<Pattern, PoolDef[]>> = {
  squat: [
    p("Sentadilla goblet con mochila", 4, "12", "60s", "3-1-1"),
    p("Sentadilla sumo con banda", 4, "12", "60s", "3-1-1"),
    p("Sentadilla con fitball en pared (1 pierna asistida)", 3, "10 c/lado", "60s", "3-1-1"),
    p("Sentadilla con pausa abajo", 3, "10", "75s", "3-2-1"),
    p("Sentadilla con banda en rodillas + tempo", 4, "12", "60s", "4-1-1"),
  ],
  hinge: [
    p("Peso muerto rumano con banda", 4, "12", "60s", "3-1-1"),
    p("Hip thrust con fitball y banda", 4, "12", "60s", "2-2-1"),
    p("Buenos días con banda", 4, "12", "60s", "3-1-1"),
    p("Swing con mochila", 4, "15", "60s", "explosivo", "Cadera, no brazos"),
    p("Peso muerto sumo con banda", 4, "12", "60s", "3-1-1"),
  ],
  sl_squat: [
    p("Sentadilla búlgara con banda", 3, "10 c/lado", "75s", "3-1-1"),
    p("Step up alto con banda", 3, "10 c/lado", "60s", "2-0-1"),
    p("Zancada inversa con banda", 3, "10 c/lado", "60s", "3-0-1"),
    p("Sentadilla a 1 pierna asistida (TRX/banda)", 3, "8 c/lado", "75s", "3-1-1"),
  ],
  sl_hinge: [
    p("Peso muerto rumano a 1 pierna con banda", 3, "10 c/lado", "60s", "3-0-1"),
    p("Hip thrust 1 pierna con fitball", 3, "10 c/lado", "60s", "2-2-1"),
    p("Curl femoral con fitball", 3, "12", "60s", "3-1-1"),
    p("Patada caderaa 4 apoyos con banda (donkey kick)", 3, "12 c/lado", "45s", "2-1-2"),
  ],
  lunge: [
    p("Zancada caminando con mochila", 3, "12 c/lado", "60s", "3-0-1"),
    p("Zancada lateral con banda", 3, "10 c/lado", "60s", "3-0-1"),
    p("Zancada con rotación (anti-rot)", 3, "10 c/lado", "60s", "controlado", "Gira el torso al frente"),
    p("Skater step (patinador)", 3, "12 c/lado", "45s", "controlado"),
  ],
  push_h: [
    p("Flexiones en suelo", 3, "10", "60s", "3-0-1"),
    p("Flexiones con manos en fitball", 3, "10", "60s", "3-1-1"),
    p("Press de pecho con banda + fitball", 3, "12", "60s", "3-0-1"),
    p("Flexiones con pies elevados en silla", 3, "10", "60s", "3-1-1"),
    p("Flexiones diamante (rodillas si necesitas)", 3, "10", "60s", "3-1-1"),
  ],
  push_v: [
    p("Press militar con banda", 3, "10", "60s", "3-0-1"),
    p("Press Arnold con banda", 3, "10", "60s", "3-0-1"),
    p("Pike push up en banco", 3, "10", "60s", "3-0-1"),
    p("Elevación lateral con banda", 3, "12", "45s", "2-1-2"),
  ],
  pull_h: [
    p("Remo con banda anclada", 4, "12", "60s", "2-1-2"),
    p("Remo a 1 mano con banda", 3, "10 c/lado", "60s", "2-1-2"),
    p("Remo invertido bajo mesa firme", 3, "10", "60s", "3-0-1"),
    p("Remo con banda doblada", 4, "12", "60s", "2-1-2"),
    p("Remo arquero con banda", 3, "10 c/lado", "60s", "3-0-1"),
  ],
  pull_v: [
    p("Pull apart con banda", 3, "15", "45s", "2-2-1"),
    p("Face pull con banda", 3, "12", "45s", "2-1-2"),
    p("Lat pulldown con banda anclada arriba", 3, "12", "45s", "2-1-2"),
    p("Pull over con banda", 3, "12", "45s", "2-1-2"),
  ],
  carry: [
    p("Farmer carry con mochilas", 3, "40s", "45s", "controlado"),
    p("Suitcase carry pesado", 3, "30s c/lado", "45s", "controlado"),
    p("Overhead carry con banda", 3, "20s c/lado", "45s", "controlado"),
    p("Bear crawl", 3, "20s", "45s", "controlado", "Rodillas a 5 cm del suelo"),
  ],
  anti_ext: [
    p("Plancha con pies en fitball", 3, "40s", "30s", "isométrico"),
    p("Plancha + tap hombro", 3, "10 c/lado", "30s", "controlado"),
    p("Plancha con rollout pequeño en fitball", 3, "10", "45s", "3-0-1"),
    p("Plancha alta con elevación pierna", 3, "10 c/lado", "30s", "2-1-2"),
  ],
  anti_rot: [
    p("Pallof press con banda", 3, "12 c/lado", "30s", "2-1-2"),
    p("Pallof press dinámico (paso lateral)", 3, "10 c/lado", "30s", "2-1-2"),
    p("Press de pecho 1 mano con banda de pie", 3, "10 c/lado", "30s", "2-1-2"),
    p("Renegade row con mochilas", 3, "8 c/lado", "45s", "controlado"),
  ],
  anti_lat: [
    p("Plancha lateral", 3, "30s c/lado", "30s", "isométrico"),
    p("Plancha lateral con elevación cadera", 3, "10 c/lado", "30s", "2-1-2"),
    p("Suitcase hold con mochila", 3, "30s c/lado", "30s", "isométrico"),
  ],
  rotation: [
    p("Russian twist con fitball", 3, "12 c/lado", "30s", "controlado"),
    p("Wood chop con banda alta a baja", 3, "12 c/lado", "30s", "2-1-2"),
    p("Wood chop con banda baja a alta", 3, "12 c/lado", "30s", "2-1-2"),
    p("Rotación torácica en cuadrupedia", 3, "8 c/lado", "30s", "lento"),
  ],
  core_dyn: [
    p("Dead bug con banda", 3, "10 c/lado", "30s", "2-1-2"),
    p("Bird dog con banda", 3, "10 c/lado", "30s", "controlado"),
    p("Jackknife con fitball", 3, "10", "45s", "3-0-1"),
    p("Hollow hold", 3, "20s", "30s", "isométrico"),
    p("Mountain climbers lentos en fitball", 3, "20", "30s", "controlado"),
  ],
  glute_iso: [
    p("Abducción de pie con banda", 3, "15 c/lado", "45s", "2-1-2"),
    p("Patada de glúteo con banda", 3, "12 c/lado", "45s", "2-1-2"),
    p("Patada lateral con banda en tobillo", 3, "15 c/lado", "45s", "2-1-2"),
    p("Concha (clamshell) con banda fuerte", 3, "15 c/lado", "30s", "2-1-2"),
  ],
  mobility: [
    p("Gato-vaca", 2, "10", "20s", "lento"),
    p("Movilidad de cadera 90/90", 2, "8 c/lado", "20s", "lento"),
    p("Apertura torácica sobre fitball", 2, "8", "20s", "lento"),
  ],
};

// ----------------------------------------------------------
// ADVANCED POOLS
// ----------------------------------------------------------
const POOL_ADV: Partial<Record<Pattern, PoolDef[]>> = {
  squat: [
    p("Sentadilla pistola asistida con banda", 4, "8 c/lado", "75s", "4-1-1"),
    p("Sentadilla goblet pesada con mochila", 4, "12", "75s", "4-1-1"),
    p("Sentadilla con pausa abajo + banda", 4, "10", "75s", "4-2-1"),
    p("Sentadilla salto con banda en cadera", 4, "10", "75s", "explosiva"),
    p("Sissy squat asistida con banda", 4, "10", "75s", "4-1-1"),
  ],
  hinge: [
    p("Hip thrust con banda doblada (pausa)", 5, "10", "75s", "3-3-1"),
    p("Peso muerto rumano con banda doblada", 4, "12", "75s", "4-1-1"),
    p("Swing pesado con mochila", 4, "20", "60s", "explosivo"),
    p("Good morning con banda doblada", 4, "12", "75s", "4-1-1"),
    p("Single leg deadlift con mochila", 4, "10 c/lado", "60s", "3-1-1"),
  ],
  sl_squat: [
    p("Pistol asistida con banda", 4, "6 c/lado", "90s", "5-1-1"),
    p("Sentadilla búlgara con banda doblada", 4, "10 c/lado", "90s", "4-1-1"),
    p("Step up alto pesado", 4, "10 c/lado", "75s", "3-0-1"),
    p("Skater squat asistido", 4, "8 c/lado", "75s", "4-1-1"),
  ],
  sl_hinge: [
    p("Peso muerto rumano a 1 pierna con banda doblada", 4, "10 c/lado", "60s", "4-1-1"),
    p("Hip thrust 1 pierna pesado", 4, "10 c/lado", "75s", "3-2-1"),
    p("Curl femoral nórdico asistido con banda", 3, "6", "90s", "5-0-1"),
    p("Patada de cadera a 4 apoyos pesada", 4, "12 c/lado", "60s", "3-1-1"),
  ],
  lunge: [
    p("Zancada caminando con mochila pesada", 4, "12 c/lado", "60s", "3-0-1"),
    p("Zancada con salto (jump lunge)", 4, "10 c/lado", "60s", "explosiva"),
    p("Cossack squat (lateral profunda)", 4, "8 c/lado", "75s", "3-1-1"),
    p("Reverse lunge a knee drive", 4, "10 c/lado", "60s", "explosiva"),
  ],
  push_h: [
    p("Flexiones arquero", 4, "8 c/lado", "75s", "3-1-1"),
    p("Flexiones con pies en fitball", 4, "10", "75s", "3-1-1"),
    p("Press de pecho con banda doblada", 4, "12", "60s", "3-1-1"),
    p("Flexiones explosivas (clap o liberación)", 4, "8", "75s", "2-0-X"),
    p("Flexiones diamante", 4, "10", "60s", "3-1-1"),
  ],
  push_v: [
    p("Pike push up", 4, "10", "75s", "3-1-1"),
    p("Press hombro con banda doblada (pausa)", 4, "10", "60s", "3-2-1"),
    p("Press Arnold con banda doblada", 4, "10", "60s", "3-0-1"),
    p("Handstand hold asistido (pared)", 3, "20s", "60s", "isométrico"),
  ],
  pull_h: [
    p("Remo con banda doblada (pausa)", 4, "10", "60s", "3-1-2"),
    p("Remo arquero con banda doblada", 4, "8 c/lado", "60s", "3-0-1"),
    p("Remo invertido pies en fitball", 4, "10", "60s", "3-0-1"),
    p("Renegade row con mochilas pesadas", 4, "8 c/lado", "60s", "controlado"),
  ],
  pull_v: [
    p("Pull apart con banda fuerte", 4, "15", "45s", "2-2-1"),
    p("Face pull con banda doblada", 4, "15", "45s", "2-1-2"),
    p("Lat pulldown con banda anclada arriba", 4, "12", "45s", "3-1-1"),
    p("Pull over con banda doblada", 4, "12", "45s", "2-1-2"),
  ],
  carry: [
    p("Farmer carry pesado con mochilas", 4, "40s", "60s", "controlado"),
    p("Overhead carry 1 mano con banda", 4, "30s c/lado", "45s", "isométrico"),
    p("Suitcase carry pesado", 4, "30s c/lado", "45s", "controlado"),
    p("Bear crawl largo", 4, "30s", "45s", "controlado"),
  ],
  anti_ext: [
    p("Plancha con pies en fitball", 4, "45s", "30s", "isométrico"),
    p("Plancha con pies en fitball + remo banda", 4, "10 c/lado", "45s", "controlado"),
    p("Rollout con fitball", 4, "10", "45s", "3-0-1"),
    p("Ab wheel asistido (con fitball)", 4, "8", "60s", "4-0-1"),
  ],
  anti_rot: [
    p("Pallof press isométrico largo", 4, "30s c/lado", "30s", "isométrico"),
    p("Pallof press dinámico con banda", 4, "12 c/lado", "30s", "2-1-2"),
    p("Renegade row con mochilas", 4, "10 c/lado", "45s", "controlado"),
    p("Press de pecho 1 mano de pie con banda", 4, "10 c/lado", "45s", "2-1-2"),
  ],
  anti_lat: [
    p("Plancha lateral con elevación pierna", 4, "12 c/lado", "30s", "2-1-2"),
    p("Suitcase hold pesado", 4, "40s c/lado", "30s", "isométrico"),
    p("Side plank con rotación (T-rotation)", 4, "10 c/lado", "30s", "2-1-2"),
  ],
  rotation: [
    p("Wood chop con banda doblada", 4, "12 c/lado", "30s", "2-1-2"),
    p("Russian twist con fitball pesado", 4, "15 c/lado", "30s", "controlado"),
    p("Med ball/jarra slam rotacional", 4, "10 c/lado", "45s", "explosiva"),
  ],
  core_dyn: [
    p("Jackknife con fitball + giro", 4, "10 c/lado", "45s", "3-0-1"),
    p("Pike con fitball", 4, "12", "45s", "3-0-1"),
    p("Hollow rock", 4, "20", "30s", "controlado"),
    p("L-sit asistido en sillas", 4, "20s", "60s", "isométrico"),
    p("Toes to bar asistido con banda", 4, "8", "60s", "controlado"),
  ],
  glute_iso: [
    p("Abducción de pie con banda doblada", 3, "15 c/lado", "45s", "2-2-2"),
    p("Patada de glúteo con banda doblada", 3, "15 c/lado", "45s", "2-1-2"),
    p("Hip thrust 1 pierna isométrico", 3, "30s c/lado", "45s", "isométrico"),
  ],
  mobility: [
    p("Movilidad de cadera 90/90 con rotación", 2, "8 c/lado", "20s", "lento"),
    p("Apertura torácica sobre fitball", 2, "8", "20s", "lento"),
    p("Cossack stretch dinámico", 2, "8 c/lado", "20s", "lento"),
  ],
};

// ----------------------------------------------------------
// POSTPARTUM POOLS
// ----------------------------------------------------------
const POOL_PP: Partial<Record<Pattern, PoolDef[]>> = {
  breath: [
    p("Respiración 360°", 3, "8", "30s", "4-2-4", "Expandir costillas en todas las direcciones"),
    p("Respiración diafragmática", 3, "10", "30s", "4-2-4"),
    p("Respiración 360° con banda ligera en cintura", 3, "10", "30s", "4-2-4"),
  ],
  pelvic: [
    p("Kegel con exhalación", 3, "10", "30s", "3-3-3", "Aprieta al exhalar"),
    p("Kegel dinámico (rápidos + sostenidos)", 3, "10+5", "30s", "3-3-3"),
    p("Puente con apretón pélvico", 3, "10", "45s", "2-2-1"),
    p("Sentadilla con fitball en pared + kegel", 3, "10", "60s", "3-1-1"),
  ],
  core_dyn: [
    p("Transverso del abdomen acostada", 3, "10", "30s", "exhalar al apretar"),
    p("Dead bug bajo (solo brazos)", 3, "8 c/lado", "45s", "2-1-2"),
    p("Bird dog asistido", 3, "6 c/lado", "45s", "controlado"),
    p("Bird dog con banda", 3, "8 c/lado", "45s", "controlado"),
    p("Dead bug con banda en manos", 3, "10 c/lado", "45s", "2-1-2"),
  ],
  hinge: [
    p("Puente de glúteo pequeño", 3, "10", "45s", "2-2-1"),
    p("Puente con pies en fitball", 3, "12", "45s", "2-2-1"),
    p("Puente 1 pierna con pie en fitball", 3, "8 c/lado", "45s", "2-2-1"),
    p("Hip thrust con fitball + banda ligera", 3, "12", "60s", "2-2-1"),
  ],
  squat: [
    p("Sentadilla a silla", 3, "10", "60s", "3-1-1"),
    p("Sentadilla con fitball en pared", 3, "12", "60s", "3-1-1"),
    p("Sentadilla goblet ligera con mochila", 3, "12", "60s", "3-1-1"),
  ],
  pull_h: [
    p("Remo con banda ligera", 3, "10", "45s", "2-1-2"),
    p("Remo con banda anclada", 3, "12", "60s", "2-1-2"),
    p("Pull apart con banda ligera", 3, "12", "45s", "2-2-1"),
  ],
  push_h: [
    p("Flexiones en pared", 3, "8", "60s", "3-0-1"),
    p("Flexiones inclinadas", 3, "10", "60s", "3-0-1"),
    p("Flexiones con manos en fitball (pared)", 3, "8", "60s", "3-0-1"),
  ],
  glute_iso: [
    p("Abducción de cadera con banda ligera", 3, "10 c/lado", "45s", "2-1-2"),
    p("Patada de glúteo con banda", 3, "12 c/lado", "45s", "2-1-2"),
    p("Concha (clamshell) con banda", 3, "12 c/lado", "30s", "2-1-2"),
  ],
  anti_ext: [
    p("Plancha en rodillas", 3, "15s", "45s", "isométrico"),
    p("Plancha frontal", 3, "20s", "45s", "isométrico"),
    p("Plancha con manos en fitball (pared)", 3, "20s", "45s", "isométrico"),
  ],
  mobility: [
    p("Gato-vaca", 3, "10", "20s", "lento"),
    p("Rotación torácica acostada", 3, "8 c/lado", "20s", "lento"),
    p("Apertura sobre fitball", 2, "5 respiraciones", "30s", "lento"),
    p("Estiramiento de psoas en zancada", 2, "30s c/lado", "20s", "lento"),
    p("Postura del niño con respiración", 2, "5 respiraciones", "20s", "lento"),
    p("Apertura de pecho acostada", 2, "5 respiraciones c/lado", "20s", "lento"),
    p("Saludo al sol suave (modificado)", 2, "3 rondas", "30s", "lento"),
  ],
};

// ============================================================
// SESSION TEMPLATES (patrones a usar por nivel × bloque × tipo)
// ============================================================
// Cada slot define un patrón. El selector elige un ejercicio del pool
// usando month + slotIndex como semilla → rotación infinita.

type SessionTemplate = Pattern[];

const TPL_BEG: Record<"A" | "B" | "C", Record<Exclude<WorkoutType, "rest">, SessionTemplate>> = {
  A: {
    full_body: ["breath", "squat", "push_h", "hinge", "pull_h", "anti_ext"],
    lower:     ["squat", "hinge", "lunge", "glute_iso", "anti_ext"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "core_dyn"],
    core_stability: ["breath", "core_dyn", "anti_ext", "hinge", "anti_rot", "mobility"],
  },
  B: {
    full_body: ["squat", "push_h", "hinge", "pull_h", "carry", "anti_ext"],
    lower:     ["squat", "hinge", "lunge", "glute_iso", "carry"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "carry", "core_dyn"],
    core_stability: ["core_dyn", "anti_ext", "anti_rot", "glute_iso", "mobility"],
  },
  C: {
    full_body: ["squat", "push_h", "hinge", "pull_h", "lunge", "anti_ext", "anti_rot"],
    lower:     ["squat", "hinge", "lunge", "glute_iso", "carry"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "anti_rot", "core_dyn"],
    core_stability: ["anti_ext", "core_dyn", "anti_rot", "glute_iso", "mobility"],
  },
};

const TPL_INT: Record<"A" | "B" | "C", Record<Exclude<WorkoutType, "rest">, SessionTemplate>> = {
  A: {
    full_body: ["squat", "push_h", "hinge", "pull_h", "lunge", "carry", "anti_ext"],
    lower:     ["squat", "hinge", "sl_squat", "sl_hinge", "glute_iso", "carry"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "carry", "core_dyn"],
    core_stability: ["anti_ext", "anti_rot", "core_dyn", "anti_lat", "rotation", "mobility"],
  },
  B: {
    full_body: ["sl_squat", "push_h", "sl_hinge", "pull_h", "lunge", "anti_rot", "core_dyn"],
    lower:     ["sl_squat", "hinge", "lunge", "sl_hinge", "glute_iso", "anti_lat"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "rotation", "core_dyn"],
    core_stability: ["anti_ext", "anti_rot", "rotation", "core_dyn", "anti_lat", "mobility"],
  },
  C: {
    full_body: ["squat", "push_h", "hinge", "pull_h", "carry", "rotation", "anti_ext"],
    lower:     ["squat", "sl_hinge", "lunge", "sl_squat", "glute_iso", "carry"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "anti_rot", "carry"],
    core_stability: ["core_dyn", "anti_ext", "anti_rot", "anti_lat", "rotation", "mobility"],
  },
};

const TPL_ADV: Record<"A" | "B" | "C", Record<Exclude<WorkoutType, "rest">, SessionTemplate>> = {
  A: {
    full_body: ["sl_squat", "push_h", "sl_hinge", "pull_h", "carry", "anti_ext", "anti_rot"],
    lower:     ["sl_squat", "hinge", "sl_hinge", "lunge", "glute_iso", "carry"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "carry", "core_dyn"],
    core_stability: ["anti_ext", "anti_rot", "anti_lat", "rotation", "core_dyn", "mobility"],
  },
  B: {
    full_body: ["squat", "push_h", "hinge", "pull_h", "lunge", "rotation", "core_dyn"],
    lower:     ["squat", "sl_hinge", "lunge", "sl_squat", "glute_iso", "anti_lat"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "rotation", "anti_rot"],
    core_stability: ["core_dyn", "anti_ext", "anti_rot", "anti_lat", "rotation", "mobility"],
  },
  C: {
    full_body: ["sl_squat", "push_h", "sl_hinge", "pull_h", "carry", "rotation", "anti_ext"],
    lower:     ["sl_squat", "sl_hinge", "lunge", "hinge", "glute_iso", "carry"],
    upper:     ["push_h", "pull_h", "push_v", "pull_v", "anti_rot", "core_dyn"],
    core_stability: ["anti_ext", "anti_rot", "anti_lat", "rotation", "core_dyn", "mobility"],
  },
};

type PostpartumWorkoutType = "core_diastasis" | "pelvic_floor" | "gentle_strength" | "mobility_breath";

const PP_LABELS: Record<PostpartumWorkoutType, string> = {
  core_diastasis: "Core profundo · Diástasis",
  pelvic_floor: "Suelo pélvico",
  gentle_strength: "Fuerza suave global",
  mobility_breath: "Movilidad y respiración",
};
const PP_EMOJIS: Record<PostpartumWorkoutType, string> = {
  core_diastasis: "🤱",
  pelvic_floor: "🌸",
  gentle_strength: "💗",
  mobility_breath: "🕊️",
};

const TPL_PP: Record<"A" | "B" | "C", Record<PostpartumWorkoutType, SessionTemplate>> = {
  A: {
    core_diastasis: ["breath", "core_dyn", "hinge", "mobility"],
    pelvic_floor:   ["breath", "pelvic", "hinge", "mobility"],
    gentle_strength:["squat", "hinge", "push_h", "pull_h", "core_dyn"],
    mobility_breath:["breath", "mobility", "mobility", "mobility"],
  },
  B: {
    core_diastasis: ["breath", "core_dyn", "hinge", "anti_ext"],
    pelvic_floor:   ["pelvic", "squat", "hinge", "glute_iso"],
    gentle_strength:["squat", "hinge", "push_h", "pull_h", "core_dyn", "anti_ext"],
    mobility_breath:["breath", "mobility", "mobility", "mobility"],
  },
  C: {
    core_diastasis: ["core_dyn", "anti_ext", "hinge", "core_dyn"],
    pelvic_floor:   ["pelvic", "squat", "hinge", "glute_iso", "anti_ext"],
    gentle_strength:["squat", "hinge", "push_h", "pull_h", "push_h", "anti_ext"],
    mobility_breath:["breath", "mobility", "mobility", "mobility", "mobility"],
  },
};

// ============================================================
// PICKER (rotación infinita basada en mes y slot)
// ============================================================

function pickFromPool(
  pool: PoolDef[] | undefined,
  month: number,
  slotIndex: number,
  patternSalt: number,
): PoolDef | null {
  if (!pool || pool.length === 0) return null;
  // Distintos slots del mismo entrenamiento usan posiciones distintas del pool.
  // Mes a mes rota: cada mes nuevo desplaza el índice por 1.
  const idx = Math.abs(month - 1 + slotIndex * 3 + patternSalt) % pool.length;
  return pool[idx];
}

const PATTERN_SALT: Record<Pattern, number> = {
  squat: 0, hinge: 1, sl_squat: 2, sl_hinge: 3, lunge: 4,
  push_h: 5, push_v: 6, pull_h: 7, pull_v: 8, carry: 9,
  anti_ext: 10, anti_rot: 11, anti_lat: 12, rotation: 13,
  core_dyn: 14, glute_iso: 15, mobility: 16, breath: 17, pelvic: 18,
};

function buildSession(
  pool: Partial<Record<Pattern, PoolDef[]>>,
  template: SessionTemplate,
  month: number,
  blockBoost: { extraSet: boolean; tempoSwap?: string },
): Exercise[] {
  const out: Exercise[] = [];
  template.forEach((pattern, slotIdx) => {
    const def = pickFromPool(pool[pattern], month, slotIdx, PATTERN_SALT[pattern]);
    if (!def) return;
    out.push({
      name: def.name,
      sets: def.sets + (blockBoost.extraSet ? 1 : 0),
      reps: def.reps,
      rest: def.rest,
      tempo: blockBoost.tempoSwap ?? def.tempo,
      note: def.note,
      completed: false,
    });
  });
  return out;
}

function blockBoost(block: "A" | "B" | "C"): { extraSet: boolean; tempoSwap?: string } {
  if (block === "A") return { extraSet: false };
  if (block === "B") return { extraSet: true };
  return { extraSet: true }; // C: tempo se queda del propio ejercicio (muchos ya son lentos)
}

// ============================================================
// PHASE & WEEK ADJUSTMENTS
// ============================================================

function shiftRest(rest: string, delta: number): string {
  const sec = parseInt(rest);
  if (isNaN(sec)) return rest;
  return `${Math.max(30, Math.min(150, sec + delta))}s`;
}

function adjustForPhase(exercises: Exercise[], phase: CyclePhase): Exercise[] {
  return exercises.map((ex) => {
    switch (phase) {
      case "menstrual": return { ...ex, sets: Math.max(2, ex.sets - 1), rest: shiftRest(ex.rest, 15) };
      case "follicular": return { ...ex };
      case "ovulatory": return { ...ex, sets: ex.sets + 1, rest: shiftRest(ex.rest, -10) };
      case "luteal": return { ...ex, rest: shiftRest(ex.rest, 10) };
    }
  });
}

function adjustForWeekInBlock(exercises: Exercise[], weekInBlock: number): Exercise[] {
  if (weekInBlock <= 1) return exercises;
  return exercises.map((ex) => {
    const isoMatch = ex.reps.match(/^(\d+)s(.*)$/);
    if (isoMatch) {
      const base = parseInt(isoMatch[1]);
      return { ...ex, reps: `${base + 5 * (weekInBlock - 1)}s${isoMatch[2]}` };
    }
    const repMatch = ex.reps.match(/^(\d+)(.*)$/);
    if (repMatch) {
      const base = parseInt(repMatch[1]);
      return { ...ex, reps: `${base + 1 * (weekInBlock - 1)}${repMatch[2]}` };
    }
    return ex;
  });
}

// ============================================================
// LABELS & EMOJIS
// ============================================================

export function getWorkoutLabel(type: WorkoutType): string {
  switch (type) {
    case "full_body": return "Full Body";
    case "lower": return "Tren Inferior";
    case "upper": return "Tren Superior";
    case "core_stability": return "Core y Estabilidad";
    case "rest": return "Descanso";
  }
}

export function getWorkoutEmoji(type: WorkoutType): string {
  switch (type) {
    case "full_body": return "💪";
    case "lower": return "🦵";
    case "upper": return "🏋️‍♀️";
    case "core_stability": return "🧘‍♀️";
    case "rest": return "😴";
  }
}

// ============================================================
// MAIN PLAN GENERATOR
// ============================================================

export function generateWeeklyPlan(
  frequency: TrainingFrequency,
  phase: CyclePhase,
  mode: CycleMode = "cycle",
  level: TrainingLevel = "intermediate",
  programWeek: number = 1,
): WorkoutDay[] {
  const meso = getMesocycleInfo(level, mode, programWeek);
  const boost = blockBoost(meso.block);

  // Post parto
  if (mode === "postpartum") {
    const baseRotation: PostpartumWorkoutType[] = [
      "core_diastasis", "pelvic_floor", "gentle_strength", "mobility_breath", "core_diastasis",
    ];
    const ppSlots = baseRotation.slice(0, frequency);
    const dayIndicesByFreq: Record<TrainingFrequency, number[]> = {
      3: [0, 2, 4],
      4: [0, 1, 3, 5],
      5: [0, 1, 3, 4, 5],
    };
    const dayIndices = dayIndicesByFreq[frequency];

    const week: WorkoutDay[] = [];
    for (let d = 0; d < 7; d++) {
      const slotIndex = dayIndices.indexOf(d);
      if (slotIndex !== -1) {
        const ppType = ppSlots[slotIndex];
        const template = TPL_PP[meso.block][ppType];
        const base = buildSession(POOL_PP, template, meso.month, boost);
        const exercises = adjustForWeekInBlock(base, meso.weekInBlock);
        week.push({
          type: ppType === "gentle_strength" ? "full_body" : "core_stability",
          label: PP_LABELS[ppType],
          emoji: PP_EMOJIS[ppType],
          exercises,
        });
      } else {
        week.push({ type: "rest", label: "Caminata suave o descanso", emoji: "🚶‍♀️", exercises: [] });
      }
    }
    return week;
  }

  // Ciclo regular
  let trainingSlots: Exclude<WorkoutType, "rest">[];
  let trainingDayIndices: number[];
  switch (frequency) {
    case 3:
      trainingSlots = ["full_body", "core_stability", "full_body"];
      trainingDayIndices = [0, 2, 4];
      break;
    case 4:
      trainingSlots = ["lower", "upper", "lower", "upper"];
      trainingDayIndices = [0, 1, 3, 4];
      break;
    case 5:
      trainingSlots = ["lower", "upper", "core_stability", "lower", "upper"];
      trainingDayIndices = [0, 1, 3, 4, 5];
      break;
  }

  const pool = level === "beginner" ? POOL_BEG : level === "advanced" ? POOL_ADV : POOL_INT;
  const tpl = level === "beginner" ? TPL_BEG : level === "advanced" ? TPL_ADV : TPL_INT;

  const week: WorkoutDay[] = [];
  for (let d = 0; d < 7; d++) {
    const slotIndex = trainingDayIndices.indexOf(d);
    if (slotIndex !== -1) {
      const type = trainingSlots[slotIndex];
      // Para que dos sesiones del mismo tipo en la misma semana no sean idénticas,
      // mezclamos el "mes efectivo" con el slot del día.
      const effectiveMonth = meso.month + slotIndex;
      const base = buildSession(pool, tpl[meso.block][type], effectiveMonth, boost);
      const withPhase = adjustForPhase(base, phase);
      const withProgression = adjustForWeekInBlock(withPhase, meso.weekInBlock);
      week.push({
        type,
        label: getWorkoutLabel(type),
        emoji: getWorkoutEmoji(type),
        exercises: withProgression,
      });
    } else {
      week.push({ type: "rest", label: "Descanso", emoji: "😴", exercises: [] });
    }
  }
  return week;
}

// ============================================================
// MENSAJES / GUÍAS
// ============================================================

export function getPhaseTrainingNote(phase: CyclePhase, mode: CycleMode = "cycle"): string {
  if (mode === "postpartum") {
    return "🤱 Post parto: respiración, core profundo, suelo pélvico y movilidad. Avanzas progresivamente y sin impacto.";
  }
  switch (phase) {
    case "menstrual":
      return "⚡ Fase menstrual: intensidad reducida y más descanso. Escucha tu cuerpo y prioriza técnica.";
    case "follicular":
      return "🌱 Fase folicular: tu energía sube. Buen momento para sumar tensión o reps con técnica limpia.";
    case "ovulatory":
      return "🔥 Fase ovulatoria: pico de fuerza. Usa la banda más fuerte o suma una serie con buen tempo.";
    case "luteal":
      return "🍂 Fase lútea: energía descendente. Mantén intensidad moderada y cuida el tempo de bajada.";
  }
}

export function getLevelTrainingTip(level: TrainingLevel): string {
  switch (level) {
    case "beginner":
      return "🌟 Principiante: aprende el patrón con tempo lento (bajada 3s). La técnica vale más que las repeticiones.";
    case "intermediate":
      return "💪 Intermedio: progresa de bloque en bloque (cada 4 semanas). Ajusta la banda o el tempo, no solo las reps.";
    case "advanced":
      return "🔥 Avanzado: juega con tempos excéntricos largos, isométricos y unilaterales pesados. Cuida la recuperación.";
  }
}

export function getPostpartumCardioTip(): string {
  return "🚶‍♀️ Cardio opcional: prioriza caminatas a ritmo ligero (20–30 min). Evita correr, saltos o impacto hasta tu alta médica.";
}

export function getRPEReminder(phase: CyclePhase, level: TrainingLevel, mode: CycleMode = "cycle"): string | null {
  if (level === "beginner" || mode === "postpartum") return null;
  const target = getTargetRPE(phase, mode);
  return `💡 Ajusta la tensión de la banda o la carga para que tu esfuerzo hoy sienta como RPE ${target.min}–${target.max} (${target.label.toLowerCase()}).`;
}

// ============================================================
// EXPORTS PARA HERRAMIENTAS DE CONTENIDO (lista de ejercicios)
// ============================================================
// Útil para generar el catálogo único de ejercicios a grabar en video.
export const ALL_POOLS = {
  beginner: POOL_BEG,
  intermediate: POOL_INT,
  advanced: POOL_ADV,
  postpartum: POOL_PP,
} as const;
