// Common food database with nutritional info per 100g
// Sources: Jumbo, Líder, Tottus, Santa Isabel (Chilean supermarkets)
export interface FoodItem {
  id: string;
  name: string;
  category: string;
  caloriesPer100g: number;
  proteinPer100g: number;
  carbsPer100g: number;
  fatPer100g: number;
  defaultPortionG: number;
  portionLabel: string;
  portionWeightG: number;
  source?: string; // supermarket source
}

export interface FoodLogEntry {
  id: string;
  foodId: string;
  foodName: string;
  mealType: 'breakfast' | 'lunch' | 'snack' | 'dinner';
  quantity: number;
  unit: 'g' | 'portion';
  portionLabel?: string;
  gramsConsumed: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  timestamp: number;
  date: string;
}

export const MEAL_LABELS: Record<string, string> = {
  breakfast: "Desayuno",
  lunch: "Almuerzo",
  snack: "Snack",
  dinner: "Cena",
};

export const MEAL_TIMES: Record<string, string> = {
  breakfast: "8:00 AM",
  lunch: "1:00 PM",
  snack: "4:30 PM",
  dinner: "8:00 PM",
};

export const FOOD_DATABASE: FoodItem[] = [
  // === PROTEÍNAS ===
  { id: "chicken_breast", name: "Pechuga de pollo", category: "Proteínas", caloriesPer100g: 165, proteinPer100g: 31, carbsPer100g: 0, fatPer100g: 3.6, defaultPortionG: 150, portionLabel: "filete", portionWeightG: 150, source: "Jumbo" },
  { id: "chicken_thigh", name: "Trutro de pollo", category: "Proteínas", caloriesPer100g: 209, proteinPer100g: 26, carbsPer100g: 0, fatPer100g: 11, defaultPortionG: 150, portionLabel: "unidad", portionWeightG: 150, source: "Líder" },
  { id: "salmon", name: "Salmón fresco", category: "Proteínas", caloriesPer100g: 208, proteinPer100g: 20, carbsPer100g: 0, fatPer100g: 13, defaultPortionG: 150, portionLabel: "filete", portionWeightG: 150, source: "Jumbo" },
  { id: "salmon_canned", name: "Salmón en lata", category: "Proteínas", caloriesPer100g: 167, proteinPer100g: 20, carbsPer100g: 0, fatPer100g: 9, defaultPortionG: 170, portionLabel: "lata", portionWeightG: 170, source: "Líder" },
  { id: "eggs", name: "Huevo", category: "Proteínas", caloriesPer100g: 155, proteinPer100g: 13, carbsPer100g: 1.1, fatPer100g: 11, defaultPortionG: 50, portionLabel: "unidad", portionWeightG: 50, source: "Santa Isabel" },
  { id: "tuna", name: "Atún en lata (agua)", category: "Proteínas", caloriesPer100g: 116, proteinPer100g: 26, carbsPer100g: 0, fatPer100g: 1, defaultPortionG: 160, portionLabel: "lata", portionWeightG: 160, source: "Líder" },
  { id: "tuna_oil", name: "Atún en aceite", category: "Proteínas", caloriesPer100g: 198, proteinPer100g: 29, carbsPer100g: 0, fatPer100g: 8, defaultPortionG: 160, portionLabel: "lata", portionWeightG: 160, source: "Jumbo" },
  { id: "greek_yogurt", name: "Yogur griego Nestlé", category: "Proteínas", caloriesPer100g: 97, proteinPer100g: 9, carbsPer100g: 3.6, fatPer100g: 5, defaultPortionG: 170, portionLabel: "vaso", portionWeightG: 170, source: "Jumbo" },
  { id: "yogurt_protein", name: "Yogur proteico Loncoleche", category: "Proteínas", caloriesPer100g: 62, proteinPer100g: 10, carbsPer100g: 4, fatPer100g: 0.5, defaultPortionG: 150, portionLabel: "vaso", portionWeightG: 150, source: "Tottus" },
  { id: "whey_protein", name: "Proteína whey", category: "Proteínas", caloriesPer100g: 380, proteinPer100g: 75, carbsPer100g: 10, fatPer100g: 5, defaultPortionG: 30, portionLabel: "scoop", portionWeightG: 30 },
  { id: "beef", name: "Carne de res magra", category: "Proteínas", caloriesPer100g: 250, proteinPer100g: 26, carbsPer100g: 0, fatPer100g: 15, defaultPortionG: 150, portionLabel: "filete", portionWeightG: 150, source: "Líder" },
  { id: "ground_beef", name: "Carne molida especial", category: "Proteínas", caloriesPer100g: 212, proteinPer100g: 21, carbsPer100g: 0, fatPer100g: 14, defaultPortionG: 150, portionLabel: "porción", portionWeightG: 150, source: "Jumbo" },
  { id: "turkey", name: "Pavo molido", category: "Proteínas", caloriesPer100g: 135, proteinPer100g: 30, carbsPer100g: 0, fatPer100g: 1, defaultPortionG: 100, portionLabel: "porción", portionWeightG: 100, source: "Tottus" },
  { id: "turkey_breast_deli", name: "Pechuga de pavo (fiambre)", category: "Proteínas", caloriesPer100g: 104, proteinPer100g: 17, carbsPer100g: 2, fatPer100g: 3, defaultPortionG: 50, portionLabel: "porción", portionWeightG: 50, source: "Santa Isabel" },
  { id: "merluza", name: "Merluza", category: "Proteínas", caloriesPer100g: 90, proteinPer100g: 18, carbsPer100g: 0, fatPer100g: 1.5, defaultPortionG: 150, portionLabel: "filete", portionWeightG: 150, source: "Líder" },
  { id: "reineta", name: "Reineta", category: "Proteínas", caloriesPer100g: 95, proteinPer100g: 19, carbsPer100g: 0, fatPer100g: 2, defaultPortionG: 150, portionLabel: "filete", portionWeightG: 150, source: "Jumbo" },
  { id: "tofu", name: "Tofu firme", category: "Proteínas", caloriesPer100g: 144, proteinPer100g: 15, carbsPer100g: 3, fatPer100g: 8, defaultPortionG: 100, portionLabel: "porción", portionWeightG: 100, source: "Tottus" },
  { id: "cottage_cheese", name: "Queso cottage", category: "Proteínas", caloriesPer100g: 98, proteinPer100g: 11, carbsPer100g: 3.4, fatPer100g: 4.3, defaultPortionG: 100, portionLabel: "porción", portionWeightG: 100, source: "Jumbo" },

  // === CARBOHIDRATOS ===
  { id: "rice", name: "Arroz blanco (cocido)", category: "Carbohidratos", caloriesPer100g: 130, proteinPer100g: 2.7, carbsPer100g: 28, fatPer100g: 0.3, defaultPortionG: 150, portionLabel: "taza", portionWeightG: 150, source: "Líder" },
  { id: "brown_rice", name: "Arroz integral (cocido)", category: "Carbohidratos", caloriesPer100g: 123, proteinPer100g: 2.7, carbsPer100g: 26, fatPer100g: 1, defaultPortionG: 150, portionLabel: "taza", portionWeightG: 150, source: "Jumbo" },
  { id: "oats", name: "Avena Quaker", category: "Carbohidratos", caloriesPer100g: 389, proteinPer100g: 17, carbsPer100g: 66, fatPer100g: 7, defaultPortionG: 40, portionLabel: "taza", portionWeightG: 40, source: "Líder" },
  { id: "bread_integral", name: "Pan integral Ideal", category: "Carbohidratos", caloriesPer100g: 247, proteinPer100g: 13, carbsPer100g: 41, fatPer100g: 3.4, defaultPortionG: 30, portionLabel: "rebanada", portionWeightG: 30, source: "Jumbo" },
  { id: "bread_molde", name: "Pan de molde Bimbo", category: "Carbohidratos", caloriesPer100g: 265, proteinPer100g: 8, carbsPer100g: 49, fatPer100g: 3.5, defaultPortionG: 28, portionLabel: "rebanada", portionWeightG: 28, source: "Líder" },
  { id: "marraqueta", name: "Marraqueta", category: "Carbohidratos", caloriesPer100g: 280, proteinPer100g: 9, carbsPer100g: 55, fatPer100g: 1.5, defaultPortionG: 100, portionLabel: "unidad", portionWeightG: 100, source: "Santa Isabel" },
  { id: "hallulla", name: "Hallulla", category: "Carbohidratos", caloriesPer100g: 320, proteinPer100g: 8, carbsPer100g: 52, fatPer100g: 9, defaultPortionG: 90, portionLabel: "unidad", portionWeightG: 90, source: "Tottus" },
  { id: "pasta_cooked", name: "Pasta (cocida)", category: "Carbohidratos", caloriesPer100g: 131, proteinPer100g: 5, carbsPer100g: 25, fatPer100g: 1.1, defaultPortionG: 200, portionLabel: "plato", portionWeightG: 200, source: "Líder" },
  { id: "quinoa_cooked", name: "Quinoa (cocida)", category: "Carbohidratos", caloriesPer100g: 120, proteinPer100g: 4.4, carbsPer100g: 21, fatPer100g: 1.9, defaultPortionG: 150, portionLabel: "taza", portionWeightG: 150, source: "Jumbo" },
  { id: "potato", name: "Papa", category: "Carbohidratos", caloriesPer100g: 77, proteinPer100g: 2, carbsPer100g: 17, fatPer100g: 0.1, defaultPortionG: 150, portionLabel: "unidad", portionWeightG: 150, source: "Santa Isabel" },
  { id: "sweet_potato", name: "Camote", category: "Carbohidratos", caloriesPer100g: 86, proteinPer100g: 1.6, carbsPer100g: 20, fatPer100g: 0.1, defaultPortionG: 150, portionLabel: "unidad", portionWeightG: 150, source: "Líder" },
  { id: "banana", name: "Plátano", category: "Carbohidratos", caloriesPer100g: 89, proteinPer100g: 1.1, carbsPer100g: 23, fatPer100g: 0.3, defaultPortionG: 120, portionLabel: "unidad", portionWeightG: 120 },
  { id: "apple", name: "Manzana", category: "Carbohidratos", caloriesPer100g: 52, proteinPer100g: 0.3, carbsPer100g: 14, fatPer100g: 0.2, defaultPortionG: 180, portionLabel: "unidad", portionWeightG: 180 },
  { id: "wrap_integral", name: "Tortilla integral Mission", category: "Carbohidratos", caloriesPer100g: 290, proteinPer100g: 8, carbsPer100g: 43, fatPer100g: 9, defaultPortionG: 45, portionLabel: "unidad", portionWeightG: 45, source: "Jumbo" },
  { id: "granola", name: "Granola Nature's Heart", category: "Carbohidratos", caloriesPer100g: 440, proteinPer100g: 10, carbsPer100g: 62, fatPer100g: 17, defaultPortionG: 40, portionLabel: "porción", portionWeightG: 40, source: "Jumbo" },
  { id: "cereal_fitness", name: "Cereal Fitness Nestlé", category: "Carbohidratos", caloriesPer100g: 357, proteinPer100g: 9, carbsPer100g: 72, fatPer100g: 2, defaultPortionG: 30, portionLabel: "porción", portionWeightG: 30, source: "Líder" },

  // === GRASAS ===
  { id: "avocado", name: "Palta", category: "Grasas", caloriesPer100g: 160, proteinPer100g: 2, carbsPer100g: 9, fatPer100g: 15, defaultPortionG: 80, portionLabel: "mitad", portionWeightG: 80 },
  { id: "olive_oil", name: "Aceite de oliva", category: "Grasas", caloriesPer100g: 884, proteinPer100g: 0, carbsPer100g: 0, fatPer100g: 100, defaultPortionG: 15, portionLabel: "cucharada", portionWeightG: 15, source: "Jumbo" },
  { id: "almonds", name: "Almendras", category: "Grasas", caloriesPer100g: 579, proteinPer100g: 21, carbsPer100g: 22, fatPer100g: 50, defaultPortionG: 30, portionLabel: "puñado", portionWeightG: 30, source: "Líder" },
  { id: "peanut_butter", name: "Mantequilla de maní", category: "Grasas", caloriesPer100g: 588, proteinPer100g: 25, carbsPer100g: 20, fatPer100g: 50, defaultPortionG: 32, portionLabel: "cucharada", portionWeightG: 32, source: "Tottus" },
  { id: "cheese_fresco", name: "Queso fresco Colún", category: "Grasas", caloriesPer100g: 264, proteinPer100g: 18, carbsPer100g: 3, fatPer100g: 21, defaultPortionG: 30, portionLabel: "tajada", portionWeightG: 30, source: "Jumbo" },
  { id: "cheese_gouda", name: "Queso gouda", category: "Grasas", caloriesPer100g: 356, proteinPer100g: 25, carbsPer100g: 2, fatPer100g: 27, defaultPortionG: 30, portionLabel: "lámina", portionWeightG: 30, source: "Líder" },
  { id: "walnuts", name: "Nueces", category: "Grasas", caloriesPer100g: 654, proteinPer100g: 15, carbsPer100g: 14, fatPer100g: 65, defaultPortionG: 30, portionLabel: "puñado", portionWeightG: 30, source: "Santa Isabel" },
  { id: "chia_seeds", name: "Semillas de chía", category: "Grasas", caloriesPer100g: 486, proteinPer100g: 17, carbsPer100g: 42, fatPer100g: 31, defaultPortionG: 15, portionLabel: "cucharada", portionWeightG: 15, source: "Jumbo" },
  { id: "linaza", name: "Linaza molida", category: "Grasas", caloriesPer100g: 534, proteinPer100g: 18, carbsPer100g: 29, fatPer100g: 42, defaultPortionG: 10, portionLabel: "cucharada", portionWeightG: 10, source: "Tottus" },

  // === VERDURAS ===
  { id: "broccoli", name: "Brócoli", category: "Verduras", caloriesPer100g: 34, proteinPer100g: 2.8, carbsPer100g: 7, fatPer100g: 0.4, defaultPortionG: 100, portionLabel: "taza", portionWeightG: 100 },
  { id: "spinach", name: "Espinaca", category: "Verduras", caloriesPer100g: 23, proteinPer100g: 2.9, carbsPer100g: 3.6, fatPer100g: 0.4, defaultPortionG: 50, portionLabel: "taza", portionWeightG: 50 },
  { id: "tomato", name: "Tomate", category: "Verduras", caloriesPer100g: 18, proteinPer100g: 0.9, carbsPer100g: 3.9, fatPer100g: 0.2, defaultPortionG: 120, portionLabel: "unidad", portionWeightG: 120 },
  { id: "mixed_salad", name: "Ensalada mixta", category: "Verduras", caloriesPer100g: 20, proteinPer100g: 1.5, carbsPer100g: 3, fatPer100g: 0.3, defaultPortionG: 150, portionLabel: "plato", portionWeightG: 150 },
  { id: "palta_ensalada", name: "Lechuga", category: "Verduras", caloriesPer100g: 15, proteinPer100g: 1.4, carbsPer100g: 2.9, fatPer100g: 0.2, defaultPortionG: 80, portionLabel: "taza", portionWeightG: 80 },
  { id: "zucchini", name: "Zapallo italiano", category: "Verduras", caloriesPer100g: 17, proteinPer100g: 1.2, carbsPer100g: 3.1, fatPer100g: 0.3, defaultPortionG: 150, portionLabel: "unidad", portionWeightG: 150 },
  { id: "pepino", name: "Pepino", category: "Verduras", caloriesPer100g: 15, proteinPer100g: 0.7, carbsPer100g: 3.6, fatPer100g: 0.1, defaultPortionG: 150, portionLabel: "unidad", portionWeightG: 150 },
  { id: "champiñones", name: "Champiñones", category: "Verduras", caloriesPer100g: 22, proteinPer100g: 3.1, carbsPer100g: 3.3, fatPer100g: 0.3, defaultPortionG: 100, portionLabel: "taza", portionWeightG: 100, source: "Jumbo" },
  { id: "zanahoria", name: "Zanahoria", category: "Verduras", caloriesPer100g: 41, proteinPer100g: 0.9, carbsPer100g: 10, fatPer100g: 0.2, defaultPortionG: 80, portionLabel: "unidad", portionWeightG: 80 },
  { id: "pimenton", name: "Pimentón rojo", category: "Verduras", caloriesPer100g: 31, proteinPer100g: 1, carbsPer100g: 6, fatPer100g: 0.3, defaultPortionG: 120, portionLabel: "unidad", portionWeightG: 120 },

  // === LÁCTEOS ===
  { id: "milk", name: "Leche entera Colún", category: "Lácteos", caloriesPer100g: 61, proteinPer100g: 3.2, carbsPer100g: 4.8, fatPer100g: 3.3, defaultPortionG: 250, portionLabel: "vaso", portionWeightG: 250, source: "Jumbo" },
  { id: "skim_milk", name: "Leche descremada Colún", category: "Lácteos", caloriesPer100g: 34, proteinPer100g: 3.4, carbsPer100g: 5, fatPer100g: 0.1, defaultPortionG: 250, portionLabel: "vaso", portionWeightG: 250, source: "Líder" },
  { id: "leche_almendras", name: "Leche de almendras", category: "Lácteos", caloriesPer100g: 17, proteinPer100g: 0.6, carbsPer100g: 0.3, fatPer100g: 1.1, defaultPortionG: 250, portionLabel: "vaso", portionWeightG: 250, source: "Jumbo" },
  { id: "yogurt_natural", name: "Yogur natural Soprole", category: "Lácteos", caloriesPer100g: 63, proteinPer100g: 4, carbsPer100g: 5, fatPer100g: 3, defaultPortionG: 175, portionLabel: "pote", portionWeightG: 175, source: "Líder" },

  // === SNACKS SALUDABLES ===
  { id: "dark_chocolate", name: "Chocolate negro 70% Sahne Nuss", category: "Snacks", caloriesPer100g: 598, proteinPer100g: 8, carbsPer100g: 46, fatPer100g: 43, defaultPortionG: 20, portionLabel: "onza", portionWeightG: 20, source: "Jumbo" },
  { id: "berries", name: "Frutos rojos (mix)", category: "Snacks", caloriesPer100g: 57, proteinPer100g: 0.7, carbsPer100g: 14, fatPer100g: 0.3, defaultPortionG: 100, portionLabel: "taza", portionWeightG: 100 },
  { id: "honey", name: "Miel", category: "Snacks", caloriesPer100g: 304, proteinPer100g: 0.3, carbsPer100g: 82, fatPer100g: 0, defaultPortionG: 21, portionLabel: "cucharada", portionWeightG: 21 },
  { id: "rice_cakes", name: "Galletas de arroz", category: "Snacks", caloriesPer100g: 387, proteinPer100g: 8, carbsPer100g: 82, fatPer100g: 3, defaultPortionG: 10, portionLabel: "unidad", portionWeightG: 10, source: "Tottus" },
  { id: "frutos_secos_mix", name: "Mix frutos secos", category: "Snacks", caloriesPer100g: 607, proteinPer100g: 20, carbsPer100g: 17, fatPer100g: 54, defaultPortionG: 30, portionLabel: "puñado", portionWeightG: 30, source: "Jumbo" },
  { id: "barra_cereal", name: "Barra de cereal Nature Valley", category: "Snacks", caloriesPer100g: 471, proteinPer100g: 6, carbsPer100g: 64, fatPer100g: 20, defaultPortionG: 42, portionLabel: "barra", portionWeightG: 42, source: "Líder" },

  // === LEGUMBRES ===
  { id: "lentils", name: "Lentejas (cocidas)", category: "Legumbres", caloriesPer100g: 116, proteinPer100g: 9, carbsPer100g: 20, fatPer100g: 0.4, defaultPortionG: 150, portionLabel: "taza", portionWeightG: 150, source: "Santa Isabel" },
  { id: "chickpeas", name: "Garbanzos (cocidos)", category: "Legumbres", caloriesPer100g: 164, proteinPer100g: 9, carbsPer100g: 27, fatPer100g: 2.6, defaultPortionG: 150, portionLabel: "taza", portionWeightG: 150, source: "Líder" },
  { id: "black_beans", name: "Porotos negros (cocidos)", category: "Legumbres", caloriesPer100g: 132, proteinPer100g: 9, carbsPer100g: 24, fatPer100g: 0.5, defaultPortionG: 150, portionLabel: "taza", portionWeightG: 150, source: "Tottus" },
  { id: "porotos_granados", name: "Porotos granados", category: "Legumbres", caloriesPer100g: 115, proteinPer100g: 7, carbsPer100g: 20, fatPer100g: 0.5, defaultPortionG: 200, portionLabel: "plato", portionWeightG: 200, source: "Santa Isabel" },

  // === BEBIDAS Y OTROS ===
  { id: "cafe_solo", name: "Café solo (sin azúcar)", category: "Bebidas", caloriesPer100g: 2, proteinPer100g: 0.1, carbsPer100g: 0, fatPer100g: 0, defaultPortionG: 240, portionLabel: "taza", portionWeightG: 240 },
  { id: "te_verde", name: "Té verde", category: "Bebidas", caloriesPer100g: 1, proteinPer100g: 0, carbsPer100g: 0.2, fatPer100g: 0, defaultPortionG: 240, portionLabel: "taza", portionWeightG: 240 },
  { id: "jugo_naranja", name: "Jugo de naranja natural", category: "Bebidas", caloriesPer100g: 45, proteinPer100g: 0.7, carbsPer100g: 10, fatPer100g: 0.2, defaultPortionG: 250, portionLabel: "vaso", portionWeightG: 250 },

  // === CONDIMENTOS / SALSAS ===
  { id: "hummus", name: "Hummus", category: "Salsas", caloriesPer100g: 166, proteinPer100g: 8, carbsPer100g: 14, fatPer100g: 10, defaultPortionG: 30, portionLabel: "cucharada", portionWeightG: 30, source: "Jumbo" },
  { id: "salsa_tomate", name: "Salsa de tomate natural", category: "Salsas", caloriesPer100g: 29, proteinPer100g: 1, carbsPer100g: 5, fatPer100g: 0.5, defaultPortionG: 50, portionLabel: "porción", portionWeightG: 50 },
];

export function calculateFoodMacros(food: FoodItem, gramsConsumed: number) {
  const factor = gramsConsumed / 100;
  return {
    calories: Math.round(food.caloriesPer100g * factor),
    protein: Math.round(food.proteinPer100g * factor * 10) / 10,
    carbs: Math.round(food.carbsPer100g * factor * 10) / 10,
    fat: Math.round(food.fatPer100g * factor * 10) / 10,
  };
}

export function getTodayKey(): string {
  return new Date().toISOString().split('T')[0];
}

export function saveFoodLog(entries: FoodLogEntry[]) {
  localStorage.setItem('lunafit_food_log', JSON.stringify(entries));
}

export function loadFoodLog(): FoodLogEntry[] {
  const raw = localStorage.getItem('lunafit_food_log');
  if (!raw) return [];
  try { return JSON.parse(raw); } catch { return []; }
}

export function getTodayEntries(entries: FoodLogEntry[]): FoodLogEntry[] {
  const today = getTodayKey();
  return entries.filter(e => e.date === today);
}

export function getTodayTotals(entries: FoodLogEntry[]) {
  const today = getTodayEntries(entries);
  return {
    calories: today.reduce((s, e) => s + e.calories, 0),
    protein: Math.round(today.reduce((s, e) => s + e.protein, 0) * 10) / 10,
    carbs: Math.round(today.reduce((s, e) => s + e.carbs, 0) * 10) / 10,
    fat: Math.round(today.reduce((s, e) => s + e.fat, 0) * 10) / 10,
  };
}

export function getEntriesByMeal(entries: FoodLogEntry[]): Record<string, FoodLogEntry[]> {
  const today = getTodayEntries(entries);
  const grouped: Record<string, FoodLogEntry[]> = { breakfast: [], lunch: [], snack: [], dinner: [] };
  today.forEach(e => {
    if (!grouped[e.mealType]) grouped[e.mealType] = [];
    grouped[e.mealType].push(e);
  });
  return grouped;
}
