/**
 * Catálogo de videos por ejercicio.
 *
 * - El admin puede gestionar todos los enlaces desde /admin/videos.
 * - Los datos se guardan en la tabla `exercise_videos` de la base de datos.
 * - VIDEO_OVERRIDES queda como fallback estático opcional (vacío por defecto).
 */
import { useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ALL_POOLS } from "@/lib/training";

export type VideoSource = "youtube" | "vimeo";

export interface ExerciseVideo {
  source: VideoSource;
  id: string;
}

// Fallback estático (opcional, dejar vacío y administrar todo desde el panel).
export const VIDEO_OVERRIDES: Record<string, ExerciseVideo> = {};

// ---------- Cache reactiva en memoria ----------
let cache: Record<string, ExerciseVideo> = {};
let version = 0;
const listeners = new Set<() => void>();

function emit() {
  version++;
  listeners.forEach((l) => l());
}

export function subscribeExerciseVideos(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function getExerciseVideosVersion() {
  return version;
}

export function useExerciseVideosVersion() {
  return useSyncExternalStore(subscribeExerciseVideos, getExerciseVideosVersion, getExerciseVideosVersion);
}

// ---------- Resolver sincrónico ----------
export function resolveExerciseVideo(
  exerciseName: string,
  fallbackVimeoId?: string,
): ExerciseVideo | null {
  const fromDb = cache[exerciseName];
  if (fromDb) return fromDb;
  const fromFile = VIDEO_OVERRIDES[exerciseName];
  if (fromFile) return fromFile;
  if (fallbackVimeoId) return { source: "vimeo", id: fallbackVimeoId };
  return null;
}

// ---------- IO ----------
export async function loadExerciseVideos() {
  const { data, error } = await supabase
    .from("exercise_videos")
    .select("exercise_name, source, video_id");
  if (error) return;
  const next: Record<string, ExerciseVideo> = {};
  (data ?? []).forEach((r: any) => {
    next[r.exercise_name] = { source: r.source as VideoSource, id: r.video_id };
  });
  cache = next;
  emit();
}

export async function upsertExerciseVideo(exerciseName: string, video: ExerciseVideo) {
  const { error } = await supabase.from("exercise_videos").upsert({
    exercise_name: exerciseName,
    source: video.source,
    video_id: video.id,
  });
  if (error) throw error;
  cache = { ...cache, [exerciseName]: video };
  emit();
}

export async function deleteExerciseVideo(exerciseName: string) {
  const { error } = await supabase
    .from("exercise_videos")
    .delete()
    .eq("exercise_name", exerciseName);
  if (error) throw error;
  const next = { ...cache };
  delete next[exerciseName];
  cache = next;
  emit();
}

export function getAllExerciseVideos(): Record<string, ExerciseVideo> {
  return cache;
}

// ---------- Catálogo único de ejercicios desde los pools de training ----------
export interface CatalogEntry {
  name: string;
  levels: string[]; // beginner / intermediate / advanced / postpartum
}

export function getExerciseCatalog(): CatalogEntry[] {
  const map = new Map<string, Set<string>>();
  (Object.entries(ALL_POOLS) as [string, any][]).forEach(([level, pools]) => {
    Object.values(pools).forEach((pool: any) => {
      (pool as any[]).forEach((ex) => {
        if (!map.has(ex.name)) map.set(ex.name, new Set());
        map.get(ex.name)!.add(level);
      });
    });
  });
  return Array.from(map.entries())
    .map(([name, levels]) => ({ name, levels: Array.from(levels) }))
    .sort((a, b) => a.name.localeCompare(b.name, "es"));
}

/**
 * Acepta URL completa o ID. Devuelve { source, id } o null.
 */
export function parseVideoUrl(input: string): ExerciseVideo | null {
  const s = input.trim();
  if (!s) return null;
  // YouTube
  const yt =
    s.match(/youtube\.com\/watch\?v=([\w-]{6,})/) ||
    s.match(/youtu\.be\/([\w-]{6,})/) ||
    s.match(/youtube\.com\/shorts\/([\w-]{6,})/) ||
    s.match(/youtube\.com\/embed\/([\w-]{6,})/);
  if (yt) return { source: "youtube", id: yt[1] };
  // Vimeo
  const vm = s.match(/vimeo\.com\/(?:video\/)?(\d{4,})/);
  if (vm) return { source: "vimeo", id: vm[1] };
  // ID puro: solo dígitos -> Vimeo, alfanumérico -> YouTube
  if (/^\d{4,}$/.test(s)) return { source: "vimeo", id: s };
  if (/^[\w-]{6,}$/.test(s)) return { source: "youtube", id: s };
  return null;
}
