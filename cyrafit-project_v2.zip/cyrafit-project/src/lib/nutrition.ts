// Nutrition calculator based on Mifflin-St Jeor, Devine ideal weight, and adjusted weight

export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'intense' | 'very_intense';
export type Goal = 'fat_loss_light' | 'fat_loss_moderate' | 'recomposition' | 'muscle_gain';
export type BmiCategory = 'underweight' | 'normal' | 'overweight' | 'obese';

export interface NutritionProfile {
  name?: string;
  age: number;
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: Goal;
}

export interface NutritionResult {
  bmi: number;
  bmiCategory: BmiCategory;
  idealWeight: number;
  adjustedWeight: number | null;
  bmr: number;
  tdee: number;
  targetCalories: number;
  proteinG: number;
  fatG: number;
  carbsG: number;
  proteinKcal: number;
  fatKcal: number;
  carbsKcal: number;
}

const ACTIVITY_FACTORS: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  intense: 1.725,
  very_intense: 1.9,
};

export const ACTIVITY_LABELS: Record<ActivityLevel, string> = {
  sedentary: 'Sedentario',
  light: 'Ligero (1-3 días/sem)',
  moderate: 'Moderado (3-5 días/sem)',
  intense: 'Intenso (6-7 días/sem)',
  very_intense: 'Muy intenso (2x/día)',
};

export const GOAL_LABELS: Record<Goal, string> = {
  fat_loss_light: 'Pérdida de grasa ligera',
  fat_loss_moderate: 'Pérdida de grasa moderada',
  recomposition: 'Recomposición corporal',
  muscle_gain: 'Aumento de masa muscular',
};

export function calculateBmi(weightKg: number, heightCm: number): number {
  const heightM = heightCm / 100;
  return weightKg / (heightM * heightM);
}

export function getBmiCategory(bmi: number): BmiCategory {
  if (bmi < 18.5) return 'underweight';
  if (bmi < 25) return 'normal';
  if (bmi < 30) return 'overweight';
  return 'obese';
}

// Devine formula for women: 45.5 + 0.9 * (heightCm - 150)
export function calculateIdealWeight(heightCm: number): number {
  if (heightCm <= 150) return 45.5;
  return 45.5 + 0.9 * (heightCm - 150);
}

// Adjusted weight = ideal + 0.4 * (real - ideal)
export function calculateAdjustedWeight(realWeight: number, idealWeight: number): number {
  return idealWeight + 0.4 * (realWeight - idealWeight);
}

// Mifflin-St Jeor for women: (10 * weight) + (6.25 * height) - (5 * age) - 161
export function calculateBmr(weightKg: number, heightCm: number, age: number): number {
  return (10 * weightKg) + (6.25 * heightCm) - (5 * age) - 161;
}

export function calculateNutrition(profile: NutritionProfile): NutritionResult {
  const { age, heightCm, weightKg, activityLevel, goal } = profile;

  const bmi = calculateBmi(weightKg, heightCm);
  const bmiCategory = getBmiCategory(bmi);
  const idealWeight = calculateIdealWeight(heightCm);

  const isOverweight = bmiCategory === 'overweight' || bmiCategory === 'obese';
  const adjustedWeight = isOverweight ? calculateAdjustedWeight(weightKg, idealWeight) : null;

  // Use adjusted weight for overweight/obese, real weight for normal
  const formulaWeight = isOverweight ? adjustedWeight! : weightKg;
  const macroWeight = isOverweight ? adjustedWeight! : weightKg;

  const bmr = calculateBmr(formulaWeight, heightCm, age);
  const tdee = bmr * ACTIVITY_FACTORS[activityLevel];

  // Macros calculation
  let proteinG: number;
  let fatG: number;
  let carbsKcal: number;

  if (goal === 'muscle_gain') {
    // Only valid for normal BMI - use 1.7g protein, 1g fat, rest carbs + 300kcal
    proteinG = 1.7 * macroWeight;
    fatG = 1.0 * macroWeight;
    const proteinKcal = proteinG * 4;
    const fatKcal = fatG * 9;
    carbsKcal = (tdee - proteinKcal - fatKcal) + 300;
  } else {
    // Fat loss or recomposition: 1.7g protein, 0.8g fat
    proteinG = 1.7 * macroWeight;
    fatG = 0.8 * macroWeight;
    const proteinKcal = proteinG * 4;
    const fatKcal = fatG * 9;
    carbsKcal = tdee - proteinKcal - fatKcal;

    if (goal === 'fat_loss_light') {
      carbsKcal -= 300;
    } else if (goal === 'fat_loss_moderate') {
      carbsKcal -= 500;
    }
    // recomposition: no change
  }

  if (carbsKcal < 0) carbsKcal = 0;
  const carbsG = carbsKcal / 4;
  const proteinKcal = proteinG * 4;
  const fatKcal = fatG * 9;
  let targetCalories = proteinKcal + fatKcal + carbsKcal;

  // MINIMUM 1300 kcal — never recommend less
  if (targetCalories < 1300) {
    const deficit = 1300 - targetCalories;
    carbsKcal += deficit;
    targetCalories = 1300;
  }

  return {
    bmi: Math.round(bmi * 10) / 10,
    bmiCategory,
    idealWeight: Math.round(idealWeight * 10) / 10,
    adjustedWeight: adjustedWeight ? Math.round(adjustedWeight * 10) / 10 : null,
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    targetCalories: Math.round(targetCalories),
    proteinG: Math.round(proteinG),
    fatG: Math.round(fatG),
    carbsG: Math.round(carbsG),
    proteinKcal: Math.round(proteinKcal),
    fatKcal: Math.round(fatKcal),
    carbsKcal: Math.round(carbsKcal),
  };
}

export function getBmiLabel(category: BmiCategory): string {
  switch (category) {
    case 'underweight': return 'Bajo peso';
    case 'normal': return 'Normopeso';
    case 'overweight': return 'Sobrepeso';
    case 'obese': return 'Obesidad';
  }
}

export function saveNutritionProfile(profile: NutritionProfile) {
  localStorage.setItem('lunafit_nutrition_profile', JSON.stringify(profile));
}

export function loadNutritionProfile(): NutritionProfile | null {
  const raw = localStorage.getItem('lunafit_nutrition_profile');
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}
