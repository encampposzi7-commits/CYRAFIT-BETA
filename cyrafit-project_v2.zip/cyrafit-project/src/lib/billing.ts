/**
 * Billing adapter — abstracción del proveedor de pagos.
 * Reemplazar `placeholderAdapter` por Google Play Billing cuando se integre.
 */
import { supabase } from "@/integrations/supabase/client";

export type BillingProduct = {
  id: string;
  title: string;
  description: string;
  priceLabel: string;
  period: "monthly" | "yearly" | "lifetime";
};

export type PurchaseResult = {
  success: boolean;
  error?: string;
  productId?: string;
  purchaseToken?: string;
  expiresAt?: string | null;
};

export type BillingAdapter = {
  listProducts(): Promise<BillingProduct[]>;
  purchase(productId: string): Promise<PurchaseResult>;
  restore(): Promise<PurchaseResult>;
};

export const PREMIUM_PRODUCTS: BillingProduct[] = [
  { id: "cyrafit_premium_monthly", title: "Plan mensual", description: "Renovación mensual", priceLabel: "$12.990 / mes", period: "monthly" },
  { id: "cyrafit_premium_yearly", title: "Plan anual", description: "Ahorra $36.000 · Equivale a $9.990/mes", priceLabel: "$119.880 / año", period: "yearly" },
];

export const placeholderAdapter: BillingAdapter = {
  async listProducts() { return PREMIUM_PRODUCTS; },
  async purchase(productId) {
    return { success: false, error: "Google Play Billing aún no está disponible.", productId };
  },
  async restore() { return { success: false, error: "Restauración no disponible aún." }; },
};

export const billing: BillingAdapter = placeholderAdapter;

export async function setTestPremium(userId: string, enable: boolean) {
  const { data, error } = await supabase.rpc("set_premium_status", {
    _user_id: userId,
    _is_premium: enable,
    _source: "test",
    _expires_at: enable ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null,
    _product_id: enable ? "test_premium" : null,
    _purchase_token: null,
    _is_test: true,
  });
  if (error) return { success: false, error: error.message };
  return { success: !!data };
}
