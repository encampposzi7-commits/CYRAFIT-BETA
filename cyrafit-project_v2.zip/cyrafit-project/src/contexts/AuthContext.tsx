import { createContext, useContext, useEffect, useState, type Context, type ReactNode } from "react";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

interface UserProfile {
  id: string;
  name: string;
  email: string;
  birth_date: string;
}

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signUp: (email: string, password: string) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signInWithGoogle: () => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  saveProfile: (data: { name: string; birth_date: string }) => Promise<{ error: any; data?: UserProfile | null }>;
  refreshProfile: () => Promise<void>;
}

declare global {
  var __cyra_auth_context__: Context<AuthContextType | undefined> | undefined;
}

const AuthContext = globalThis.__cyra_auth_context__ ?? createContext<AuthContextType | undefined>(undefined);

globalThis.__cyra_auth_context__ = AuthContext;

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string) => {
    try {
      console.info("[Auth] Fetching profile", { userId });

      const { data, error } = await supabase
        .from("profile")
        .select("id, name, email, birth_date")
        .eq("id", userId)
        .maybeSingle();

      if (error) {
        console.error("[Auth] Failed to fetch profile", { userId, message: error.message });
        setProfile(null);
        return null;
      }

      setProfile(data);
      console.info("[Auth] Profile fetch completed", { userId, found: !!data });
      return data;
    } catch (error) {
      console.error("[Auth] Unexpected profile fetch error", error);
      setProfile(null);
      return null;
    }
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          void fetchProfile(session.user.id).finally(() => setLoading(false));
        } else {
          setProfile(null);
          setLoading(false);
        }
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        void fetchProfile(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    }).catch(() => {
      setLoading(false);
    });

    const timeout = setTimeout(() => setLoading(false), 5000);
    return () => {
      subscription.unsubscribe();
      clearTimeout(timeout);
    };
  }, []);

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: window.location.origin },
    });
    return { error };
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error };
  };

  const signInWithGoogle = async () => {
    // En Web → OAuth redirect tradicional.
    // En Android/iOS → selector nativo de cuentas vía @capgo/capacitor-social-login.
    const { googleSignIn } = await import("@/lib/googleAuth");
    return await googleSignIn();
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setProfile(null);
    localStorage.removeItem("cyra_welcomed");
    sessionStorage.removeItem("cyra_admin_choice");
  };

  const saveProfile = async (data: { name: string; birth_date: string }) => {
    if (!user) return { error: "No user" };

    // Validate date format YYYY-MM-DD
    const dateMatch = data.birth_date.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!dateMatch) {
      return { error: "Fecha inválida. Usa formato YYYY-MM-DD." };
    }
    const testDate = new Date(Date.UTC(+dateMatch[1], +dateMatch[2] - 1, +dateMatch[3]));
    if (testDate.getUTCFullYear() !== +dateMatch[1] || testDate.getUTCMonth() !== +dateMatch[2] - 1 || testDate.getUTCDate() !== +dateMatch[3]) {
      return { error: "Fecha inválida." };
    }

    const profilePayload = {
      id: user.id,
      name: data.name.trim(),
      email: user.email || "",
      birth_date: data.birth_date,
    };

    console.info("[Auth] Saving profile", profilePayload);

    try {
      const { error } = await supabase
        .from("profile")
        .upsert(profilePayload, { onConflict: "id" });

      if (error) {
        console.error("[Auth] Profile save failed", error.message, error.details, error.hint);
        return { error: error.message, data: null };
      }

      setProfile(profilePayload);
      console.info("[Auth] Profile saved successfully");
      return { error: null, data: profilePayload };
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Error inesperado al guardar perfil";
      console.error("[Auth] Unexpected profile save error", err);
      return { error: msg, data: null };
    }
  };

  const refreshProfile = async () => {
    if (user) await fetchProfile(user.id);
  };

  return (
    <AuthContext.Provider
      value={{
        session, user, profile, loading,
        signUp, signIn, signInWithGoogle, signOut,
        saveProfile, refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
