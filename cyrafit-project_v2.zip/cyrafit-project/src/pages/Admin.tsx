import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Users, Crown, Activity, Dumbbell, TrendingUp, Search,
  Download, ArrowLeft, Sparkles, Smartphone, Heart, Trash2, ShieldCheck, ShieldOff, Video,
} from "lucide-react";
import { toast } from "sonner";

import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip,
  PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend,
} from "recharts";
import { format, subDays, startOfDay } from "date-fns";
import { es } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type Profile = {
  id: string;
  name: string | null;
  email: string | null;
  birth_date: string | null;
  is_premium: boolean;
  premium_source: string | null;
  created_at: string;
};
type Session = { user_id: string; device: string | null; occurred_at: string };
type Training = { user_id: string; level: string | null; phase: string | null; mode: string | null; completed_at: string };
type CycleSet = { user_id: string; mode: string };

const COLORS = ["#b84c65", "#e8a87c", "#c9a0dc", "#87a878", "#6ba3c8"];

const AdminPage = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const { isAdmin, loading: roleLoading } = useIsAdmin();

  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [trainings, setTrainings] = useState<Training[]>([]);
  const [cycleSets, setCycleSets] = useState<CycleSet[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "premium" | "free">("all");
  const [loading, setLoading] = useState(true);

  // Redirect if not authorized
  useEffect(() => {
    if (authLoading || roleLoading) return;
    if (!user) navigate("/");
    else if (!isAdmin) navigate("/");
  }, [user, isAdmin, authLoading, roleLoading, navigate]);

  // Load all data
  const fetchAll = async () => {
    const [p, s, t, c] = await Promise.all([
      supabase.from("profile").select("id, name, email, birth_date, is_premium, premium_source, created_at"),
      supabase.from("app_sessions").select("user_id, device, occurred_at").gte("occurred_at", subDays(new Date(), 30).toISOString()),
      supabase.from("training_sessions").select("user_id, level, phase, mode, completed_at").gte("completed_at", subDays(new Date(), 90).toISOString()),
      supabase.from("cycle_settings").select("user_id, mode"),
    ]);
    setProfiles((p.data as Profile[]) ?? []);
    setSessions((s.data as Session[]) ?? []);
    setTrainings((t.data as Training[]) ?? []);
    setCycleSets((c.data as CycleSet[]) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    if (!isAdmin) return;
    void fetchAll();

    // Realtime — re-fetch on any relevant change
    const channel = supabase
      .channel("admin-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "profile" }, fetchAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "app_sessions" }, fetchAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "training_sessions" }, fetchAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "subscriptions" }, fetchAll)
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [isAdmin]);

  // ===== KPIs =====
  const total = profiles.length;
  const premium = profiles.filter(p => p.is_premium).length;
  const premiumPct = total ? Math.round((premium / total) * 100) : 0;

  const todayKey = startOfDay(new Date()).getTime();
  const dauUsers = new Set(
    sessions.filter(s => startOfDay(new Date(s.occurred_at)).getTime() === todayKey).map(s => s.user_id)
  ).size;
  const mauUsers = new Set(sessions.map(s => s.user_id)).size;
  const dauPct = total ? Math.round((dauUsers / total) * 100) : 0;

  // Retention 7d: users active today who registered ≥7 days ago
  const sevenAgo = subDays(new Date(), 7);
  const eligible = profiles.filter(p => new Date(p.created_at) <= sevenAgo);
  const activeUserIds = new Set(sessions.filter(s => new Date(s.occurred_at) >= subDays(new Date(), 7)).map(s => s.user_id));
  const retained = eligible.filter(p => activeUserIds.has(p.id)).length;
  const retention7d = eligible.length ? Math.round((retained / eligible.length) * 100) : 0;

  // Daily activity (last 14d)
  const daily = useMemo(() => {
    const days: { date: string; usuarias: number; entrenamientos: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = subDays(new Date(), i);
      const key = startOfDay(d).getTime();
      const u = new Set(sessions.filter(s => startOfDay(new Date(s.occurred_at)).getTime() === key).map(s => s.user_id)).size;
      const tr = trainings.filter(t => startOfDay(new Date(t.completed_at)).getTime() === key).length;
      days.push({ date: format(d, "dd MMM", { locale: es }), usuarias: u, entrenamientos: tr });
    }
    return days;
  }, [sessions, trainings]);

  // Most used training level
  const levelCounts = useMemo(() => {
    const c: Record<string, number> = {};
    trainings.forEach(t => { if (t.level) c[t.level] = (c[t.level] ?? 0) + 1; });
    return Object.entries(c).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [trainings]);

  // Most active phase
  const phaseCounts = useMemo(() => {
    const c: Record<string, number> = {};
    trainings.forEach(t => { if (t.phase) c[t.phase] = (c[t.phase] ?? 0) + 1; });
    return Object.entries(c).map(([name, value]) => ({ name, value }));
  }, [trainings]);

  // Mode distribution (cycle vs postpartum)
  const modeCounts = useMemo(() => {
    const c: Record<string, number> = { cycle: 0, postpartum: 0 };
    cycleSets.forEach(s => { c[s.mode] = (c[s.mode] ?? 0) + 1; });
    return [
      { name: "Ciclo activo", value: c.cycle },
      { name: "Post parto", value: c.postpartum },
    ];
  }, [cycleSets]);

  // Device split
  const deviceCounts = useMemo(() => {
    const c: Record<string, number> = { mobile: 0, tablet: 0, desktop: 0 };
    sessions.forEach(s => { const k = s.device ?? "desktop"; c[k] = (c[k] ?? 0) + 1; });
    return [
      { name: "Móvil", value: c.mobile },
      { name: "Tablet", value: c.tablet },
      { name: "Desktop", value: c.desktop },
    ];
  }, [sessions]);

  const topLevel = levelCounts[0]?.name ?? "—";

  // ===== Filtered users =====
  const filteredUsers = useMemo(() => {
    return profiles
      .filter(p => filter === "all" || (filter === "premium" ? p.is_premium : !p.is_premium))
      .filter(p => {
        if (!search.trim()) return true;
        const q = search.toLowerCase();
        return (p.name ?? "").toLowerCase().includes(q) || (p.email ?? "").toLowerCase().includes(q);
      })
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }, [profiles, filter, search]);

  const exportCSV = () => {
    const rows = [
      ["Nombre", "Email", "Plan", "Origen Premium", "Registrada"],
      ...filteredUsers.map(u => [
        u.name ?? "",
        u.email ?? "",
        u.is_premium ? "Premium" : "Gratuita",
        u.premium_source ?? "",
        format(new Date(u.created_at), "yyyy-MM-dd"),
      ]),
    ];
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cycra-usuarias-${format(new Date(), "yyyyMMdd")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const togglePremium = async (u: Profile) => {
    const next = !u.is_premium;
    const expires = next ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString() : null;
    const { error } = await supabase.rpc("admin_set_premium", {
      _user_id: u.id, _is_premium: next, _expires_at: expires,
    });
    if (error) return toast.error(error.message);
    toast.success(next ? `${u.name ?? u.email} ahora es Premium` : `${u.name ?? u.email} cambiada a Gratis`);
    fetchAll();
  };

  const deleteUser = async (u: Profile) => {
    if (!confirm(`¿Eliminar definitivamente a ${u.name ?? u.email}? Esta acción no se puede deshacer.`)) return;
    const { error } = await supabase.rpc("admin_delete_user", { _user_id: u.id });
    if (error) return toast.error(error.message);
    toast.success("Usuaria eliminada");
    fetchAll();
  };


  if (authLoading || roleLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}
          className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background pb-16">
      <header className="bg-card border-b border-border sticky top-0 z-20 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-lg font-heading font-bold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary" /> Panel Cycra
              </h1>
              <p className="text-xs text-muted-foreground">Sincronización en tiempo real · {total} usuarias</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate("/admin/videos")}>
            <Video className="w-4 h-4 mr-1" /> Videos
          </Button>
          <Button variant="outline" size="sm" onClick={async () => { await signOut(); navigate("/", { replace: true }); }}>Salir</Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* KPI grid */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <KpiCard icon={<Users className="w-4 h-4" />} label="Usuarias totales" value={total} />
          <KpiCard icon={<Crown className="w-4 h-4" />} label="Premium" value={`${premium} (${premiumPct}%)`} highlight />
          <KpiCard icon={<Activity className="w-4 h-4" />} label="Activas hoy" value={`${dauUsers} (${dauPct}%)`} />
          <KpiCard icon={<TrendingUp className="w-4 h-4" />} label="Retención 7d" value={`${retention7d}%`} />
          <KpiCard icon={<Dumbbell className="w-4 h-4" />} label="Nivel más usado" value={topLevel} />
          <KpiCard icon={<Heart className="w-4 h-4" />} label="MAU (30d)" value={mauUsers} />
          <KpiCard icon={<Smartphone className="w-4 h-4" />} label="Entrenos 30d" value={trainings.length} />
          <KpiCard icon={<Sparkles className="w-4 h-4" />} label="Fase top" value={phaseCounts[0]?.name ?? "—"} />
        </section>

        {/* Charts */}
        <section className="grid md:grid-cols-2 gap-4">
          <ChartCard title="Actividad diaria (14 días)">
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={daily}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                <Legend />
                <Line type="monotone" dataKey="usuarias" stroke="#b84c65" strokeWidth={2} />
                <Line type="monotone" dataKey="entrenamientos" stroke="#87a878" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Nivel de entrenamiento usado">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={levelCounts}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                <Bar dataKey="value" fill="#b84c65" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Fase del ciclo más entrenada">
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={phaseCounts} dataKey="value" nameKey="name" outerRadius={80} label>
                  {phaseCounts.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Modo de usuaria & dispositivos">
            <div className="grid grid-cols-2 gap-2 h-[240px]">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={modeCounts} dataKey="value" nameKey="name" outerRadius={60} label>
                    {modeCounts.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={deviceCounts} dataKey="value" nameKey="name" outerRadius={60} label>
                    {deviceCounts.map((_, i) => <Cell key={i} fill={COLORS[i + 2]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </section>

        {/* User table */}
        <section className="bg-card rounded-2xl border border-border overflow-hidden">
          <div className="p-4 border-b border-border flex flex-wrap gap-2 items-center justify-between">
            <div className="flex items-center gap-2 flex-1 min-w-[220px]">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Buscar por nombre o email..." className="pl-9"
                  value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <div className="flex gap-1">
                {(["all", "premium", "free"] as const).map(f => (
                  <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>
                    {f === "all" ? "Todas" : f === "premium" ? "Premium" : "Gratis"}
                  </Button>
                ))}
              </div>
            </div>
            <Button size="sm" variant="outline" onClick={exportCSV}>
              <Download className="w-4 h-4 mr-1" /> CSV
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/40">
                <tr className="text-left text-xs text-muted-foreground">
                  <th className="px-4 py-2 font-medium">Nombre</th>
                  <th className="px-4 py-2 font-medium">Email</th>
                  <th className="px-4 py-2 font-medium">Plan</th>
                  <th className="px-4 py-2 font-medium">Origen</th>
                  <th className="px-4 py-2 font-medium">Registrada</th>
                  <th className="px-4 py-2 font-medium text-right">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map(u => (
                  <tr key={u.id} className="border-t border-border hover:bg-muted/20">
                    <td className="px-4 py-2 font-medium">{u.name ?? "—"}</td>
                    <td className="px-4 py-2 text-muted-foreground">{u.email ?? "—"}</td>
                    <td className="px-4 py-2">
                      {u.is_premium
                        ? <Badge className="bg-primary text-primary-foreground">Premium</Badge>
                        : <Badge variant="outline">Gratis</Badge>}
                    </td>
                    <td className="px-4 py-2 text-xs text-muted-foreground">{u.premium_source ?? "—"}</td>
                    <td className="px-4 py-2 text-xs">{format(new Date(u.created_at), "dd MMM yyyy", { locale: es })}</td>
                    <td className="px-4 py-2">
                      <div className="flex gap-1 justify-end">
                        <Button
                          size="sm"
                          variant={u.is_premium ? "outline" : "default"}
                          onClick={() => togglePremium(u)}
                          title={u.is_premium ? "Quitar Premium" : "Activar Premium (1 año)"}
                        >
                          {u.is_premium ? <ShieldOff className="w-3.5 h-3.5" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteUser(u)}
                          className="text-destructive hover:bg-destructive/10"
                          title="Eliminar usuaria"
                          disabled={u.id === user?.id}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredUsers.length === 0 && (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground text-sm">Sin resultados</td></tr>
                )}

              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
};

const KpiCard = ({ icon, label, value, highlight }: { icon: React.ReactNode; label: string; value: React.ReactNode; highlight?: boolean }) => (
  <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
    className={`rounded-2xl p-3 border ${highlight ? "bg-primary/10 border-primary/30" : "bg-card border-border"}`}>
    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">{icon}<span>{label}</span></div>
    <div className="text-xl font-bold mt-1 font-heading">{value}</div>
  </motion.div>
);

const ChartCard = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="bg-card border border-border rounded-2xl p-4">
    <h3 className="text-sm font-semibold mb-2">{title}</h3>
    {children}
  </div>
);

export default AdminPage;
