import { useState } from "react";
import { motion } from "framer-motion";
import { User, Target, Bell, Moon, HelpCircle, ChevronRight, CalendarIcon, LogOut, Sparkles, FlaskConical, CreditCard, Flower2, Shield } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { format } from "date-fns";
import BottomNav from "@/components/BottomNav";
import PremiumModal from "@/components/PremiumModal";
import PremiumBadge from "@/components/PremiumBadge";
import EditPersonalDataDialog from "@/components/EditPersonalDataDialog";
import EditNutritionGoalDialog from "@/components/EditNutritionGoalDialog";
import ManageSubscriptionDialog from "@/components/ManageSubscriptionDialog";
import EditCycleSettingsDialog from "@/components/EditCycleSettingsDialog";
import { useCycleData } from "@/hooks/useCycleData";
import { useAuth } from "@/contexts/AuthContext";
import { usePremium } from "@/hooks/usePremium";
import { setTestPremium } from "@/lib/billing";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";

const SettingsPage = () => {
  const { lastPeriodDate, cycleDay, phaseInfo, settings } = useCycleData();
  const { profile, signOut, user } = useAuth();
  const { isPremium, source } = usePremium();
  const { isAdmin } = useIsAdmin();
  const navigate = useNavigate();
  const [premiumOpen, setPremiumOpen] = useState(false);
  const [togglingTest, setTogglingTest] = useState(false);
  const [editPersonalOpen, setEditPersonalOpen] = useState(false);
  const [editNutritionOpen, setEditNutritionOpen] = useState(false);
  const [manageSubOpen, setManageSubOpen] = useState(false);
  const [editCycleOpen, setEditCycleOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate("/", { replace: true });
  };


  const handleTestToggle = async (next: boolean) => {
    if (!user) return;
    setTogglingTest(true);
    const res = await setTestPremium(user.id, next);
    setTogglingTest(false);
    if (!res.success) {
      toast({ title: "No se pudo cambiar", description: res.error ?? "Intenta de nuevo." });
    } else {
      toast({ title: next ? "Premium de prueba activado" : "Premium de prueba desactivado" });
    }
  };

  const calcAge = (dateStr: string) => {
    const birth = new Date(dateStr);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age;
  };

  const displayName = profile?.name || "Cyra User";
  const age = profile?.birth_date ? calcAge(profile.birth_date) : null;

  const sections: {
    title: string;
    items: { icon: typeof User; label: string; desc: string; onClick?: () => void }[];
  }[] = [
    {
      title: "Perfil",
      items: [
        {
          icon: User,
          label: "Datos personales",
          desc: `${displayName}${age ? `, ${age} años` : ""}`,
          onClick: () => setEditPersonalOpen(true),
        },
        {
          icon: Target,
          label: "Objetivo nutricional",
          desc: "Calorías, macros y meta",
          onClick: () => setEditNutritionOpen(true),
        },
        {
          icon: CreditCard,
          label: "Administrar suscripción",
          desc: isPremium
            ? source === "test"
              ? "Premium (modo prueba)"
              : "Premium activo"
            : "Plan gratuito",
          onClick: () => setManageSubOpen(true),
        },
      ],
    },
    {
      title: "Preferencias",
      items: [
        { icon: Bell, label: "Notificaciones", desc: "Recordatorios activos" },
        { icon: Moon, label: "Apariencia", desc: "Tema claro" },
        { icon: HelpCircle, label: "Ayuda y soporte", desc: "FAQ, contacto" },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="gradient-warm pt-12 pb-6 px-5">
        <div className="max-w-lg mx-auto">
          <h1 className="text-2xl font-heading font-bold text-foreground">Ajustes</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 space-y-6 -mt-2">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 glass-card rounded-2xl p-5"
        >
          <div className="w-14 h-14 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-xl font-heading font-bold">
            {displayName.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <p className="font-heading font-semibold text-foreground">{displayName}</p>
              <PremiumBadge />
            </div>
            <p className="text-xs text-muted-foreground">
              {age ? `${age} años · ` : ""}Ciclo día {cycleDay} · {phaseInfo.emoji} {phaseInfo.name}
            </p>
          </div>
        </motion.div>

        {/* Premium card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.03 }}
          className="rounded-2xl overflow-hidden gradient-primary p-5 text-primary-foreground"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 mb-1">
                <Sparkles className="w-4 h-4" />
                <p className="text-xs font-semibold uppercase tracking-wider opacity-90">
                  {isPremium ? "Tu plan" : "Cyrafit Premium"}
                </p>
              </div>
              <p className="font-heading font-bold text-lg leading-tight">
                {isPremium
                  ? `Premium activo${source === "test" ? " (test)" : ""}`
                  : "Desbloquea todo Cyrafit"}
              </p>
              <p className="text-xs opacity-90 mt-1">
                {isPremium
                  ? "Tienes acceso completo a todas las funciones."
                  : "Nutrición, rutinas y métricas avanzadas."}
              </p>
            </div>
            {!isPremium && (
              <button
                onClick={() => setPremiumOpen(true)}
                className="shrink-0 bg-primary-foreground text-primary text-xs font-bold px-3 py-2 rounded-full hover:opacity-90"
              >
                Suscribirme
              </button>
            )}
          </div>
        </motion.div>

        {/* Test mode toggle (developer / QA) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="glass-card rounded-2xl p-4 flex items-center gap-3"
        >
          <FlaskConical className="w-5 h-5 text-primary shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground">Modo prueba Premium</p>
            <p className="text-[11px] text-muted-foreground leading-snug">
              Simula Premium ON/OFF mientras Google Play no está conectado.
            </p>
          </div>
          <Switch
            checked={isPremium && source === "test"}
            disabled={togglingTest || (isPremium && source !== "test")}
            onCheckedChange={handleTestToggle}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">
            Ciclo Menstrual
          </h2>
          <div className="glass-card rounded-2xl overflow-hidden">
            <button
              onClick={() => setEditCycleOpen(true)}
              className="w-full flex items-center gap-3 p-4 hover:bg-secondary/50 transition-colors text-left"
            >
              <Flower2 className="w-5 h-5 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">Datos del ciclo</p>
                <p className="text-xs text-muted-foreground">
                  {settings.mode === "postpartum"
                    ? `Post parto · ciclo ${settings.avgCycleLength}d`
                    : `Ciclo ${settings.avgCycleLength}d · menstruación ${settings.avgPeriodLength}d`}
                  {lastPeriodDate ? ` · último ${format(lastPeriodDate, "dd/MM")}` : ""}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
            </button>
          </div>
        </motion.div>

        {sections.map((section, si) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: (si + 1) * 0.1 }}
          >
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">
              {section.title}
            </h2>
            <div className="glass-card rounded-2xl overflow-hidden divide-y divide-border">
              {section.items.map((item) => (
                <button
                  key={item.label}
                  onClick={item.onClick}
                  disabled={!item.onClick}
                  className="w-full flex items-center gap-3 p-4 hover:bg-secondary/50 transition-colors text-left disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <item.icon className="w-5 h-5 text-primary shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                </button>
              ))}
            </div>
          </motion.div>
        ))}

        {isAdmin && (
          <Link to="/admin" className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl bg-primary/10 text-primary font-medium hover:bg-primary/20 transition-colors">
            <Shield className="w-4 h-4" /> Panel administrativo
          </Link>
        )}

        {/* Sign out */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          onClick={handleSignOut}
          className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl bg-destructive/10 text-destructive font-medium transition-colors hover:bg-destructive/20"
        >
          <LogOut className="w-4 h-4" />
          Cerrar sesión
        </motion.button>
      </div>

      <BottomNav />
      <PremiumModal open={premiumOpen} onOpenChange={setPremiumOpen} />
      <EditPersonalDataDialog open={editPersonalOpen} onOpenChange={setEditPersonalOpen} />
      <EditNutritionGoalDialog open={editNutritionOpen} onOpenChange={setEditNutritionOpen} />
      <ManageSubscriptionDialog
        open={manageSubOpen}
        onOpenChange={setManageSubOpen}
        onUpgradeClick={() => setPremiumOpen(true)}
      />
      <EditCycleSettingsDialog open={editCycleOpen} onOpenChange={setEditCycleOpen} />
    </div>
  );
};

export default SettingsPage;
