import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { Droplet, Egg, CalendarDays } from "lucide-react";
import { useIsAdmin } from "@/hooks/useIsAdmin";

import PremiumModal from "@/components/PremiumModal";
import { usePremium } from "@/hooks/usePremium";
import CycleRing from "@/components/CycleRing";
import PhaseCard from "@/components/PhaseCard";
import WaterTracker from "@/components/WaterTracker";
import QuickStats from "@/components/QuickStats";
import BottomNav from "@/components/BottomNav";
import WelcomeScreen from "@/components/WelcomeScreen";
import AuthScreen from "@/components/AuthScreen";
import AdminChoiceScreen from "@/components/AdminChoiceScreen";
import OnboardingProfile from "@/components/OnboardingProfile";
import OnboardingCycle from "@/components/OnboardingCycle";
import CyraPhaseFloat from "@/components/CyraPhaseFloat";
import WeeklyRecipes from "@/components/WeeklyRecipes";
import CycleCalendar from "@/components/CycleCalendar";
import { useCycleData } from "@/hooks/useCycleData";
import { useAuth } from "@/contexts/AuthContext";
import { useTrackAppSession } from "@/hooks/useTrackAppSession";
import { getGreeting, TAGLINE } from "@/lib/cyraVoice";

const STORAGE_KEY_WELCOMED = "cyra_welcomed";
const SESSION_KEY_PREMIUM_SHOWN = "cyrafit_premium_shown";
const SESSION_KEY_ADMIN_CHOICE = "cyra_admin_choice"; // "admin" | "app"

const Index = () => {
  const {
    loading: cycleLoading,
    isConfigured,
    settings,
    cycleDay,
    phase,
    phaseInfo,
    pendingPeriodStart,
    nextPeriodDate,
    daysUntilNextPeriod,
    ovulationDate,
    fertileWindow,
    logPeriodStart,
  } = useCycleData();
  const { user, profile, loading } = useAuth();
  const { isPremium, loading: premiumLoading } = usePremium();

  const [welcomed, setWelcomed] = useState(() => !!localStorage.getItem(STORAGE_KEY_WELCOMED));
  const [authDone, setAuthDone] = useState(false);
  const [showPremium, setShowPremium] = useState(false);
  const previewMode = typeof window !== "undefined" && (
    localStorage.getItem("cyra_preview_mode") === "1" ||
    new URLSearchParams(window.location.search).get("preview") === "1"
  );
  if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("preview") === "1") {
    localStorage.setItem("cyra_preview_mode", "1");
  }

  useTrackAppSession();

  const navigate = useNavigate();
  const { isAdmin, loading: adminLoading } = useIsAdmin();
  const [adminChoice, setAdminChoice] = useState<"admin" | "app" | null>(
    () => (sessionStorage.getItem(SESSION_KEY_ADMIN_CHOICE) as "admin" | "app" | null) ?? null
  );

  const isPaula = user?.email?.toLowerCase() === "paula@cyrafit.com";

  // Reset auth flow state on sign-out so AuthScreen reappears
  useEffect(() => {
    if (!user && !loading) {
      setAuthDone(false);
      setAdminChoice(null);
    }
  }, [user, loading]);

  useEffect(() => {
    if (!user || adminLoading || !isAdmin || !isPaula) return;
    if (adminChoice === "admin") navigate("/admin", { replace: true });
  }, [user, isAdmin, adminLoading, isPaula, adminChoice, navigate]);


  const handleAdminChoice = (choice: "admin" | "app") => {
    sessionStorage.setItem(SESSION_KEY_ADMIN_CHOICE, choice);
    setAdminChoice(choice);
    if (choice === "admin") navigate("/admin", { replace: true });
  };


  useEffect(() => {
    if (!user || !profile || premiumLoading || isPremium) return;
    if (sessionStorage.getItem(SESSION_KEY_PREMIUM_SHOWN)) return;
    const t = setTimeout(() => {
      setShowPremium(true);
      sessionStorage.setItem(SESSION_KEY_PREMIUM_SHOWN, "1");
    }, 800);
    return () => clearTimeout(t);
  }, [user, profile, premiumLoading, isPremium]);

  const handleWelcomeStart = () => {
    localStorage.setItem(STORAGE_KEY_WELCOMED, "true");
    setWelcomed(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!welcomed) return <WelcomeScreen onStart={handleWelcomeStart} />;
  if (!previewMode) {
    if (!user && !authDone) return <AuthScreen onAuthComplete={() => setAuthDone(true)} />;
    if (user && !adminLoading && isAdmin && isPaula && !adminChoice) {
      return <AdminChoiceScreen name={profile?.name} onChoose={handleAdminChoice} />;
    }
    if (user && !profile) return <OnboardingProfile onComplete={() => {}} />;
    if (user && profile && !cycleLoading && !isConfigured) {
      return <OnboardingCycle onComplete={() => {}} />;
    }
  }

  const displayName = profile?.name || (previewMode ? "Demo" : "Usuaria");
  const isPostpartumOnly = settings.mode === "postpartum" && !settings.trackPeriodPostpartum;
  const showCycleData = !isPostpartumOnly && !!settings.lastPeriodDate;

  return (
    <div className="min-h-screen bg-background pb-24">
      {isConfigured && (
        <CyraPhaseFloat
          phaseInfo={phaseInfo}
          cycleDay={cycleDay}
          phase={phase}
          isPostpartum={isPostpartumOnly}
          pendingPeriodStart={pendingPeriodStart}
        />
      )}

      <div className="gradient-warm pt-12 pb-6 px-5">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="max-w-lg mx-auto">
          <p className="text-sm text-muted-foreground font-medium">{getGreeting(displayName)}</p>
          <h1 className="text-2xl font-heading font-bold text-foreground mt-0.5">Cyra</h1>
          <p className="text-[11px] text-muted-foreground/80 italic mt-0.5">{TAGLINE}</p>
          {showCycleData && !pendingPeriodStart && (
            <p className="text-xs text-muted-foreground mt-1.5">
              Hoy estás en el <span className="font-semibold text-foreground">día {cycleDay}</span> de tu ciclo · {phaseInfo.emoji} fase {phaseInfo.name}
            </p>
          )}
          {showCycleData && pendingPeriodStart && (
            <p className="text-xs text-muted-foreground mt-1.5">
              🌸 Hoy podría ser tu <span className="font-semibold text-foreground">día 1</span> · esperando tu confirmación
            </p>
          )}
          {isPostpartumOnly && (
            <p className="text-xs text-muted-foreground mt-1.5">
              Recuperación post parto 🤱 — vamos paso a paso, sin prisa.
            </p>
          )}
        </motion.div>
      </div>

      {showCycleData && pendingPeriodStart && (
        <div className="max-w-lg mx-auto px-5 mt-4">
          <div className="rounded-2xl border border-primary/25 bg-primary/8 p-4 space-y-3">
            <div>
              <p className="text-xs font-semibold text-primary">¿Llegó tu periodo hoy?</p>
              <p className="text-sm font-heading font-bold text-foreground mt-1">
                Es probable que hoy sea tu día 1 🌸
              </p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                Según tus últimos ciclos, hoy podría comenzar tu menstruación. Cuando la confirmes, actualizo tu fase, predicciones y recomendaciones de inmediato.
              </p>
            </div>
            <div>
              <p className="text-[11px] font-semibold text-foreground/80 mb-1.5">Síntomas que podrías sentir hoy:</p>
              <div className="flex flex-wrap gap-1.5">
                {["Calambres leves", "Sensibilidad", "Cansancio", "Cambios de ánimo", "Hinchazón"].map((s) => (
                  <span key={s} className="text-[10px] bg-background/70 text-foreground/80 px-2.5 py-1 rounded-full font-medium">
                    {s}
                  </span>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={async () => { await logPeriodStart(new Date()); }}
                className="flex-1 text-xs font-semibold text-primary-foreground bg-primary px-3 py-2 rounded-full"
              >
                Sí, me llegó hoy
              </button>
              <button
                onClick={() => {
                  const el = document.getElementById("cycle-calendar");
                  el?.scrollIntoView({ behavior: "smooth", block: "center" });
                }}
                className="flex-1 text-xs font-semibold text-primary bg-primary/10 px-3 py-2 rounded-full"
              >
                Aún no
              </button>
            </div>
          </div>
        </div>
      )}



      <div className="max-w-lg mx-auto px-5 space-y-5 -mt-2">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex justify-center py-4">
          <CycleRing cycleDay={showCycleData ? cycleDay : 0} phase={showCycleData ? phase : "follicular"} />
        </motion.div>

        <div className="flex justify-center">
          <span className={`text-xs font-semibold px-4 py-1.5 rounded-full ${phaseInfo.bgColor} ${phaseInfo.color}`}>
            {phaseInfo.emoji} Fase {phaseInfo.name} · Intensidad {phaseInfo.intensity}
          </span>
        </div>

        {/* Predictions: only when we have a real period date and not pure postpartum */}
        {showCycleData && nextPeriodDate && (
          <div className="grid grid-cols-3 gap-2">
            <div className="glass-card rounded-2xl p-3 text-center">
              <CalendarDays className="w-4 h-4 text-primary mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Próx. periodo</p>
              <p className="text-xs font-bold text-foreground mt-0.5">
                {format(nextPeriodDate, "dd MMM", { locale: es })}
              </p>
              {daysUntilNextPeriod !== null && (
                <p className="text-[9px] text-muted-foreground">en {daysUntilNextPeriod}d</p>
              )}
            </div>
            <div className="glass-card rounded-2xl p-3 text-center">
              <Egg className="w-4 h-4 text-accent mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Ovulación</p>
              <p className="text-xs font-bold text-foreground mt-0.5">
                {ovulationDate ? format(ovulationDate, "dd MMM", { locale: es }) : "—"}
              </p>
            </div>
            <div className="glass-card rounded-2xl p-3 text-center">
              <Droplet className="w-4 h-4 text-primary mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Ventana fértil</p>
              <p className="text-xs font-bold text-foreground mt-0.5">
                {fertileWindow
                  ? `${format(fertileWindow.start, "dd", { locale: es })}–${format(fertileWindow.end, "dd MMM", { locale: es })}`
                  : "—"}
              </p>
            </div>
          </div>
        )}

        {showCycleData && (
          <div className="flex justify-center">
            <button
              onClick={async () => {
                await logPeriodStart(new Date());
              }}
              className="text-xs font-medium text-primary bg-primary/10 px-3 py-1.5 rounded-full"
            >
              🌸 Empezó hoy mi periodo
            </button>
          </div>
        )}

        <QuickStats />
        {showCycleData && <div id="cycle-calendar"><CycleCalendar /></div>}
        <PhaseCard phase={phaseInfo} cyclePhase={phase} isPostpartum={isPostpartumOnly} />
        <WeeklyRecipes />
        <WaterTracker />
      </div>

      <BottomNav />
      <PremiumModal open={showPremium} onOpenChange={setShowPremium} />
    </div>
  );
};

export default Index;
