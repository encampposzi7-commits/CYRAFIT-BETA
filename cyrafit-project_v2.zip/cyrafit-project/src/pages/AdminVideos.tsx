import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Search, Check, X, Play, Trash2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  getExerciseCatalog,
  resolveExerciseVideo,
  upsertExerciseVideo,
  deleteExerciseVideo,
  loadExerciseVideos,
  parseVideoUrl,
  useExerciseVideosVersion,
  type ExerciseVideo,
} from "@/lib/exerciseVideos";

const LEVEL_LABEL: Record<string, string> = {
  beginner: "Principiante",
  intermediate: "Intermedio",
  advanced: "Avanzado",
  postpartum: "Post parto",
};

const AdminVideos = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: roleLoading } = useIsAdmin();
  useExerciseVideosVersion(); // re-render cuando cambia el cache

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "with" | "without">("all");
  const [editing, setEditing] = useState<string | null>(null);
  const [draftUrl, setDraftUrl] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (authLoading || roleLoading) return;
    if (!user || !isAdmin) navigate("/");
  }, [user, isAdmin, authLoading, roleLoading, navigate]);

  useEffect(() => { void loadExerciseVideos(); }, []);

  const catalog = useMemo(() => getExerciseCatalog(), []);

  const rows = useMemo(() => {
    return catalog
      .filter((c) => {
        const v = resolveExerciseVideo(c.name);
        if (filter === "with" && !v) return false;
        if (filter === "without" && v) return false;
        if (!search.trim()) return true;
        return c.name.toLowerCase().includes(search.toLowerCase());
      });
  }, [catalog, search, filter]);

  const totalWith = catalog.filter((c) => resolveExerciseVideo(c.name)).length;
  const pct = catalog.length ? Math.round((totalWith / catalog.length) * 100) : 0;

  const startEdit = (name: string) => {
    const v = resolveExerciseVideo(name);
    setEditing(name);
    setDraftUrl(v ? (v.source === "youtube"
      ? `https://www.youtube.com/watch?v=${v.id}`
      : `https://vimeo.com/${v.id}`) : "");
  };

  const save = async (name: string) => {
    const parsed = parseVideoUrl(draftUrl);
    if (!parsed) return toast.error("URL no reconocida. Pega un link de YouTube o Vimeo.");
    setSaving(true);
    try {
      await upsertExerciseVideo(name, parsed);
      toast.success("Video guardado");
      setEditing(null);
    } catch (e: any) {
      toast.error(e.message ?? "Error al guardar");
    } finally { setSaving(false); }
  };

  const remove = async (name: string) => {
    if (!confirm(`¿Quitar video de "${name}"?`)) return;
    try {
      await deleteExerciseVideo(name);
      toast.success("Video eliminado");
    } catch (e: any) { toast.error(e.message); }
  };

  if (authLoading || roleLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}
          className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }
  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background pb-16">
      <header className="bg-card border-b border-border sticky top-0 z-20 backdrop-blur">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <Button variant="ghost" size="icon" onClick={() => navigate("/admin")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="min-w-0">
              <h1 className="text-lg font-heading font-bold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary" /> Catálogo de videos
              </h1>
              <p className="text-xs text-muted-foreground">
                {totalWith} / {catalog.length} ejercicios con video ({pct}%)
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-5 space-y-4">
        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Buscar ejercicio..." className="pl-9"
              value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="flex gap-1">
            {(["all", "with", "without"] as const).map((f) => (
              <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>
                {f === "all" ? "Todos" : f === "with" ? "Con video" : "Sin video"}
              </Button>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl divide-y divide-border overflow-hidden">
          {rows.map((row) => {
            const v = resolveExerciseVideo(row.name);
            const isEditing = editing === row.name;
            return (
              <div key={row.name} className="p-3 sm:p-4">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-medium text-sm">{row.name}</h3>
                      {v ? (
                        <Badge className="bg-primary/15 text-primary border-primary/30">
                          {v.source === "youtube" ? "YouTube" : "Vimeo"}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-muted-foreground">Sin video</Badge>
                      )}
                    </div>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {row.levels.map((l) => (
                        <span key={l} className="text-[10px] uppercase tracking-wide text-muted-foreground bg-muted/60 rounded px-1.5 py-0.5">
                          {LEVEL_LABEL[l] ?? l}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    {v && !isEditing && (
                      <a
                        href={v.source === "youtube" ? `https://youtu.be/${v.id}` : `https://vimeo.com/${v.id}`}
                        target="_blank" rel="noreferrer"
                      >
                        <Button size="sm" variant="outline"><Play className="w-3.5 h-3.5" /></Button>
                      </a>
                    )}
                    {!isEditing && (
                      <Button size="sm" variant={v ? "outline" : "default"} onClick={() => startEdit(row.name)}>
                        {v ? "Editar" : "Agregar"}
                      </Button>
                    )}
                    {v && !isEditing && (
                      <Button size="sm" variant="outline" className="text-destructive hover:bg-destructive/10"
                        onClick={() => remove(row.name)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </div>

                {isEditing && (
                  <div className="mt-3 flex gap-2 flex-wrap">
                    <Input
                      autoFocus
                      placeholder="Pega URL de YouTube o Vimeo (o solo el ID)"
                      value={draftUrl}
                      onChange={(e) => setDraftUrl(e.target.value)}
                      className="flex-1 min-w-[220px]"
                      onKeyDown={(e) => { if (e.key === "Enter") save(row.name); }}
                    />
                    <Button size="sm" onClick={() => save(row.name)} disabled={saving}>
                      <Check className="w-4 h-4 mr-1" /> Guardar
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setEditing(null)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
          {rows.length === 0 && (
            <div className="p-8 text-center text-sm text-muted-foreground">Sin resultados</div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminVideos;
