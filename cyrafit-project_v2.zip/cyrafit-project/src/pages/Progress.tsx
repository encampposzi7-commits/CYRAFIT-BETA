import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TrendingUp, TrendingDown, Scale, Ruler, Calendar, Check, Info, Plus, X, Loader2, Lock } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import PremiumModal from "@/components/PremiumModal";
import { usePremium } from "@/hooks/usePremium";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { TrainingFrequency } from "@/lib/training";

const STORAGE_KEY_FREQ = "lunafit_training_frequency";
const STORAGE_KEY_COMPLETED = "lunafit_completed_days";
const STORAGE_KEY_PROGRESS_HISTORY = "lunafit_progress_history";
const SESSION_KEY_EVAL_DISMISSED = "cyra_eval_dismissed";

interface ProgressEntry {
  id: string;
  user_id: string;
  date: string;
  weight: number | null;
  waist: number | null;
  hip: number | null;
  thigh: number | null;
  arm: number | null;
  created_at: string;
}

interface MonthlyProgress {
  month: string;
  completedDays: number;
  totalGoal: number;
  frequency: TrainingFrequency;
  dayGrid: boolean[];
}

const MEASUREMENT_FIELDS = [
  { key: "waist" as const, label: "Cintura", guide: "Medir en la zona más angosta del torso, generalmente a la altura del ombligo o justo por encima.", imageDesc: "📍 Punto: zona más angosta del torso" },
  { key: "hip" as const, label: "Cadera", guide: "Medir en la zona más prominente del glúteo, con los pies juntos.", imageDesc: "📍 Punto: zona más prominente del glúteo, pies juntos" },
  { key: "thigh" as const, label: "Muslo", guide: "Medir a la mitad de distancia entre la rodilla y el pliegue inguinal.", imageDesc: "📍 Punto: mitad entre rodilla y pliegue inguinal" },
  { key: "arm" as const, label: "Brazo", guide: "Medir en el punto medio entre el hombro y el codo, con el brazo relajado y colgando.", imageDesc: "📍 Punto: mitad entre hombro y codo, brazo relajado" },
];

function getCurrentMonthKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function loadProgressHistory(): MonthlyProgress[] {
  const raw = localStorage.getItem(STORAGE_KEY_PROGRESS_HISTORY);
  if (!raw) return [];
  try { return JSON.parse(raw); } catch { return []; }
}

function saveProgressHistory(history: MonthlyProgress[]) {
  localStorage.setItem(STORAGE_KEY_PROGRESS_HISTORY, JSON.stringify(history));
}

function daysSince(dateStr: string): number {
  const d = new Date(dateStr);
  const now = new Date();
  return Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
}

const Progress = () => {
  const { user } = useAuth();
  const { isPremium } = usePremium();
  const [showPremium, setShowPremium] = useState(false);

  const [entries, setEntries] = useState<ProgressEntry[]>([]);
  const [loading, setLoading] = useState(true);

  // Form state
  const [showForm, setShowForm] = useState(false);
  const [formWeight, setFormWeight] = useState("");
  const [formWaist, setFormWaist] = useState("");
  const [formHip, setFormHip] = useState("");
  const [formThigh, setFormThigh] = useState("");
  const [formArm, setFormArm] = useState("");
  const [saving, setSaving] = useState(false);

  // Measurement guide
  const [selectedMeasurement, setSelectedMeasurement] = useState<number | null>(null);

  // 20-day evaluation modal
  const [showEvalModal, setShowEvalModal] = useState(false);

  // Consistency
  const [frequency, setFrequency] = useState<TrainingFrequency>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_FREQ);
    return saved ? (parseInt(saved) as TrainingFrequency) : 3;
  });
  const [monthlyDays, setMonthlyDays] = useState<boolean[]>([]);

  // Fetch all progress entries
  const fetchEntries = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("progress")
      .select("*")
      .eq("user_id", user.id)
      .order("date", { ascending: true });

    if (error) {
      console.error("[Progress] fetch error:", error.message);
      toast.error("Error al cargar historial");
    }
    setEntries(data ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchEntries(); }, [fetchEntries]);

  // Check 20-day evaluation
  useEffect(() => {
    if (!entries.length) return;
    const dismissed = sessionStorage.getItem(SESSION_KEY_EVAL_DISMISSED);
    if (dismissed) return;
    const lastEntry = entries[entries.length - 1];
    if (daysSince(lastEntry.date) >= 20) {
      setShowEvalModal(true);
    }
  }, [entries]);

  // Save handler — upsert by user_id + date
  const handleSave = async () => {
    if (!user) return;
    const today = new Date().toISOString().split("T")[0];

    const weight = formWeight ? parseFloat(formWeight) : null;
    const waist = formWaist ? parseFloat(formWaist) : null;
    const hip = formHip ? parseFloat(formHip) : null;
    const thigh = formThigh ? parseFloat(formThigh) : null;
    const arm = formArm ? parseFloat(formArm) : null;

    if (weight !== null && (isNaN(weight) || weight < 20 || weight > 300)) {
      toast.error("Peso inválido (20-300 kg)");
      return;
    }

    if (!weight && !waist && !hip && !thigh && !arm) {
      toast.error("Ingresa al menos un valor");
      return;
    }

    setSaving(true);
    const payload: Record<string, any> = { user_id: user.id, date: today };
    if (weight !== null) payload.weight = weight;
    if (waist !== null) payload.waist = waist;
    if (hip !== null) payload.hip = hip;
    if (thigh !== null) payload.thigh = thigh;
    if (arm !== null) payload.arm = arm;

    const { error } = await supabase
      .from("progress")
      .upsert(payload as any, { onConflict: "user_id,date" });

    setSaving(false);
    if (error) {
      console.error("[Progress] save error:", error.message);
      toast.error(`Error: ${error.message}`);
      return;
    }

    toast.success("Datos guardados ✅");
    setShowForm(false);
    setFormWeight(""); setFormWaist(""); setFormHip(""); setFormThigh(""); setFormArm("");
    await fetchEntries();
  };

  // Derived data
  const weightEntries = entries.filter(e => e.weight !== null);
  const latestEntry = entries.length > 0 ? entries[entries.length - 1] : null;
  const previousEntry = entries.length > 1 ? entries[entries.length - 2] : null;

  // Weight chart data
  const weightData = weightEntries.map(e => e.weight!);
  const weightLabels = weightEntries.map(e => {
    const d = new Date(e.date + "T12:00:00");
    return `${d.getDate()}/${d.getMonth() + 1}`;
  });
  const weightChange = weightData.length >= 2
    ? (weightData[weightData.length - 1] - weightData[0]).toFixed(1)
    : "0";

  // SVG line chart
  const chartW = 320;
  const chartH = 120;
  const padX = 10;
  const padY = 10;

  let svgPath = "";
  let svgDots: { x: number; y: number; val: number }[] = [];
  if (weightData.length >= 2) {
    const minW = Math.min(...weightData);
    const maxW = Math.max(...weightData);
    const rangeW = maxW - minW || 1;
    const points = weightData.map((w, i) => {
      const x = padX + (i / (weightData.length - 1)) * (chartW - 2 * padX);
      const y = padY + (1 - (w - minW) / rangeW) * (chartH - 2 * padY);
      return { x, y, val: w };
    });
    svgDots = points;
    svgPath = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");
  }

  // Measurements with change
  const getMeasurement = (key: "waist" | "hip" | "thigh" | "arm") => {
    const current = latestEntry?.[key] ?? null;
    const prev = previousEntry?.[key] ?? null;
    const change = current !== null && prev !== null ? (current - prev) : null;
    return { current, change };
  };

  // Consistency sync
  const syncFromTraining = () => {
    const freq = parseInt(localStorage.getItem(STORAGE_KEY_FREQ) || "3") as TrainingFrequency;
    setFrequency(freq);
    const history = loadProgressHistory();
    const currentMonth = getCurrentMonthKey();
    const existing = history.find(h => h.month === currentMonth);
    const completedRaw = localStorage.getItem(STORAGE_KEY_COMPLETED);
    let completedCount = 0;
    if (completedRaw) {
      try { completedCount = Object.values(JSON.parse(completedRaw)).filter(Boolean).length; } catch {}
    }
    const totalDays = freq * 4;
    let grid = existing ? [...existing.dayGrid] : new Array(totalDays).fill(false);
    if (grid.length !== totalDays) {
      const newGrid = new Array(totalDays).fill(false);
      for (let i = 0; i < Math.min(grid.length, totalDays); i++) newGrid[i] = grid[i];
      grid = newGrid;
    }
    const alreadyMarked = grid.filter(Boolean).length;
    if (completedCount > alreadyMarked) {
      let toMark = completedCount - alreadyMarked;
      for (let i = 0; i < grid.length && toMark > 0; i++) {
        if (!grid[i]) { grid[i] = true; toMark--; }
      }
    }
    setMonthlyDays(grid);
    const updatedEntry: MonthlyProgress = {
      month: currentMonth, completedDays: grid.filter(Boolean).length,
      totalGoal: totalDays, frequency: freq, dayGrid: grid,
    };
    const updatedHistory = existing
      ? history.map(h => h.month === currentMonth ? updatedEntry : h)
      : [...history, updatedEntry];
    saveProgressHistory(updatedHistory);
  };

  useEffect(() => {
    syncFromTraining();
    const handler = () => syncFromTraining();
    window.addEventListener("cyra_training_complete", handler);
    return () => window.removeEventListener("cyra_training_complete", handler);
  }, []);

  useEffect(() => {
    const handler = () => syncFromTraining();
    window.addEventListener("focus", handler);
    return () => window.removeEventListener("focus", handler);
  }, []);

  const totalGoal = frequency * 4;
  const completedCount = monthlyDays.filter(Boolean).length;
  const adherence = totalGoal > 0 ? Math.round((completedCount / totalGoal) * 100) : 0;
  const cols = frequency;
  const rows = 4;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="gradient-warm pt-12 pb-6 px-5">
        <div className="max-w-lg mx-auto">
          <p className="text-sm text-muted-foreground font-medium">📈 Tu evolución</p>
          <h1 className="text-2xl font-heading font-bold text-foreground mt-0.5">Cyra Track</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 space-y-5 -mt-2">
        {/* Register button */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <button
            onClick={() => setShowForm(true)}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl gradient-primary text-primary-foreground font-semibold text-sm shadow-md transition-transform active:scale-[0.98]"
          >
            <Plus className="w-4 h-4" /> Registrar peso y medidas
          </button>
        </motion.div>

        {/* Weight chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="glass-card rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Scale className="w-4 h-4 text-primary" />
            <h3 className="font-heading font-semibold text-sm text-foreground">Peso corporal</h3>
            {weightData.length >= 2 && (
              <span className="ml-auto text-xs text-muted-foreground font-medium flex items-center gap-1">
                {parseFloat(weightChange) <= 0 ? (
                  <TrendingDown className="w-3 h-3 text-primary" />
                ) : (
                  <TrendingUp className="w-3 h-3 text-accent" />
                )}
                {parseFloat(weightChange) <= 0 ? weightChange : `+${weightChange}`} kg
              </span>
            )}
          </div>

          {loading ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : weightData.length < 2 ? (
            <div className="flex flex-col items-center justify-center h-32 text-center">
              <Scale className="w-8 h-8 text-muted-foreground/30 mb-2" />
              <p className="text-xs text-muted-foreground">Registra al menos 2 pesos para ver tu gráfico de evolución</p>
            </div>
          ) : (
            <div className="w-full overflow-hidden">
              <svg viewBox={`0 0 ${chartW} ${chartH + 20}`} className="w-full h-auto">
                {/* Grid lines */}
                {[0.25, 0.5, 0.75].map(frac => (
                  <line key={frac} x1={padX} x2={chartW - padX} y1={padY + frac * (chartH - 2 * padY)} y2={padY + frac * (chartH - 2 * padY)} stroke="hsl(var(--border))" strokeWidth="0.5" strokeDasharray="4 2" />
                ))}
                {/* Line */}
                <path d={svgPath} fill="none" stroke="hsl(var(--primary))" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                {/* Area fill */}
                <path d={`${svgPath} L${svgDots[svgDots.length - 1]?.x},${chartH - padY} L${svgDots[0]?.x},${chartH - padY} Z`} fill="hsl(var(--primary) / 0.1)" />
                {/* Dots */}
                {svgDots.map((dot, i) => (
                  <g key={i}>
                    <circle cx={dot.x} cy={dot.y} r="4" fill="hsl(var(--primary))" stroke="hsl(var(--background))" strokeWidth="2" />
                    <text x={dot.x} y={dot.y - 8} textAnchor="middle" fill="hsl(var(--foreground))" fontSize="8" fontWeight="600">{dot.val}</text>
                  </g>
                ))}
                {/* X labels */}
                {weightLabels.map((label, i) => {
                  const x = padX + (i / (weightLabels.length - 1)) * (chartW - 2 * padX);
                  return (
                    <text key={i} x={x} y={chartH + 12} textAnchor="middle" fill="hsl(var(--muted-foreground))" fontSize="7">{label}</text>
                  );
                })}
              </svg>
            </div>
          )}

          {/* Latest weight */}
          {weightData.length > 0 && (
            <div className="mt-3 text-center">
              <p className="text-2xl font-heading font-bold text-foreground">{weightData[weightData.length - 1]} kg</p>
              <p className="text-[10px] text-muted-foreground">Último registro</p>
            </div>
          )}
        </motion.div>

        {/* Measurements */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Ruler className="w-4 h-4 text-primary" />
            <h3 className="font-heading font-semibold text-sm text-foreground">Medidas corporales</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {MEASUREMENT_FIELDS.map((m, idx) => {
              const { current, change } = getMeasurement(m.key);
              return (
                <button key={m.key} onClick={() => setSelectedMeasurement(selectedMeasurement === idx ? null : idx)} className="bg-secondary/50 rounded-xl p-3 text-center transition-all hover:bg-secondary/70">
                  <p className="text-xs text-muted-foreground mb-1">{m.label}</p>
                  <p className="text-lg font-heading font-bold text-foreground">
                    {current !== null ? `${current} cm` : "—"}
                  </p>
                  {change !== null && (
                    <p className={`text-xs font-medium ${change > 0 ? "text-accent" : change < 0 ? "text-primary" : "text-muted-foreground"}`}>
                      {change > 0 ? `+${change}` : change} cm
                    </p>
                  )}
                  <div className="flex items-center justify-center gap-0.5 mt-1">
                    <Info className="w-2.5 h-2.5 text-muted-foreground" />
                    <span className="text-[8px] text-muted-foreground">Ver guía</span>
                  </div>
                </button>
              );
            })}
          </div>
          <AnimatePresence>
            {selectedMeasurement !== null && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mt-3 bg-primary/5 border border-primary/15 rounded-xl p-3 overflow-hidden">
                <p className="text-xs font-semibold text-foreground mb-1">📏 Cómo medir: {MEASUREMENT_FIELDS[selectedMeasurement].label}</p>
                <p className="text-[11px] text-muted-foreground mb-2">{MEASUREMENT_FIELDS[selectedMeasurement].guide}</p>
                <div className="bg-secondary rounded-lg p-3 text-center">
                  <div className="w-24 h-24 mx-auto bg-muted rounded-full flex items-center justify-center mb-2">
                    <Ruler className="w-8 h-8 text-primary/40" />
                  </div>
                  <p className="text-[10px] text-primary font-medium">{MEASUREMENT_FIELDS[selectedMeasurement].imageDesc}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* History */}
        {entries.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="glass-card rounded-2xl p-5">
            <h3 className="font-heading font-semibold text-sm text-foreground mb-3">📋 Historial</h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {[...entries].reverse().map(entry => {
                const d = new Date(entry.date + "T12:00:00");
                const dateStr = d.toLocaleDateString("es-CL", { day: "numeric", month: "short", year: "numeric" });
                return (
                  <div key={entry.id} className="flex items-center justify-between bg-secondary/30 rounded-xl px-3 py-2">
                    <span className="text-xs text-muted-foreground">{dateStr}</span>
                    <div className="flex gap-3 text-xs font-medium text-foreground">
                      {entry.weight && <span>{entry.weight} kg</span>}
                      {entry.waist && <span>C:{entry.waist}</span>}
                      {entry.hip && <span>Ca:{entry.hip}</span>}
                      {entry.thigh && <span>M:{entry.thigh}</span>}
                      {entry.arm && <span>B:{entry.arm}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Consistency */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="font-heading font-semibold text-sm text-foreground">Consistencia mensual</h3>
            <span className="ml-auto text-xs text-muted-foreground">{frequency}d/semana</span>
          </div>
          <div className="flex justify-center">
            <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)`, width: `${cols * 48}px` }}>
              {Array.from({ length: rows }, (_, weekIdx) =>
                Array.from({ length: cols }, (_, dayIdx) => {
                  const idx = weekIdx * cols + dayIdx;
                  const isCompleted = monthlyDays[idx] || false;
                  return (
                    <div key={idx} className={`aspect-square rounded-lg flex items-center justify-center transition-all ${isCompleted ? "gradient-primary shadow-sm" : "bg-muted/50 border border-border/30"}`} style={{ width: "40px", height: "40px" }}>
                      {isCompleted && <Check className="w-4 h-4 text-primary-foreground" />}
                    </div>
                  );
                })
              ).flat()}
            </div>
          </div>
          <div className="flex justify-center mt-2">
            <div className="flex gap-2" style={{ width: `${cols * 48}px` }}>
              {Array.from({ length: cols }, (_, i) => (
                <div key={i} className="flex-1 text-center"><span className="text-[9px] text-muted-foreground">Día {i + 1}</span></div>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between mt-3">
            <p className="text-xs text-muted-foreground">{completedCount} de {totalGoal} días entrenados</p>
            <p className="text-xs font-semibold text-primary">{adherence}% adherencia</p>
          </div>
          <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
            <div className="flex items-center gap-1"><div className="w-3 h-3 rounded gradient-primary" /><span>Completado</span></div>
            <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-muted/50 border border-border/30" /><span>Pendiente</span></div>
          </div>
        </motion.div>
      </div>

      {/* Input form modal */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="rounded-2xl max-w-sm mx-auto">
          <DialogHeader>
            <DialogTitle className="font-heading">Registrar datos</DialogTitle>
            <DialogDescription>Ingresa tu peso y/o medidas de hoy</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Peso (kg)</label>
              <Input type="number" step="0.1" placeholder="Ej: 61.5" value={formWeight} onChange={e => setFormWeight(e.target.value)} className="rounded-xl" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Cintura (cm)</label>
                <Input type="number" step="0.1" placeholder="Ej: 68" value={formWaist} onChange={e => setFormWaist(e.target.value)} className="rounded-xl" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Cadera (cm)</label>
                <Input type="number" step="0.1" placeholder="Ej: 96" value={formHip} onChange={e => setFormHip(e.target.value)} className="rounded-xl" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Muslo (cm)</label>
                <Input type="number" step="0.1" placeholder="Ej: 54" value={formThigh} onChange={e => setFormThigh(e.target.value)} className="rounded-xl" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Brazo (cm)</label>
                <Input type="number" step="0.1" placeholder="Ej: 27" value={formArm} onChange={e => setFormArm(e.target.value)} className="rounded-xl" />
              </div>
            </div>
            <Button onClick={handleSave} disabled={saving} className="w-full rounded-xl gradient-primary text-primary-foreground font-semibold">
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {saving ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 20-day evaluation modal — Premium */}
      <Dialog open={showEvalModal} onOpenChange={(open) => {
        if (!open) {
          sessionStorage.setItem(SESSION_KEY_EVAL_DISMISSED, "1");
        }
        setShowEvalModal(open);
      }}>
        <DialogContent className="rounded-2xl max-w-sm mx-auto text-center">
          <DialogHeader>
            <DialogTitle className="font-heading text-lg flex items-center justify-center gap-2">
              ✨ Evaluación personalizada
              {!isPremium && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-primary-foreground gradient-primary px-2 py-0.5 rounded-full">
                  <Lock className="w-2.5 h-2.5" /> Premium
                </span>
              )}
            </DialogTitle>
            <DialogDescription className="mt-2">
              {isPremium
                ? "Registra nuevamente tu peso y medidas para que tu coach Paula Pérez ajuste tu plan."
                : "Tu coach Paula Pérez analiza tu progreso cada 20 días y ajusta tu plan. Disponible en Premium."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2 mt-2">
            {isPremium ? (
              <Button
                onClick={() => {
                  setShowEvalModal(false);
                  sessionStorage.setItem(SESSION_KEY_EVAL_DISMISSED, "1");
                  setShowForm(true);
                }}
                className="w-full rounded-xl gradient-primary text-primary-foreground font-semibold"
              >
                Registrar ahora
              </Button>
            ) : (
              <Button
                onClick={() => {
                  setShowEvalModal(false);
                  sessionStorage.setItem(SESSION_KEY_EVAL_DISMISSED, "1");
                  setShowPremium(true);
                }}
                className="w-full rounded-xl gradient-primary text-primary-foreground font-semibold"
              >
                ✨ Desbloquear con Premium
              </Button>
            )}
            <Button
              variant="ghost"
              onClick={() => {
                sessionStorage.setItem(SESSION_KEY_EVAL_DISMISSED, "1");
                setShowEvalModal(false);
              }}
              className="w-full rounded-xl text-muted-foreground"
            >
              Más tarde
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <PremiumModal
        open={showPremium}
        onOpenChange={setShowPremium}
        reason="La evaluación personalizada con tu coach Paula Pérez está disponible en Cyrafit Premium."
      />

      <BottomNav />
    </div>
  );
};

export default Progress;
