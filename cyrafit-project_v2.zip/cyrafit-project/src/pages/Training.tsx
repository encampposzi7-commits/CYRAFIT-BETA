import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, Clock, Flame, Dumbbell, Check, ChevronLeft, RotateCcw, Info, Sparkles } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import FrequencySelector from "@/components/FrequencySelector";
import ExerciseDetailModal from "@/components/ExerciseDetailModal";
import TrainingCelebration from "@/components/TrainingCelebration";
import { useCycleData } from "@/hooks/useCycleData";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  TrainingFrequency,
  TrainingLevel,
  WorkoutDay,
  ExerciseLog,
  generateWeeklyPlan,
  getPhaseTrainingNote,
  getLevelTrainingTip,
  getPostpartumCardioTip,
  getProgramWeek,
  getMesocycleInfo,
  getRPEReminder,
  getTargetRPE,
  LEVEL_LABELS,
  DAY_NAMES,
  DAY_NAMES_FULL,
} from "@/lib/training";
import { Baby } from "lucide-react";

const STORAGE_KEY_FREQ = "lunafit_training_frequency";
const STORAGE_KEY_LEVEL = "lunafit_training_level";
const STORAGE_KEY_COMPLETED = "lunafit_completed_days";
const STORAGE_KEY_LOGS = "lunafit_exercise_logs";
const STORAGE_KEY_PP_OVERRIDE = "lunafit_postpartum_override";
const STORAGE_KEY_START_DATE = "lunafit_plan_start_date";
const LEGACY_KEY_LOCATION = "lunafit_workout_location";

const Training = () => {
  const [frequency, setFrequency] = useState<TrainingFrequency | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_FREQ);
    return saved ? (parseInt(saved) as TrainingFrequency) : null;
  });
  const [level, setLevel] = useState<TrainingLevel>(() => {
    return (localStorage.getItem(STORAGE_KEY_LEVEL) as TrainingLevel) || "intermediate";
  });
  const [selectedDay, setSelectedDay] = useState(0);
  const [completedDays, setCompletedDays] = useState<Record<number, boolean>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_COMPLETED);
    return saved ? JSON.parse(saved) : {};
  });
  const [exerciseLogs, setExerciseLogs] = useState<Record<string, ExerciseLog>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_LOGS);
    return saved ? JSON.parse(saved) : {};
  });
  const [selectedExerciseIndex, setSelectedExerciseIndex] = useState<number | null>(null);

  const [postpartumOverride, setPostpartumOverride] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEY_PP_OVERRIDE) === "1";
  });

  // Limpiar storage legacy de ubicación (gimnasio/casa) — la app ahora es solo en casa
  useEffect(() => {
    if (localStorage.getItem(LEGACY_KEY_LOCATION)) {
      localStorage.removeItem(LEGACY_KEY_LOCATION);
    }
  }, []);

  // Asegurar fecha de inicio del plan
  useEffect(() => {
    if (frequency && !localStorage.getItem(STORAGE_KEY_START_DATE)) {
      localStorage.setItem(STORAGE_KEY_START_DATE, new Date().toISOString());
    }
  }, [frequency]);

  const { phase, phaseInfo, settings } = useCycleData();
  const { user } = useAuth();
  const baseMode = settings.mode;
  const mode = postpartumOverride ? 'postpartum' : baseMode;
  const isPostpartum = mode === 'postpartum';

  const programWeek = getProgramWeek(localStorage.getItem(STORAGE_KEY_START_DATE));
  const meso = getMesocycleInfo(level, mode, programWeek);
  const targetRPE = getTargetRPE(phase, mode);
  const rpeReminder = getRPEReminder(phase, level, mode);

  const weekPlan: WorkoutDay[] = frequency ? generateWeeklyPlan(frequency, phase, mode, level, programWeek) : [];
  const currentWorkout = weekPlan[selectedDay];

  const [exercises, setExercises] = useState(currentWorkout?.exercises || []);

  useEffect(() => {
    if (currentWorkout) {
      setExercises(currentWorkout.exercises.map((e) => {
        const logKey = `${selectedDay}-${e.name}`;
        return { ...e, completed: !!exerciseLogs[logKey] };
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDay, frequency, level, mode, programWeek]);

  const togglePostpartum = () => {
    const next = !postpartumOverride;
    setPostpartumOverride(next);
    if (next) localStorage.setItem(STORAGE_KEY_PP_OVERRIDE, "1");
    else localStorage.removeItem(STORAGE_KEY_PP_OVERRIDE);
    setSelectedDay(0);
  };

  const repeatSession = () => {
    if (!currentWorkout) return;
    const cleared = { ...exerciseLogs };
    currentWorkout.exercises.forEach((e) => {
      delete cleared[`${selectedDay}-${e.name}`];
    });
    setExerciseLogs(cleared);
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(cleared));
    setExercises(currentWorkout.exercises.map((e) => ({ ...e, completed: false })));
  };

  const handleSelectFrequency = useCallback((freq: TrainingFrequency, lvl: TrainingLevel) => {
    setFrequency(freq);
    setLevel(lvl);
    localStorage.setItem(STORAGE_KEY_FREQ, String(freq));
    localStorage.setItem(STORAGE_KEY_LEVEL, lvl);
    localStorage.setItem(STORAGE_KEY_START_DATE, new Date().toISOString());
    setSelectedDay(0);
    setCompletedDays({});
    setExerciseLogs({});
    localStorage.removeItem(STORAGE_KEY_COMPLETED);
    localStorage.removeItem(STORAGE_KEY_LOGS);
  }, []);

  const handleSaveExerciseLog = (index: number, log: ExerciseLog) => {
    const logKey = `${selectedDay}-${exercises[index].name}`;
    const updatedLogs = { ...exerciseLogs, [logKey]: log };
    setExerciseLogs(updatedLogs);
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(updatedLogs));

    setExercises((prev) =>
      prev.map((e, i) => (i === index ? { ...e, completed: true } : e))
    );
  };

  const completedExercises = exercises.filter((e) => e.completed).length;
  const allDone = exercises.length > 0 && completedExercises === exercises.length;

  const markDayComplete = () => {
    const updated = { ...completedDays, [selectedDay]: true };
    setCompletedDays(updated);
    localStorage.setItem(STORAGE_KEY_COMPLETED, JSON.stringify(updated));
    if (user) {
      supabase.from("training_sessions").insert({
        user_id: user.id,
        level,
        phase,
        mode,
        duration_min: null,
      }).then(({ error }) => { if (error) console.warn(error.message); });
    }
    window.dispatchEvent(new CustomEvent("cyra_training_complete"));
  };

  const changeFrequency = () => {
    setFrequency(null);
    localStorage.removeItem(STORAGE_KEY_FREQ);
    localStorage.removeItem(STORAGE_KEY_LEVEL);
    localStorage.removeItem(STORAGE_KEY_COMPLETED);
    localStorage.removeItem(STORAGE_KEY_LOGS);
    localStorage.removeItem(STORAGE_KEY_START_DATE);
  };

  if (!frequency) {
    return <FrequencySelector onSelect={handleSelectFrequency} />;
  }

  const isRestDay = currentWorkout?.type === "rest";

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="gradient-warm pt-12 pb-6 px-5">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground font-medium">
                {phaseInfo.emoji} Fase {phaseInfo.name}
              </p>
              <h1 className="text-2xl font-heading font-bold text-foreground mt-0.5">
                {(phaseInfo.intensity === "Baja" || phaseInfo.intensity === "Moderada") ? "Cyra Flow" : "Cyra Power"}
              </h1>
              <p className="text-[11px] text-primary font-semibold mt-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Semana {meso.week} · {meso.label}
              </p>
            </div>
            <button
              onClick={changeFrequency}
              className="text-xs text-primary font-semibold flex items-center gap-1 bg-secondary px-3 py-1.5 rounded-full"
            >
              <RotateCcw className="w-3 h-3" />
              {LEVEL_LABELS[level]} · {frequency}d/sem
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 space-y-4 -mt-2">
        {/* Post parto toggle */}
        <button
          onClick={togglePostpartum}
          className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl text-sm font-semibold transition-all border ${
            isPostpartum
              ? "bg-primary text-primary-foreground border-primary shadow-soft"
              : "bg-card text-foreground border-border hover:bg-secondary/50"
          }`}
        >
          <Baby className="w-4 h-4" />
            {isPostpartum ? "Entrenamiento Post Parto activado" : "Activar entrenamiento Post Parto"}
        </button>

        {/* Week day selector */}
        <div className="flex gap-1.5">
          {DAY_NAMES.map((day, i) => {
            const isTraining = weekPlan[i]?.type !== "rest";
            const isDone = completedDays[i];
            const isSelected = selectedDay === i;

            return (
              <button
                key={day}
                onClick={() => setSelectedDay(i)}
                className={`flex-1 flex flex-col items-center py-2 rounded-xl transition-all text-center ${
                  isSelected
                    ? "bg-primary text-primary-foreground shadow-soft"
                    : isDone
                    ? "bg-secondary/80 text-secondary-foreground"
                    : "bg-card text-foreground"
                }`}
              >
                <span className="text-[10px] font-medium opacity-70">{day}</span>
                <span className="text-xs font-bold mt-0.5">
                  {isDone ? "✓" : isTraining ? weekPlan[i].emoji : "😴"}
                </span>
              </button>
            );
          })}
        </div>

        {/* Phase / postpartum note */}
        <div className="flex items-start gap-2 bg-secondary/50 rounded-xl p-3">
          <Info className="w-4 h-4 text-primary mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground leading-relaxed">
              {getPhaseTrainingNote(phase, mode)}
            </p>
            {isPostpartum ? (
              <p className="text-[10px] text-muted-foreground/80 leading-relaxed">
                {getPostpartumCardioTip()}
              </p>
            ) : (
              <p className="text-[10px] text-muted-foreground/80 leading-relaxed">
                {getLevelTrainingTip(level)}
              </p>
            )}
            {rpeReminder && (
              <p className="text-[10px] text-primary/90 leading-relaxed font-medium">
                {rpeReminder}
              </p>
            )}
            {isPostpartum && (
              <p className="text-[10px] text-primary/80 leading-relaxed font-medium">
                💗 Sesiones de 20–25 min. Puedes repetir la misma sesión el mismo día si te sientes con energía.
              </p>
            )}
          </div>
        </div>


        <AnimatePresence mode="wait">
          <motion.div
            key={`${selectedDay}-${level}-${mode}-${meso.block}`}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.2 }}
          >
            {isRestDay ? (
              <div className="glass-card rounded-2xl p-8 text-center space-y-3">
                <span className="text-5xl">😴</span>
                <h2 className="font-heading font-bold text-lg text-foreground">
                  Día de Descanso
                </h2>
                <p className="text-sm text-muted-foreground">
                  La recuperación es parte del progreso. Tu cuerpo se fortalece mientras descansas.
                </p>
                <div className="flex flex-wrap justify-center gap-2 pt-2">
                  {["Caminar", "Estiramientos", "Yoga suave", "Meditar"].map((a) => (
                    <span
                      key={a}
                      className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full font-medium"
                    >
                      {a}
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {/* Session card */}
                <div className="gradient-primary rounded-2xl p-5 text-primary-foreground">
                  <div className="flex items-center justify-between mb-2">
                    <h2 className="font-heading font-bold text-lg">
                      {currentWorkout.emoji} {currentWorkout.label}
                    </h2>
                    <div className="flex items-center gap-2 flex-wrap justify-end">
                      <span className="text-[10px] bg-background/20 px-2 py-0.5 rounded-full font-medium">
                        {LEVEL_LABELS[level]}
                      </span>
                      <span className="text-[10px] bg-background/20 px-2 py-0.5 rounded-full font-medium">
                        Bloque {meso.block}
                      </span>
                      <span className="text-xs bg-background/20 px-3 py-1 rounded-full font-medium">
                        RPE {targetRPE.min}–{targetRPE.max}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs opacity-80">{DAY_NAMES_FULL[selectedDay]} · {meso.label}</p>
                  <div className="flex gap-4 text-sm opacity-90 mt-2">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" /> {level === "beginner" ? "30" : level === "advanced" ? "50" : "40"} min
                    </span>
                    <span className="flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5" /> ~{level === "beginner" ? "180" : level === "advanced" ? "380" : "280"} kcal
                    </span>
                    <span className="flex items-center gap-1">
                      <Dumbbell className="w-3.5 h-3.5" /> {exercises.length} ejercicios
                    </span>
                  </div>
                </div>

                {/* Progress */}
                <div className="flex items-center justify-between mt-4">
                  <p className="text-sm font-medium text-foreground">
                    {completedExercises}/{exercises.length} completados
                  </p>
                  <div className="h-2 w-32 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      className="h-full gradient-primary rounded-full"
                      animate={{
                        width: `${exercises.length > 0 ? (completedExercises / exercises.length) * 100 : 0}%`,
                      }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                </div>

                {/* Exercise list */}
                <div className="space-y-2 mt-3">
                  {exercises.map((ex, i) => {
                    const logKey = `${selectedDay}-${ex.name}`;
                    const log = exerciseLogs[logKey];
                    return (
                      <motion.button
                        key={`${selectedDay}-${ex.name}`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.04 }}
                        onClick={() => setSelectedExerciseIndex(i)}
                        className={`w-full glass-card rounded-xl p-4 flex items-center gap-3 text-left transition-all ${
                          ex.completed ? "opacity-70" : ""
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                            ex.completed
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {ex.completed ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <span className="text-xs font-bold">{i + 1}</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p
                            className={`text-sm font-semibold ${
                              ex.completed ? "line-through text-muted-foreground" : "text-foreground"
                            }`}
                          >
                            {ex.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {log
                              ? `${log.weight}kg · ${log.actualSets}×${log.actualReps} · RPE ${log.rpe}`
                              : `${ex.sets} series · ${ex.reps} · Descanso ${ex.rest}`}
                          </p>
                          <div className="flex flex-wrap items-center gap-1.5 mt-1">
                            {ex.tempo && !log && (
                              <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                                Tempo {ex.tempo}
                              </span>
                            )}
                            {ex.note && !log && (
                              <span className="text-[10px] text-primary/70">💡 {ex.note}</span>
                            )}
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                      </motion.button>
                    );
                  })}
                </div>

                {/* Complete day button */}
                {allDone && !completedDays[selectedDay] && (
                  <motion.button
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    onClick={markDayComplete}
                    className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl mt-4 shadow-glow active:scale-[0.98] transition-transform"
                  >
                    ✅ Marcar día completado
                  </motion.button>
                )}

                {completedDays[selectedDay] && (
                  <div className="text-center py-4 space-y-3">
                    <span className="block text-sm font-semibold text-primary">
                      ✅ ¡Día completado! Buen trabajo 💪
                    </span>
                    {isPostpartum && (
                      <button
                        onClick={repeatSession}
                        className="inline-flex items-center gap-2 text-xs font-semibold text-primary bg-secondary px-4 py-2 rounded-full"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Repetir sesión
                      </button>
                    )}
                  </div>
                )}

              </>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Day navigation */}
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={() => setSelectedDay(Math.max(0, selectedDay - 1))}
            disabled={selectedDay === 0}
            className="flex items-center gap-1 text-sm text-primary font-medium disabled:opacity-30"
          >
            <ChevronLeft className="w-4 h-4" /> Anterior
          </button>
          <button
            onClick={() => setSelectedDay(Math.min(6, selectedDay + 1))}
            disabled={selectedDay === 6}
            className="flex items-center gap-1 text-sm text-primary font-medium disabled:opacity-30"
          >
            Siguiente <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Exercise detail modal */}
      {selectedExerciseIndex !== null && exercises[selectedExerciseIndex] && (
        <ExerciseDetailModal
          exercise={exercises[selectedExerciseIndex]}
          isOpen={selectedExerciseIndex !== null}
          onClose={() => setSelectedExerciseIndex(null)}
          onSave={(log) => handleSaveExerciseLog(selectedExerciseIndex, log)}
          existingLog={exerciseLogs[`${selectedDay}-${exercises[selectedExerciseIndex].name}`]}
          targetRPE={targetRPE}
        />
      )}

      {/* Training celebration */}
      {frequency && (
        <TrainingCelebration
          frequency={frequency}
          completedDays={completedDays}
          weekPlanTypes={weekPlan.map(w => w.type)}
        />
      )}

      <BottomNav />
    </div>
  );
};

export default Training;
