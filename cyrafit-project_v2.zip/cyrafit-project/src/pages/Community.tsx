import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Heart, Image as ImageIcon, MessageCircle, Pin, Plus, Sparkles, Trash2, X } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import BottomNav from "@/components/BottomNav";
import NotificationBell from "@/components/NotificationBell";
import CommunitySocialBar from "@/components/CommunitySocialBar";
import { uploadCommunityImage } from "@/lib/communityUpload";

type Post = {
  id: string;
  author_id: string;
  title: string;
  content: string;
  excerpt: string | null;
  image_url: string | null;
  pinned: boolean;
  created_at: string;
};

type Counts = { reactions: number; comments: number };

const Community = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { isAdmin } = useIsAdmin();
  const [posts, setPosts] = useState<Post[]>([]);
  const [counts, setCounts] = useState<Record<string, Counts>>({});
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [pinned, setPinned] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate("/");
  }, [authLoading, user, navigate]);

  const fetchAll = async () => {
    const [p, r, c] = await Promise.all([
      supabase
        .from("community_posts")
        .select("id, author_id, title, content, excerpt, image_url, pinned, created_at")
        .order("pinned", { ascending: false })
        .order("created_at", { ascending: false }),
      supabase.from("community_post_reactions").select("post_id"),
      supabase.from("community_comments").select("post_id"),
    ]);
    setPosts((p.data as Post[]) ?? []);
    const map: Record<string, Counts> = {};
    ((r.data as { post_id: string }[]) ?? []).forEach((row) => {
      map[row.post_id] = { ...(map[row.post_id] ?? { reactions: 0, comments: 0 }), reactions: (map[row.post_id]?.reactions ?? 0) + 1 };
    });
    ((c.data as { post_id: string }[]) ?? []).forEach((row) => {
      map[row.post_id] = { ...(map[row.post_id] ?? { reactions: 0, comments: 0 }), comments: (map[row.post_id]?.comments ?? 0) + 1 };
    });
    setCounts(map);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) return;
    void fetchAll();
    const channel = supabase
      .channel("community-feed")
      .on("postgres_changes", { event: "*", schema: "public", table: "community_posts" }, fetchAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "community_post_reactions" }, fetchAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "community_comments" }, fetchAll)
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const pickImage = (file: File | null) => {
    setImage(file);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(file ? URL.createObjectURL(file) : null);
  };

  const createPost = async () => {
    if (!user || !title.trim() || !content.trim()) return;
    setSaving(true);
    let image_url: string | null = null;
    if (image) {
      const res = await uploadCommunityImage(user.id, image, "posts");
      if (res.error) {
        setSaving(false);
        return toast.error(res.error);
      }
      image_url = res.url;
    }
    const { error } = await supabase.from("community_posts").insert({
      author_id: user.id,
      title: title.trim(),
      excerpt: excerpt.trim() || null,
      content: content.trim(),
      image_url,
      pinned,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Publicación creada ✨");
    setTitle("");
    setExcerpt("");
    setContent("");
    pickImage(null);
    setPinned(false);
    if (fileRef.current) fileRef.current.value = "";
    setOpen(false);
  };

  const deletePost = async (id: string) => {
    if (!confirm("¿Eliminar esta publicación?")) return;
    const { error } = await supabase.from("community_posts").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Eliminada");
  };

  const togglePin = async (post: Post) => {
    const { error } = await supabase
      .from("community_posts")
      .update({ pinned: !post.pinned })
      .eq("id", post.id);
    if (error) toast.error(error.message);
  };

  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1 }}
          className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="bg-card border-b border-border sticky top-0 z-20 backdrop-blur">
        <div className="max-w-2xl mx-auto px-4 py-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="min-w-0">
                <h1 className="text-lg font-heading font-bold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-primary" /> Comunidad
                </h1>
                <p className="text-[11px] text-muted-foreground truncate">
                  Tips e información compartidos por Cyra
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <NotificationBell />
              {isAdmin && (
                <Button size="sm" onClick={() => setOpen(true)}>
                  <Plus className="w-4 h-4 mr-1" /> Nueva
                </Button>
              )}
            </div>
          </div>
          <CommunitySocialBar />
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {posts.length === 0 ? (
          <div className="glass-card rounded-3xl p-8 text-center">
            <Sparkles className="w-8 h-8 text-primary mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Aún no hay publicaciones.
              {isAdmin && " ¡Crea la primera para inspirar a la comunidad!"}
            </p>
          </div>
        ) : (
          posts.map((post) => {
            const c = counts[post.id] ?? { reactions: 0, comments: 0 };
            return (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                onClick={() => navigate(`/community/${post.id}`)}
                className="glass-card rounded-3xl overflow-hidden cursor-pointer hover:shadow-lg transition"
              >
                {post.image_url && (
                  <img
                    src={post.image_url}
                    alt={post.title}
                    className="w-full h-44 object-cover"
                    loading="lazy"
                  />
                )}
                <div className="p-5 space-y-2">
                  {post.pinned && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-primary">
                      <Pin className="w-3 h-3" /> Fijado
                    </span>
                  )}
                  <h2 className="text-base font-heading font-bold text-foreground">
                    {post.title}
                  </h2>
                  <p className="text-[11px] text-muted-foreground">
                    {format(new Date(post.created_at), "dd MMM yyyy", { locale: es })}
                  </p>
                  <p className="text-sm text-foreground/80 line-clamp-3">
                    {post.excerpt || post.content}
                  </p>
                  <div className="flex items-center gap-4 pt-2 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <Heart className="w-3.5 h-3.5" /> {c.reactions}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <MessageCircle className="w-3.5 h-3.5" /> {c.comments}
                    </span>
                    {isAdmin && (
                      <div
                        className="ml-auto flex items-center gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => togglePin(post)}>
                          <Pin className={`w-3.5 h-3.5 ${post.pinned ? "text-primary" : ""}`} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-7 h-7 text-destructive"
                          onClick={() => deletePost(post.id)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </motion.article>
            );
          })
        )}
      </main>

      <BottomNav />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nueva publicación</DialogTitle>
            <DialogDescription>
              Comparte un tip, recurso o información con toda la comunidad.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              placeholder="Título"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={120}
            />
            <Input
              placeholder="Resumen corto (opcional)"
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              maxLength={200}
            />
            <Textarea
              placeholder="Contenido completo..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={8}
              maxLength={8000}
            />
            <div>
              <button
                onClick={() => fileRef.current?.click()}
                className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1"
              >
                <ImageIcon className="w-4 h-4" /> Imagen destacada (opcional)
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => pickImage(e.target.files?.[0] ?? null)}
              />
              {previewUrl && (
                <div className="relative mt-2 inline-block">
                  <img src={previewUrl} alt="preview" className="max-h-40 rounded-lg" />
                  <button
                    onClick={() => pickImage(null)}
                    className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
            <label className="flex items-center gap-2 text-sm text-muted-foreground">
              <input
                type="checkbox"
                checked={pinned}
                onChange={(e) => setPinned(e.target.checked)}
              />
              Fijar arriba
            </label>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button onClick={createPost} disabled={saving || !title.trim() || !content.trim()}>
              {saving ? "Publicando..." : "Publicar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Community;
