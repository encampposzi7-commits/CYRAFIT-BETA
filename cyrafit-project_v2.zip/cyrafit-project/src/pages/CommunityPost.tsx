import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Heart, Pin } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";
import NotificationBell from "@/components/NotificationBell";
import CommunityComments from "@/components/CommunityComments";

type Post = {
  id: string;
  author_id: string;
  title: string;
  content: string;
  excerpt: string | null;
  image_url: string | null;
  pinned: boolean;
  created_at: string;
};

const CommunityPost = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);
  const [reactionCount, setReactionCount] = useState(0);
  const [iReacted, setIReacted] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate("/");
  }, [authLoading, user, navigate]);

  const load = async () => {
    if (!id) return;
    const [p, r] = await Promise.all([
      supabase.from("community_posts").select("*").eq("id", id).maybeSingle(),
      supabase.from("community_post_reactions").select("user_id").eq("post_id", id),
    ]);
    setPost((p.data as Post) ?? null);
    const reactions = (r.data as { user_id: string }[]) ?? [];
    setReactionCount(reactions.length);
    setIReacted(!!user && reactions.some((row) => row.user_id === user.id));
    setLoading(false);
  };

  useEffect(() => {
    void load();
    if (!id) return;
    const channel = supabase
      .channel(`post-${id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "community_post_reactions", filter: `post_id=eq.${id}` },
        load,
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "community_posts", filter: `id=eq.${id}` },
        load,
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, user?.id]);

  const toggleReaction = async () => {
    if (!user || !post) return;
    if (iReacted) {
      const { error } = await supabase
        .from("community_post_reactions")
        .delete()
        .eq("post_id", post.id)
        .eq("user_id", user.id);
      if (error) toast.error(error.message);
    } else {
      const { error } = await supabase
        .from("community_post_reactions")
        .insert({ post_id: post.id, user_id: user.id });
      if (error) toast.error(error.message);
    }
  };

  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1 }}
          className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-3">
        <p className="text-sm text-muted-foreground">Esta publicación ya no existe.</p>
        <Button onClick={() => navigate("/community")}>Volver a la comunidad</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="bg-card border-b border-border sticky top-0 z-20 backdrop-blur">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={() => navigate("/community")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <NotificationBell />
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5 space-y-6">
        <motion.article
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-3xl overflow-hidden"
        >
          {post.image_url && (
            <img src={post.image_url} alt={post.title} className="w-full max-h-80 object-cover" />
          )}
          <div className="p-5 space-y-3">
            {post.pinned && (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-primary">
                <Pin className="w-3 h-3" /> Fijado
              </span>
            )}
            <h1 className="text-xl font-heading font-bold text-foreground">{post.title}</h1>
            <p className="text-[11px] text-muted-foreground">
              {format(new Date(post.created_at), "dd 'de' MMMM yyyy · HH:mm", { locale: es })}
            </p>
            <p className="text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">
              {post.content}
            </p>
            <div className="pt-2">
              <button
                onClick={toggleReaction}
                className={`inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full transition ${
                  iReacted
                    ? "bg-primary/15 text-primary"
                    : "bg-secondary/40 text-muted-foreground hover:bg-secondary/60"
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${iReacted ? "fill-primary" : ""}`} />
                {reactionCount}
              </button>
            </div>
          </div>
        </motion.article>

        <CommunityComments postId={post.id} />
      </main>

      <BottomNav />
    </div>
  );
};

export default CommunityPost;
