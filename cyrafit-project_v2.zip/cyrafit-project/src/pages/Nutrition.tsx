import { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { Settings2, Info, Lightbulb, Lock } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import NutritionProfileSetup from "@/components/NutritionProfileSetup";
import RecipeHelperModal from "@/components/RecipeHelperModal";
import PremiumModal from "@/components/PremiumModal";
import { usePremium } from "@/hooks/usePremium";
import { useAuth } from "@/contexts/AuthContext";
import { useCycleData } from "@/hooks/useCycleData";
import {
  NutritionProfile,
  NutritionResult,
  calculateNutrition,
  saveNutritionProfile,
  loadNutritionProfile,
  getBmiLabel,
  ACTIVITY_LABELS,
  GOAL_LABELS,
} from "@/lib/nutrition";
import NutritionCoaching from "@/components/NutritionCoaching";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const Nutrition = () => {
  const { profile: authProfile } = useAuth();
  const { isPremium } = usePremium();
  const { phase } = useCycleData();
  const [profile, setProfile] = useState<NutritionProfile | null>(null);
  const [showSetup, setShowSetup] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [showRecipeHelper, setShowRecipeHelper] = useState(false);
  const [showPremium, setShowPremium] = useState(false);

  useEffect(() => {
    const saved = loadNutritionProfile();
    if (saved) setProfile(saved);
    else setShowSetup(true);
  }, []);

  const result: NutritionResult | null = useMemo(() => (profile ? calculateNutrition(profile) : null), [profile]);

  const handleProfileComplete = (p: NutritionProfile) => {
    setProfile(p);
    saveNutritionProfile(p);
    setShowSetup(false);
  };

  const goalCalories = result?.targetCalories || 1800;

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="gradient-warm pt-12 pb-6 px-5">
        <div className="max-w-lg mx-auto flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground font-medium">🍽️ Diario alimenticio</p>
            <h1 className="text-2xl font-heading font-bold text-foreground mt-0.5">Cyra Fuel</h1>
          </div>
          <button onClick={() => setShowSetup(true)} className="mt-1 p-2 rounded-xl bg-secondary/60 hover:bg-secondary transition-colors" title="Ajustar perfil">
            <Settings2 className="w-5 h-5 text-primary" />
          </button>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 space-y-5 -mt-2">
        {showSetup && (
          <div className="mb-4">
            <NutritionProfileSetup
              onComplete={handleProfileComplete}
              initial={profile}
              presetName={authProfile?.name ?? undefined}
            />
          </div>
        )}

        {result && !showSetup && (
          <>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-2xl p-5">
              <button onClick={() => setShowInfo(true)} className="w-full flex items-center gap-2 mb-4 p-2.5 rounded-xl bg-primary/8 border border-primary/15">
                <Info className="w-4 h-4 text-primary flex-shrink-0" />
                <div className="text-left flex-1">
                  <p className="text-xs font-medium text-foreground">
                    {GOAL_LABELS[profile!.goal]} · IMC {result.bmi} ({getBmiLabel(result.bmiCategory)})
                  </p>
                  <p className="text-[10px] text-muted-foreground">Toca para ver el desglose completo</p>
                </div>
              </button>

              <div className="text-center mb-4">
                <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-semibold">Estimativo diario</p>
                <p className="text-4xl font-heading font-bold text-foreground mt-1">{goalCalories}</p>
                <p className="text-xs text-muted-foreground">kcal recomendadas (Mifflin-St Jeor)</p>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="bg-primary/10 rounded-xl p-3 text-center">
                  <p className="text-lg font-bold text-primary">{result.proteinG}g</p>
                  <p className="text-[10px] text-muted-foreground">Proteína</p>
                </div>
                <div className="bg-accent/10 rounded-xl p-3 text-center">
                  <p className="text-lg font-bold text-accent">{result.carbsG}g</p>
                  <p className="text-[10px] text-muted-foreground">Carbos</p>
                </div>
                <div className="bg-rosa-light/20 rounded-xl p-3 text-center">
                  <p className="text-lg font-bold text-foreground">{result.fatG}g</p>
                  <p className="text-[10px] text-muted-foreground">Grasa</p>
                </div>
              </div>
            </motion.div>

            {/* Nutrition coaching: distribución del plato, 3 recetas, consejos */}
            {profile && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-2xl p-5">
                <NutritionCoaching goal={profile.goal} />
              </motion.div>
            )}
          </>
        )}
      </div>

      {/* Floating recipe helper button */}
      {profile && !showSetup && (
        <motion.button
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5, type: "spring" }}
          onClick={() => isPremium ? setShowRecipeHelper(true) : setShowPremium(true)}
          className="fixed left-4 bottom-24 z-40 w-14 h-14 rounded-full gradient-primary shadow-glow flex items-center justify-center"
          title="Cyra Coach · sugerencias de recetas"
        >
          <Lightbulb className="w-6 h-6 text-primary-foreground" />
          {!isPremium && (
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-foreground text-background flex items-center justify-center shadow-md">
              <Lock className="w-2.5 h-2.5" />
            </span>
          )}
        </motion.button>
      )}

      <PremiumModal
        open={showPremium}
        onOpenChange={setShowPremium}
        reason="Cyra Coach Nutrición sugiere recetas según los alimentos que tienes en casa. Disponible solo en Premium."
      />

      {/* Info dialog */}
      <Dialog open={showInfo} onOpenChange={setShowInfo}>
        <DialogContent className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="font-heading">Tu plan nutricional</DialogTitle>
            <DialogDescription>Cálculo personalizado Mifflin-St Jeor</DialogDescription>
          </DialogHeader>
          {result && profile && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-secondary/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">IMC</p>
                  <p className="font-bold text-foreground">{result.bmi}</p>
                  <p className="text-xs text-primary">{getBmiLabel(result.bmiCategory)}</p>
                </div>
                <div className="bg-secondary/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">TMB</p>
                  <p className="font-bold text-foreground">{result.bmr} kcal</p>
                  <p className="text-xs text-muted-foreground">Tasa metabólica</p>
                </div>
                <div className="bg-secondary/50 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">TDEE</p>
                  <p className="font-bold text-foreground">{result.tdee} kcal</p>
                  <p className="text-xs text-muted-foreground">Gasto total</p>
                </div>
                <div className="bg-primary/10 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Objetivo</p>
                  <p className="font-bold text-primary">{result.targetCalories} kcal</p>
                  <p className="text-xs text-muted-foreground">Meta diaria</p>
                </div>
              </div>
              {result.adjustedWeight && (
                <div className="bg-accent/10 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground">Peso ideal (Devine): {result.idealWeight} kg</p>
                  <p className="text-xs text-muted-foreground">Peso ajustado: {result.adjustedWeight} kg</p>
                  <p className="text-[10px] text-muted-foreground italic mt-1">Los macros se calculan con el peso ajustado</p>
                </div>
              )}
              <div className="space-y-2">
                <h4 className="font-heading font-semibold text-foreground">Macronutrientes diarios</h4>
                <div className="flex gap-2">
                  <div className="flex-1 bg-primary/10 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-primary">{result.proteinG}g</p>
                    <p className="text-[10px] text-muted-foreground">Proteína</p>
                    <p className="text-[10px] text-muted-foreground">{result.proteinKcal} kcal</p>
                  </div>
                  <div className="flex-1 bg-accent/10 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-accent">{result.carbsG}g</p>
                    <p className="text-[10px] text-muted-foreground">Carbos</p>
                    <p className="text-[10px] text-muted-foreground">{result.carbsKcal} kcal</p>
                  </div>
                  <div className="flex-1 bg-rosa-light/20 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-rosa-light">{result.fatG}g</p>
                    <p className="text-[10px] text-muted-foreground">Grasa</p>
                    <p className="text-[10px] text-muted-foreground">{result.fatKcal} kcal</p>
                  </div>
                </div>
              </div>
              <div className="text-[10px] text-muted-foreground space-y-0.5">
                <p>📊 Actividad: {ACTIVITY_LABELS[profile.activityLevel]}</p>
                <p>🎯 Objetivo: {GOAL_LABELS[profile.goal]}</p>
                <p>📏 {profile.heightCm}cm · {profile.weightKg}kg · {profile.age} años</p>
                <p className="text-primary font-medium">⚠️ Mínimo recomendado: 1300 kcal/día</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Recipe helper modal */}
      {profile && (
        <RecipeHelperModal
          isOpen={showRecipeHelper}
          onClose={() => setShowRecipeHelper(false)}
          goal={profile.goal}
          phase={phase}
        />
      )}

      <BottomNav />
    </div>
  );
};

export default Nutrition;
