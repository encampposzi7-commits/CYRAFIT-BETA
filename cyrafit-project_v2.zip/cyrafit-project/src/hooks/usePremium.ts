import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export type PremiumStatus = {
  isPremium: boolean;
  source: string | null;
  expiresAt: string | null;
  loading: boolean;
};

export function usePremium(): PremiumStatus & { refresh: () => Promise<void> } {
  const { user } = useAuth();
  const [status, setStatus] = useState<PremiumStatus>({ isPremium: false, source: null, expiresAt: null, loading: true });

  const fetchStatus = useCallback(async () => {
    if (!user) { setStatus({ isPremium: false, source: null, expiresAt: null, loading: false }); return; }
    const { data, error } = await supabase
      .from("profile" as any)
      .select("is_premium, premium_source, premium_expires_at")
      .eq("id", user.id)
      .maybeSingle();
    if (error) { setStatus(s => ({ ...s, loading: false })); return; }
    const row = data as any;
    const expiresAt = row?.premium_expires_at ?? null;
    const stillValid = !expiresAt || new Date(expiresAt) > new Date();
    setStatus({ isPremium: !!row?.is_premium && stillValid, source: row?.premium_source ?? null, expiresAt, loading: false });
  }, [user]);

  useEffect(() => {
    void fetchStatus();
    if (!user) return;
    const channel = supabase
      .channel(`profile-premium-${user.id}-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "profile", filter: `id=eq.${user.id}` }, () => void fetchStatus())
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [user, fetchStatus]);

  return { ...status, refresh: fetchStatus };
}
