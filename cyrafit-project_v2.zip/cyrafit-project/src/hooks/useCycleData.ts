import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  CycleSettings,
  DEFAULT_CYCLE_SETTINGS,
  PhaseInfo,
  PHASES,
  POSTPARTUM_INFO,
  projectCycle,
  getCycleDay,
  getCurrentPhase,
  CyclePhase,
  estimateAvgCycleLength,
  getRegularity,
  Regularity,
  daysBetween,
} from "@/lib/cycle";

const STORAGE_KEY_LEGACY_DATE = "lunafit_last_period_date";

interface CycleSettingsRow {
  user_id: string;
  avg_cycle_length: number;
  avg_period_length: number;
  mode: 'cycle' | 'postpartum';
  postpartum_start_date: string | null;
  track_period_postpartum: boolean;
}

interface PeriodLogRow {
  id: string;
  user_id: string;
  start_date: string;
  end_date: string | null;
  flow: 'light' | 'medium' | 'heavy' | null;
}

function rowToSettings(row: CycleSettingsRow | null, lastPeriod: Date | null): CycleSettings {
  if (!row) return { ...DEFAULT_CYCLE_SETTINGS, lastPeriodDate: lastPeriod };
  return {
    avgCycleLength: row.avg_cycle_length,
    avgPeriodLength: row.avg_period_length,
    mode: row.mode,
    postpartumStartDate: row.postpartum_start_date ? new Date(row.postpartum_start_date) : null,
    trackPeriodPostpartum: row.track_period_postpartum,
    lastPeriodDate: lastPeriod,
  };
}

/**
 * Derive period "starts" (first day of each contiguous run) from a list of
 * individually marked period days. Returned sorted DESC (most recent first).
 */
function deriveStarts(markedDays: Date[]): Date[] {
  if (markedDays.length === 0) return [];
  const asc = [...markedDays]
    .map((d) => {
      const x = new Date(d);
      x.setHours(0, 0, 0, 0);
      return x;
    })
    .sort((a, b) => a.getTime() - b.getTime());
  const starts: Date[] = [];
  for (let i = 0; i < asc.length; i++) {
    if (i === 0 || daysBetween(asc[i - 1], asc[i]) > 1) {
      starts.push(asc[i]);
    }
  }
  return starts.reverse();
}

export interface CycleDataApi {
  loading: boolean;
  isConfigured: boolean;
  settings: CycleSettings;
  cycleDay: number;
  phase: CyclePhase;
  phaseInfo: PhaseInfo;
  /** Phase derived from projection (no pending override). */
  projectedPhase: CyclePhase;
  /** True when predicted period start has arrived but user hasn't confirmed today yet. */
  pendingPeriodStart: boolean;
  lastPeriodDate: Date | null;
  hasSetPeriod: boolean;
  regularity: Regularity;
  nextPeriodDate: Date | null;
  daysUntilNextPeriod: number | null;
  ovulationDate: Date | null;
  fertileWindow: { start: Date; end: Date } | null;
  /** All individually marked period days (desc). */
  periodHistory: Date[];
  /** Derived first day of each contiguous run (desc). */
  periodStarts: Date[];
  saveSettings: (next: Partial<CycleSettings>) => Promise<{ error: string | null }>;
  logPeriodStart: (date: Date) => Promise<{ error: string | null }>;
  /** Toggle a single day as period (mark if missing, unmark if present). */
  togglePeriodDay: (date: Date) => Promise<{ error: string | null; marked: boolean }>;
  setLastPeriodDate: (date: Date) => Promise<{ error: string | null }>;
  refresh: () => Promise<void>;
}


function sameDay(a: Date, b: Date) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

export function useCycleData(): CycleDataApi {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [row, setRow] = useState<CycleSettingsRow | null>(null);
  const [periodHistory, setPeriodHistory] = useState<Date[]>([]);

  const fetchAll = useCallback(async () => {
    if (!user) {
      setRow(null);
      setPeriodHistory([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [settingsRes, logsRes] = await Promise.all([
        supabase.from("cycle_settings").select("*").eq("user_id", user.id).maybeSingle(),
        supabase
          .from("period_logs")
          .select("id, user_id, start_date, end_date, flow")
          .eq("user_id", user.id)
          .order("start_date", { ascending: false })
          .limit(365),
      ]);

      if (settingsRes.error) console.error("[useCycleData] settings", settingsRes.error.message);
      if (logsRes.error) console.error("[useCycleData] logs", logsRes.error.message);

      let nextRow = (settingsRes.data as CycleSettingsRow | null) ?? null;

      // One-time migration from localStorage if no row exists yet
      if (!nextRow) {
        const legacy = localStorage.getItem(STORAGE_KEY_LEGACY_DATE);
        if (legacy) {
          const date = new Date(legacy);
          if (!isNaN(date.getTime())) {
            const { data: inserted, error } = await supabase
              .from("cycle_settings")
              .upsert({ user_id: user.id }, { onConflict: "user_id" })
              .select("*")
              .single();
            if (!error && inserted) nextRow = inserted as CycleSettingsRow;
            await supabase
              .from("period_logs")
              .insert({ user_id: user.id, start_date: date.toISOString().slice(0, 10) });
            localStorage.removeItem(STORAGE_KEY_LEGACY_DATE);
          }
        }
      }

      setRow(nextRow);
      setPeriodHistory(
        (logsRes.data ?? []).map((r: PeriodLogRow) => new Date(r.start_date + "T00:00:00")),
      );
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    void fetchAll();
  }, [fetchAll]);

  const periodStarts = useMemo(() => deriveStarts(periodHistory), [periodHistory]);
  const lastPeriodDate = periodStarts[0] ?? null;
  const settings = rowToSettings(row, lastPeriodDate);

  const projection = useMemo(() => projectCycle(settings), [settings]);

  // Pending = expected period day reached but today not yet confirmed by user
  const pendingPeriodStart = useMemo(() => {
    if (!projection) return false;
    if (settings.mode === "postpartum" && !settings.trackPeriodPostpartum) return false;
    if (projection.phase !== "menstrual") return false;
    const today = new Date();
    return !periodHistory.some((d) => sameDay(d, today));
  }, [projection, periodHistory, settings.mode, settings.trackPeriodPostpartum]);

  const projectedPhase: CyclePhase = projection?.phase ?? "follicular";
  // Until user confirms, keep the previous (luteal) phase visible
  const phase: CyclePhase = pendingPeriodStart ? "luteal" : projectedPhase;

  const phaseInfo: PhaseInfo = useMemo(() => {
    if (settings.mode === "postpartum" && !settings.trackPeriodPostpartum) return POSTPARTUM_INFO;
    if (!settings.lastPeriodDate) return PHASES.follicular;
    return PHASES[phase];
  }, [settings.mode, settings.trackPeriodPostpartum, settings.lastPeriodDate, phase]);


  const saveSettings = useCallback(
    async (next: Partial<CycleSettings>): Promise<{ error: string | null }> => {
      if (!user) return { error: "No user" };
      const merged: CycleSettings = { ...settings, ...next };
      const payload = {
        user_id: user.id,
        avg_cycle_length: merged.avgCycleLength,
        avg_period_length: merged.avgPeriodLength,
        mode: merged.mode,
        postpartum_start_date: merged.postpartumStartDate
          ? merged.postpartumStartDate.toISOString().slice(0, 10)
          : null,
        track_period_postpartum: !!merged.trackPeriodPostpartum,
      };
      const { data, error } = await supabase
        .from("cycle_settings")
        .upsert(payload, { onConflict: "user_id" })
        .select("*")
        .single();
      if (error) {
        console.error("[useCycleData] saveSettings", error.message);
        return { error: error.message };
      }
      setRow(data as CycleSettingsRow);
      return { error: null };
    },
    [user, settings],
  );

  const togglePeriodDay = useCallback(
    async (date: Date): Promise<{ error: string | null; marked: boolean }> => {
      if (!user) return { error: "No user", marked: false };
      const iso = date.toISOString().slice(0, 10);
      const existing = periodHistory.find((d) => sameDay(d, date));

      if (existing) {
        const { error } = await supabase
          .from("period_logs")
          .delete()
          .eq("user_id", user.id)
          .eq("start_date", iso);
        if (error) {
          console.error("[useCycleData] togglePeriodDay delete", error.message);
          return { error: error.message, marked: true };
        }
        await fetchAll();
        return { error: null, marked: false };
      }

      const { error } = await supabase
        .from("period_logs")
        .insert({ user_id: user.id, start_date: iso });
      if (error) {
        console.error("[useCycleData] togglePeriodDay insert", error.message);
        return { error: error.message, marked: false };
      }

      // Recompute average cycle length from period starts once we have enough history
      const newHistory = [date, ...periodHistory];
      const newStarts = deriveStarts(newHistory);
      if (newStarts.length >= 2) {
        const est = estimateAvgCycleLength(newStarts, settings.avgCycleLength);
        if (est !== settings.avgCycleLength) {
          await saveSettings({ avgCycleLength: est });
        }
      }
      await fetchAll();
      return { error: null, marked: true };
    },
    [user, periodHistory, settings.avgCycleLength, saveSettings, fetchAll],
  );

  const logPeriodStart = useCallback(
    async (date: Date): Promise<{ error: string | null }> => {
      const res = await togglePeriodDay(date);
      // If it was already marked, treat as success (idempotent)
      if (res.error && !res.marked) return { error: res.error };
      return { error: null };
    },
    [togglePeriodDay],
  );

  const setLastPeriodDate = useCallback(
    (date: Date) => logPeriodStart(date),
    [logPeriodStart],
  );

  const cycleDay = projection?.cycleDay ?? 1;
  const regularity = useMemo(() => getRegularity(periodStarts), [periodStarts]);

  return {
    loading,
    isConfigured: !!row,
    settings,
    cycleDay,
    phase,
    projectedPhase,
    pendingPeriodStart,
    phaseInfo,
    lastPeriodDate,
    hasSetPeriod: !!lastPeriodDate || !!row,
    regularity,
    nextPeriodDate: projection?.nextPeriodDate ?? null,
    daysUntilNextPeriod: projection?.daysUntilNextPeriod ?? null,
    ovulationDate: projection?.ovulationDate ?? null,
    fertileWindow: projection?.fertileWindow ?? null,
    periodHistory,
    periodStarts,
    saveSettings,
    logPeriodStart,
    togglePeriodDay,
    setLastPeriodDate,
    refresh: fetchAll,
  };
}

