import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type CommunityNotification = {
  id: string;
  user_id: string;
  type: "new_post" | "new_comment" | "comment_reply";
  post_id: string | null;
  comment_id: string | null;
  actor_id: string | null;
  title: string;
  read: boolean;
  created_at: string;
};

export function useCommunityNotifications() {
  const { user } = useAuth();
  const [items, setItems] = useState<CommunityNotification[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    if (!user) { setItems([]); setLoading(false); return; }
    const { data, error } = await supabase
      .from("community_notifications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(50);
    if (!error) setItems((data ?? []) as unknown as CommunityNotification[]);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    void fetchAll();
    if (!user) return;
    const channel = supabase
      .channel(`notifications-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "community_notifications", filter: `user_id=eq.${user.id}` }, fetchAll)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, fetchAll]);

  const unreadCount = items.filter((n) => !n.read).length;
  const markAllRead = async () => {
    if (!user || unreadCount === 0) return;
    await supabase.from("community_notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
  };
  const markRead = async (id: string) => {
    await supabase.from("community_notifications").update({ read: true }).eq("id", id);
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };
  const clearAll = async () => {
    if (!user) return;
    await supabase.from("community_notifications").delete().eq("user_id", user.id);
    setItems([]);
  };

  return { items, loading, unreadCount, markAllRead, markRead, clearAll, refresh: fetchAll };
}
