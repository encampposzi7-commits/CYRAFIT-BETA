import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const KEY = "cycra_session_logged";

function detectDevice(): string {
  const ua = navigator.userAgent.toLowerCase();
  if (/ipad|tablet/.test(ua)) return "tablet";
  if (/mobi|iphone|android/.test(ua)) return "mobile";
  return "desktop";
}

export function useTrackAppSession() {
  const { user } = useAuth();
  useEffect(() => {
    if (!user) return;
    const today = new Date().toISOString().slice(0, 10);
    const stamp = `${user.id}:${today}`;
    if (sessionStorage.getItem(KEY) === stamp) return;
    sessionStorage.setItem(KEY, stamp);
    supabase.from("app_sessions").insert({ user_id: user.id, device: detectDevice() }).then(() => {});
  }, [user]);
}
