import { useEffect, useState } from "react";
import { Capacitor } from "@capacitor/core";
import { NativeBiometric } from "capacitor-native-biometric";
import { Fingerprint, Lock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

const SESSION_KEY = "cyra_biometric_passed";

const BiometricGate = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  const [checking, setChecking] = useState(true);
  const [locked, setLocked] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isNative = Capacitor.isNativePlatform();

  const tryAuth = async () => {
    setError(null);
    try {
      const result = await NativeBiometric.isAvailable();
      if (!result.isAvailable) {
        sessionStorage.setItem(SESSION_KEY, "1");
        setLocked(false);
        setChecking(false);
        return;
      }
      await NativeBiometric.verifyIdentity({
        reason: "Desbloquea Cyrafit",
        title: "Acceso a Cyrafit",
        subtitle: "Confirma tu identidad",
        description: "Usa tu huella o rostro para entrar",
      });
      sessionStorage.setItem(SESSION_KEY, "1");
      setLocked(false);
    } catch (e: any) {
      setError("Autenticación cancelada o fallida.");
      setLocked(true);
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    if (!isNative || loading) return;
    if (!user) {
      // not logged in — let auth screen handle it
      setChecking(false);
      setLocked(false);
      return;
    }
    if (sessionStorage.getItem(SESSION_KEY) === "1") {
      setChecking(false);
      setLocked(false);
      return;
    }
    setLocked(true);
    void tryAuth();
  }, [isNative, loading, user]);

  if (!isNative) return <>{children}</>;
  if (checking && locked) {
    return (
      <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-4 bg-background p-6">
        <Fingerprint className="w-16 h-16 text-primary animate-pulse" />
        <p className="text-sm text-muted-foreground">Verificando…</p>
      </div>
    );
  }
  if (locked) {
    return (
      <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-4 bg-background p-6 text-center">
        <Lock className="w-14 h-14 text-primary" />
        <h2 className="font-heading font-bold text-lg text-foreground">Cyrafit bloqueada</h2>
        {error && <p className="text-xs text-muted-foreground max-w-xs">{error}</p>}
        <button
          onClick={tryAuth}
          className="gradient-primary text-primary-foreground font-heading font-bold px-6 py-3 rounded-2xl shadow-glow flex items-center gap-2"
        >
          <Fingerprint className="w-5 h-5" />
          Desbloquear con huella
        </button>
      </div>
    );
  }
  return <>{children}</>;
};

export default BiometricGate;
