import { useState } from "react";
import { Sparkles, Check, Loader2, Crown } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { billing, PREMIUM_PRODUCTS, type BillingProduct } from "@/lib/billing";
import { toast } from "@/hooks/use-toast";

const BENEFITS = [
  "Entrenamientos intermedio y avanzado",
  "Nutrición inteligente con Cyra Coach",
  "Evaluación personalizada con tu coach",
  "Seguimiento y guía constante",
];

interface PremiumModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Optional context message shown above benefits (e.g. "Esta función es Premium"). */
  reason?: string;
}

const PremiumModal = ({ open, onOpenChange, reason }: PremiumModalProps) => {
  const [selected, setSelected] = useState<BillingProduct>(PREMIUM_PRODUCTS[1]); // yearly default
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    setLoading(true);
    const result = await billing.purchase(selected.id);
    setLoading(false);

    if (result.success) {
      toast({ title: "¡Bienvenida a Premium!", description: "Tu suscripción está activa." });
      onOpenChange(false);
    } else {
      toast({
        title: "Suscripción no disponible aún",
        description: result.error ?? "Pronto podrás suscribirte desde Google Play.",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 overflow-hidden border-0 rounded-3xl max-h-[92vh] overflow-y-auto">
        {/* Hero */}
        <div className="gradient-primary px-6 pt-7 pb-5 text-primary-foreground">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5" />
            <span className="text-xs font-semibold uppercase tracking-wider opacity-90">Cyrafit Premium</span>
          </div>
          <DialogHeader className="space-y-1.5 text-left">
            <DialogTitle className="text-2xl font-heading text-primary-foreground leading-tight">
              Este es tu siguiente nivel
            </DialogTitle>
            <DialogDescription className="text-primary-foreground/90 text-sm leading-relaxed">
              {reason ?? "Accede a entrenamientos más desafiantes, nutrición personalizada y el acompañamiento que necesitas para avanzar de verdad."}
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="px-6 py-5 space-y-5 bg-background">
          {/* Launch price badge */}
          <div className="flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-xl px-3 py-2">
            <Crown className="w-4 h-4 text-primary shrink-0" />
            <p className="text-[11px] font-semibold text-foreground leading-tight">
              👉 Precio de lanzamiento exclusivo
            </p>
          </div>

          {/* Benefits */}
          <ul className="space-y-2.5">
            {BENEFITS.map((b) => (
              <li key={b} className="flex items-start gap-2.5">
                <span className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center">
                  <Check className="w-3 h-3 text-primary" />
                </span>
                <span className="text-sm text-foreground leading-snug">{b}</span>
              </li>
            ))}
          </ul>

          {/* Plans */}
          <div className="space-y-2">
            {PREMIUM_PRODUCTS.map((p) => {
              const isYearly = p.period === "yearly";
              const isSelected = selected.id === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelected(p)}
                  className={`relative w-full text-left p-3.5 rounded-2xl border-2 transition-all ${
                    isSelected
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card hover:border-primary/40"
                  }`}
                >
                  {isYearly && (
                    <span className="absolute -top-2 right-3 text-[9px] font-bold uppercase tracking-wider bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                      Recomendado
                    </span>
                  )}
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-foreground">{p.title}</p>
                      <p className="text-xs text-muted-foreground">{p.description}</p>
                    </div>
                    <span className="text-sm font-heading font-bold text-primary whitespace-nowrap">
                      {p.priceLabel}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* CTAs */}
          <div className="space-y-2">
            <Button
              onClick={handleSubscribe}
              disabled={loading}
              className="w-full h-12 rounded-2xl text-base font-semibold gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>✨ Cambiar a Premium</>
              )}
            </Button>
            <button
              onClick={() => onOpenChange(false)}
              className="w-full h-9 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              Seguir con prueba gratuita
            </button>
          </div>

          <p className="text-[10px] text-center text-muted-foreground leading-relaxed">
            Pago gestionado vía Google Play. Cancela cuando quieras desde tu cuenta de Play Store.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PremiumModal;
