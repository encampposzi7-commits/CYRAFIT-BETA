import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChefHat, Utensils, Lightbulb, BookOpen, ChevronDown, ChevronUp } from "lucide-react";
import { Goal, GOAL_LABELS } from "@/lib/nutrition";
import cyraAvatar from "@/assets/cyra-avatar.png";

interface Props {
  goal: Goal;
}

interface Recipe {
  name: string;
  type: "almuerzo" | "cena";
  ingredients: { item: string; rawG?: string; cookedG?: string }[];
  steps: string[];
  adjustment: string;
  macros?: { calories: number; protein: number; carbs: number; fat: number };
}

interface PlateDistribution {
  vegetables: string;
  protein: string;
  carbs: string;
  carbsGrams: string;
  fats: string;
}

function getPlateDistribution(goal: Goal): PlateDistribution {
  switch (goal) {
    case "fat_loss_light":
    case "fat_loss_moderate":
      return {
        vegetables: "1/2 a 3/4 del plato",
        protein: "Alta (palma de la mano o más)",
        carbs: "1/4 del plato o menos",
        carbsGrams: "0 a 80g de CHO cocidos",
        fats: "Controladas (1 cucharada)",
      };
    case "recomposition":
      return {
        vegetables: "1/2 del plato",
        protein: "1/4 del plato",
        carbs: "1/4 del plato",
        carbsGrams: "80 a 120g de CHO cocidos",
        fats: "Moderadas (1-2 cucharadas)",
      };
    case "muscle_gain":
      return {
        vegetables: "1/3 del plato",
        protein: "Alta (1/4+ del plato)",
        carbs: "1/4 del plato (generosos)",
        carbsGrams: "120 a 150g de CHO cocidos",
        fats: "Moderadas a generosas",
      };
  }
}

function getMealDifference(goal: Goal): { lunch: string; dinner: string } {
  if (goal === "fat_loss_light" || goal === "fat_loss_moderate") {
    return {
      lunch: "Incluye carbohidratos complejos (arroz integral, quinoa, camote) para energía. Comida más calórica del día.",
      dinner: "Reduce carbohidratos. Enfócate en proteína + verduras. Aporta recuperación sin exceso calórico.",
    };
  }
  if (goal === "muscle_gain") {
    return {
      lunch: "Porción generosa de carbohidratos + proteína. Ideal post-entrenamiento.",
      dinner: "Mantén proteína alta con carbohidratos moderados. Incluye grasas saludables para hormonas.",
    };
  }
  return {
    lunch: "Equilibrio de macros. Carbohidratos complejos para sostener energía.",
    dinner: "Ligeramente menos carbohidratos. Proteína + verduras + grasas saludables.",
  };
}

function getRecipes(goal: Goal): Recipe[] {
  if (goal === "fat_loss_light" || goal === "fat_loss_moderate") {
    return [
      {
        name: "Bowl proteico mediterráneo",
        type: "almuerzo",
        ingredients: [
          { item: "Pechuga de pollo", rawG: "150g crudo", cookedG: "≈120g cocido" },
          { item: "Ensalada mixta abundante", rawG: "200g" },
          { item: "Quinoa", rawG: "20g crudo", cookedG: "≈60g cocido (15g CHO)" },
          { item: "Pepino, tomate cherry, aceitunas" },
          { item: "Aceite de oliva + limón", rawG: "1 cdta" },
        ],
        steps: ["Cocina el pollo a la plancha con especias.", "Cocina la quinoa y deja enfriar.", "Arma el bowl con la ensalada de base.", "Agrega pollo, quinoa y vegetales.", "Aliña con aceite y limón."],
        adjustment: "CHO cocidos: ~60g quinoa = 15g CHO. Dentro del rango de déficit (hasta 80g cocidos).",
        macros: { calories: 320, protein: 38, carbs: 18, fat: 10 },
      },
      {
        name: "Wrap de lechuga con salmón",
        type: "cena",
        ingredients: [
          { item: "Salmón al horno", rawG: "150g crudo", cookedG: "≈120g cocido" },
          { item: "Hojas grandes de lechuga", rawG: "100g" },
          { item: "Palta", rawG: "1/4 unidad (40g)" },
          { item: "Zanahoria rallada", rawG: "50g" },
          { item: "Salsa de yogur natural", rawG: "30g" },
        ],
        steps: ["Hornea el salmón con limón y eneldo.", "Lava las hojas de lechuga.", "Rellena con salmón desmigado, zanahoria y palta.", "Agrega salsa de yogur."],
        adjustment: "Sin CHO densos en la cena. Ideal para déficit.",
        macros: { calories: 310, protein: 30, carbs: 8, fat: 18 },
      },
    ];
  }

  if (goal === "muscle_gain") {
    return [
      {
        name: "Pasta proteica con pollo y verduras",
        type: "almuerzo",
        ingredients: [
          { item: "Pasta integral", rawG: "60g crudo", cookedG: "≈150g cocido (45g CHO)" },
          { item: "Pechuga de pollo", rawG: "180g crudo", cookedG: "≈145g cocido" },
          { item: "Brócoli, pimentón", rawG: "150g" },
          { item: "Queso parmesano", rawG: "10g" },
          { item: "Aceite de oliva", rawG: "1 cdta" },
        ],
        steps: ["Cocina la pasta al dente.", "Saltea el pollo con verduras.", "Mezcla todo con un hilo de aceite.", "Espolvorea parmesano."],
        adjustment: "CHO cocidos: ~150g pasta = 45g CHO. Dentro del rango de volumen (120-150g cocidos).",
        macros: { calories: 520, protein: 48, carbs: 48, fat: 12 },
      },
      {
        name: "Bowl de arroz con carne y huevo",
        type: "cena",
        ingredients: [
          { item: "Arroz integral", rawG: "50g crudo", cookedG: "≈130g cocido (35g CHO)" },
          { item: "Carne molida magra", rawG: "150g crudo", cookedG: "≈115g cocido" },
          { item: "Huevo frito", rawG: "1 unidad" },
          { item: "Espinacas salteadas", rawG: "80g" },
          { item: "Palta", rawG: "1/4 unidad" },
        ],
        steps: ["Cocina el arroz.", "Saltea la carne con especias.", "Fríe el huevo.", "Arma el bowl con espinacas de base.", "Agrega arroz, carne, huevo y palta."],
        adjustment: "CHO cocidos: ~130g arroz = 35g CHO. Dentro del rango de volumen.",
        macros: { calories: 480, protein: 40, carbs: 38, fat: 18 },
      },
    ];
  }

  // Recomposition
  return [
    {
      name: "Bowl de pollo con quinoa y verduras asadas",
      type: "almuerzo",
      ingredients: [
        { item: "Pechuga de pollo", rawG: "150g crudo", cookedG: "≈120g cocido" },
        { item: "Quinoa", rawG: "30g crudo", cookedG: "≈90g cocido (20g CHO)" },
        { item: "Calabacín, berenjena, pimentón asados", rawG: "150g" },
        { item: "Hummus", rawG: "2 cdas (30g)" },
        { item: "Semillas de sésamo", rawG: "5g" },
      ],
      steps: ["Cocina el pollo a la plancha.", "Cocina la quinoa.", "Asa las verduras en el horno.", "Arma el bowl y agrega hummus.", "Espolvorea semillas."],
      adjustment: "CHO cocidos: ~90g quinoa = 20g CHO. Dentro del rango de mantención (80-120g cocidos).",
      macros: { calories: 380, protein: 40, carbs: 25, fat: 13 },
    },
    {
      name: "Tacos fitness de pescado",
      type: "cena",
      ingredients: [
        { item: "Reineta/merluza", rawG: "150g crudo", cookedG: "≈120g cocido" },
        { item: "Tortillas de maíz", rawG: "2 unidades (50g)" },
        { item: "Repollo morado rallado", rawG: "80g" },
        { item: "Palta", rawG: "1/4 unidad" },
        { item: "Salsa de yogur con cilantro", rawG: "30g" },
      ],
      steps: ["Cocina el pescado a la plancha con limón.", "Calienta las tortillas.", "Arma los tacos con pescado, repollo y palta.", "Agrega salsa de yogur."],
      adjustment: "CHO cocidos: tortillas = ~25g CHO. Dentro del rango de mantención.",
      macros: { calories: 340, protein: 32, carbs: 28, fat: 12 },
    },
  ];
}

function getTips(goal: Goal): string[] {
  const common = [
    "Prepara tus comidas el domingo para tener opciones listas entre semana.",
    "Lleva siempre una botella de agua y bebe al menos 2 litros al día.",
    "Evita comer frente a pantallas: come consciente y mastica bien.",
  ];

  if (goal === "fat_loss_light" || goal === "fat_loss_moderate") {
    return [
      ...common,
      "Incluye proteína en cada comida para mantener la saciedad.",
      "Usa especias y hierbas para dar sabor sin agregar calorías.",
      "Si entrenas, come tu comida con más carbos post-entrenamiento.",
    ];
  }
  if (goal === "muscle_gain") {
    return [
      ...common,
      "Come cada 3-4 horas para mantener el flujo de nutrientes.",
      "Tu comida post-entrenamiento debe incluir carbohidratos + proteína.",
      "No temas a los carbohidratos: son tu combustible para crecer.",
    ];
  }
  return [
    ...common,
    "Equilibra tus platos: no elimines ningún macronutriente.",
    "Si entrenas fuerte, aumenta ligeramente los carbohidratos ese día.",
    "Incluye variedad de colores en tus vegetales para más micronutrientes.",
  ];
}

const NutritionCoaching = ({ goal }: Props) => {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const plate = getPlateDistribution(goal);
  const mealDiff = getMealDifference(goal);
  const recipes = getRecipes(goal);
  const tips = getTips(goal);

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const SectionHeader = ({ id, icon, title }: { id: string; icon: React.ReactNode; title: string }) => (
    <button
      onClick={() => toggleSection(id)}
      className="w-full flex items-center justify-between p-4 rounded-xl bg-card hover:bg-secondary/50 transition-colors"
    >
      <div className="flex items-center gap-3">
        {icon}
        <span className="font-heading font-semibold text-sm text-foreground">{title}</span>
      </div>
      {expandedSection === id ? (
        <ChevronUp className="w-4 h-4 text-muted-foreground" />
      ) : (
        <ChevronDown className="w-4 h-4 text-muted-foreground" />
      )}
    </button>
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-1">
        <div className="w-7 h-7 rounded-full overflow-hidden border border-primary/20">
          <img src={cyraAvatar} alt="Cyra" className="w-full h-full object-cover" />
        </div>
        <h2 className="font-heading font-bold text-base text-foreground">Coach Cyra</h2>
      </div>
      <p className="text-xs text-muted-foreground">
        Guía personalizada según tu objetivo: <span className="text-primary font-medium">{GOAL_LABELS[goal]}</span>
      </p>

      {/* Plate distribution */}
      <div>
        <SectionHeader id="plate" icon={<Utensils className="w-4 h-4 text-primary" />} title="Distribución del plato" />
        <AnimatePresence>
          {expandedSection === "plate" && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="p-4 space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "🥬 Verduras", value: plate.vegetables, color: "bg-green-500/10 border-green-500/20" },
                    { label: "🍗 Proteína", value: plate.protein, color: "bg-primary/10 border-primary/20" },
                    { label: "🍚 Carbohidratos", value: plate.carbs, color: "bg-accent/10 border-accent/20" },
                    { label: "🥑 Grasas", value: plate.fats, color: "bg-yellow-500/10 border-yellow-500/20" },
                  ].map((item) => (
                    <div key={item.label} className={`rounded-xl p-3 border ${item.color}`}>
                      <p className="text-xs font-semibold text-foreground">{item.label}</p>
                      <p className="text-[11px] text-muted-foreground mt-1">{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* CHO grams highlight */}
                <div className="bg-accent/10 border border-accent/20 rounded-xl p-3">
                  <p className="text-xs font-semibold text-foreground">🍚 Gramos de CHO cocidos (cena)</p>
                  <p className="text-sm font-bold text-accent mt-1">{plate.carbsGrams}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {goal === "fat_loss_light" || goal === "fat_loss_moderate"
                      ? "En déficit: mantén los CHO bajos, especialmente en la cena."
                      : goal === "muscle_gain"
                      ? "En volumen: puedes incluir CHO más generosos."
                      : "En mantención: CHO moderados para sostener energía."}
                  </p>
                </div>

                <div className="space-y-2 mt-3">
                  <h4 className="text-xs font-semibold text-foreground">☀️ Almuerzo vs 🌙 Cena</h4>
                  <div className="space-y-1.5">
                    <div className="bg-secondary/50 rounded-lg p-2.5">
                      <p className="text-[10px] font-semibold text-primary">Almuerzo</p>
                      <p className="text-[11px] text-muted-foreground">{mealDiff.lunch}</p>
                    </div>
                    <div className="bg-secondary/50 rounded-lg p-2.5">
                      <p className="text-[10px] font-semibold text-primary">Cena</p>
                      <p className="text-[11px] text-muted-foreground">{mealDiff.dinner}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Recipes */}
      <div>
        <SectionHeader id="recipes" icon={<BookOpen className="w-4 h-4 text-primary" />} title={`Recetas fitness (${recipes.length})`} />
        <AnimatePresence>
          {expandedSection === "recipes" && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="p-4 space-y-3">
                {recipes.map((recipe, i) => (
                  <RecipeCard key={i} recipe={recipe} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Tips */}
      <div>
        <SectionHeader id="tips" icon={<Lightbulb className="w-4 h-4 text-primary" />} title="Consejos prácticos" />
        <AnimatePresence>
          {expandedSection === "tips" && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="p-4 space-y-2">
                {tips.map((tip, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-primary text-xs mt-0.5">✦</span>
                    <p className="text-xs text-muted-foreground">{tip}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const RecipeCard = ({ recipe }: { recipe: Recipe }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="glass-card rounded-xl overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-3 flex items-center justify-between text-left"
      >
        <div>
          <p className="text-sm font-semibold text-foreground">{recipe.name}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">
            {recipe.type === "almuerzo" ? "☀️ Almuerzo" : "🌙 Cena"} · {recipe.ingredients.length} ingredientes
            {recipe.macros && ` · ${recipe.macros.calories} kcal`}
          </p>
        </div>
        {expanded ? (
          <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" />
        ) : (
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
        )}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-2">
              {recipe.macros && (
                <div className="grid grid-cols-4 gap-1.5">
                  <div className="bg-primary/10 rounded-lg p-1.5 text-center">
                    <p className="text-xs font-bold text-primary">{recipe.macros.calories}</p>
                    <p className="text-[8px] text-muted-foreground">kcal</p>
                  </div>
                  <div className="bg-primary/10 rounded-lg p-1.5 text-center">
                    <p className="text-xs font-bold text-foreground">{recipe.macros.protein}g</p>
                    <p className="text-[8px] text-muted-foreground">Prot</p>
                  </div>
                  <div className="bg-accent/10 rounded-lg p-1.5 text-center">
                    <p className="text-xs font-bold text-foreground">{recipe.macros.carbs}g</p>
                    <p className="text-[8px] text-muted-foreground">CHO</p>
                  </div>
                  <div className="bg-rosa-light/20 rounded-lg p-1.5 text-center">
                    <p className="text-xs font-bold text-foreground">{recipe.macros.fat}g</p>
                    <p className="text-[8px] text-muted-foreground">Grasa</p>
                  </div>
                </div>
              )}
              <div>
                <p className="text-[10px] font-semibold text-foreground mb-1">Ingredientes:</p>
                {recipe.ingredients.map((ing, i) => (
                  <div key={i} className="text-[11px] text-muted-foreground">
                    <span>• {ing.item}</span>
                    {ing.rawG && <span className="text-foreground font-medium"> — {ing.rawG}</span>}
                    {ing.cookedG && <span className="text-primary font-medium"> ({ing.cookedG})</span>}
                  </div>
                ))}
              </div>
              <div>
                <p className="text-[10px] font-semibold text-foreground mb-1">Preparación:</p>
                {recipe.steps.map((step, i) => (
                  <p key={i} className="text-[11px] text-muted-foreground">{i + 1}. {step}</p>
                ))}
              </div>
              <div className="bg-primary/5 rounded-lg p-2">
                <p className="text-[10px] text-primary font-medium">💡 {recipe.adjustment}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NutritionCoaching;
