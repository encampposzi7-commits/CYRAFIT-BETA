import { useMemo, useState } from "react";
import { format, isSameDay } from "date-fns";
import { es } from "date-fns/locale";
import { CalendarDays, Droplet, Egg, Settings2, Sparkles } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { addDays, daysBetween } from "@/lib/cycle";
import { useCycleData } from "@/hooks/useCycleData";
import { useToast } from "@/hooks/use-toast";
import EditCycleSettingsDialog from "@/components/EditCycleSettingsDialog";
import { cn } from "@/lib/utils";

/**
 * Calendario visual con seguimiento de ciclo:
 * - Días de menstruación reales (verificados)
 * - Próxima menstruación estimada
 * - Ovulación y ventana fértil
 * Permite registrar inicio de un nuevo periodo tocando un día.
 */
const CycleCalendar = () => {
  const {
    settings,
    periodHistory,
    nextPeriodDate,
    ovulationDate,
    fertileWindow,
    togglePeriodDay,
  } = useCycleData();
  const { toast } = useToast();
  const [openEdit, setOpenEdit] = useState(false);
  const [pendingDate, setPendingDate] = useState<Date | null>(null);
  const [pendingAction, setPendingAction] = useState<"mark" | "unmark">("mark");
  const [saving, setSaving] = useState(false);
  const [month, setMonth] = useState<Date>(new Date());

  // Build modifier date arrays
  const { periodDays, predictedPeriodDays, fertileDays, ovulationDays } = useMemo(() => {
    // Real period days = every individually marked day
    const periodDays: Date[] = [...periodHistory];
    const predictedPeriodDays: Date[] = [];
    const fertileDays: Date[] = [];
    const ovulationDays: Date[] = [];

    // Project the next 3 cycles forward
    if (settings.lastPeriodDate && (settings.mode === "cycle" || settings.trackPeriodPostpartum)) {
      let next = nextPeriodDate ? new Date(nextPeriodDate) : null;
      if (next) {
        for (let c = 0; c < 3; c++) {
          for (let i = 0; i < settings.avgPeriodLength; i++) {
            predictedPeriodDays.push(addDays(next, i));
          }
          const ov = addDays(next, settings.avgCycleLength - 14);
          ovulationDays.push(ov);
          for (let i = -5; i <= 1; i++) fertileDays.push(addDays(ov, i));
          next = addDays(next, settings.avgCycleLength);
        }
      }
      if (ovulationDate) ovulationDays.push(ovulationDate);
      if (fertileWindow) {
        const span = daysBetween(fertileWindow.start, fertileWindow.end);
        for (let i = 0; i <= span; i++) fertileDays.push(addDays(fertileWindow.start, i));
      }
    }
    return { periodDays, predictedPeriodDays, fertileDays, ovulationDays };
  }, [
    periodHistory,
    settings.avgPeriodLength,
    settings.avgCycleLength,
    settings.lastPeriodDate,
    settings.mode,
    settings.trackPeriodPostpartum,
    nextPeriodDate,
    ovulationDate,
    fertileWindow,
  ]);

  const handleDaySelect = (d: Date | undefined) => {
    if (!d) return;
    if (d > new Date()) {
      toast({ title: "Solo puedes registrar fechas pasadas o de hoy." });
      return;
    }
    const already = periodHistory.some((p) => isSameDay(p, d));
    setPendingAction(already ? "unmark" : "mark");
    setPendingDate(d);
  };

  const confirmLog = async () => {
    if (!pendingDate) return;
    setSaving(true);
    const { error, marked } = await togglePeriodDay(pendingDate);
    setSaving(false);
    if (error) {
      toast({ title: "Error", description: error, variant: "destructive" });
    } else {
      toast({
        title: marked ? "Día marcado ✨" : "Día desmarcado",
        description: "Actualicé tu próximo periodo, ovulación y días fértiles.",
      });
    }
    setPendingDate(null);
  };

  return (
    <div className="glass-card rounded-3xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-bold text-foreground">Tu calendario</h3>
        </div>
        <button
          onClick={() => setOpenEdit(true)}
          className="text-[11px] font-semibold text-primary inline-flex items-center gap-1 hover:underline"
        >
          <Settings2 className="w-3 h-3" /> Editar
        </button>
      </div>

      <p className="text-[11px] text-muted-foreground leading-relaxed">
        Toca un día para marcarlo o desmarcarlo como menstruación. Recalculo automáticamente tu
        próximo periodo, ovulación y días fértiles.
      </p>

      <div className="rounded-2xl bg-secondary/30 p-1">
        <Calendar
          mode="single"
          selected={undefined}
          onSelect={handleDaySelect}
          month={month}
          onMonthChange={setMonth}
          locale={es}
          weekStartsOn={1}
          modifiers={{
            period: periodDays,
            predicted: predictedPeriodDays,
            fertile: fertileDays,
            ovulation: ovulationDays,
          }}
          modifiersClassNames={{
            period: "bg-primary/80 text-primary-foreground rounded-full font-semibold",
            predicted:
              "border-2 border-dashed border-primary/60 rounded-full text-primary font-semibold",
            fertile: "bg-accent/20 rounded-full",
            ovulation: "bg-accent text-accent-foreground rounded-full font-bold",
          }}
          disabled={(date) => date > addDays(new Date(), 1)}
          className={cn("p-2 pointer-events-auto")}
        />
      </div>

      {/* Legend */}
      <div className="grid grid-cols-2 gap-1.5 text-[10px]">
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-primary/80" />
          <span className="text-muted-foreground">Menstruación</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full border-2 border-dashed border-primary/60" />
          <span className="text-muted-foreground">Estimada</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-accent/30" />
          <span className="text-muted-foreground">Días fértiles</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-accent" />
          <span className="text-muted-foreground">Ovulación</span>
        </div>
      </div>

      {/* Quick summary */}
      <div className="grid grid-cols-3 gap-1.5 pt-1">
        <div className="rounded-xl bg-secondary/40 p-2 text-center">
          <Droplet className="w-3 h-3 text-primary mx-auto" />
          <p className="text-[9px] text-muted-foreground mt-0.5">Próx.</p>
          <p className="text-[10px] font-bold text-foreground">
            {nextPeriodDate ? format(nextPeriodDate, "dd MMM", { locale: es }) : "—"}
          </p>
        </div>
        <div className="rounded-xl bg-secondary/40 p-2 text-center">
          <Egg className="w-3 h-3 text-accent mx-auto" />
          <p className="text-[9px] text-muted-foreground mt-0.5">Ovul.</p>
          <p className="text-[10px] font-bold text-foreground">
            {ovulationDate ? format(ovulationDate, "dd MMM", { locale: es }) : "—"}
          </p>
        </div>
        <div className="rounded-xl bg-secondary/40 p-2 text-center">
          <Sparkles className="w-3 h-3 text-primary mx-auto" />
          <p className="text-[9px] text-muted-foreground mt-0.5">Fértil</p>
          <p className="text-[10px] font-bold text-foreground">
            {fertileWindow
              ? `${format(fertileWindow.start, "dd", { locale: es })}–${format(fertileWindow.end, "dd MMM", { locale: es })}`
              : "—"}
          </p>
        </div>
      </div>

      <EditCycleSettingsDialog open={openEdit} onOpenChange={setOpenEdit} />

      <AlertDialog open={!!pendingDate} onOpenChange={(v) => !v && setPendingDate(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {pendingAction === "mark" ? "¿Marcar día de menstruación?" : "¿Desmarcar este día?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {pendingAction === "mark" ? "Voy a marcar " : "Voy a quitar la marca de "}
              <span className="font-semibold text-foreground">
                {pendingDate ? format(pendingDate, "EEEE dd 'de' MMMM", { locale: es }) : ""}
              </span>
              {pendingAction === "mark"
                ? " como día de tu periodo y recalcularé tus predicciones."
                : " y recalcularé tus predicciones."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={saving}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmLog} disabled={saving}>
              {saving
                ? "Guardando..."
                : pendingAction === "mark"
                  ? "Sí, marcar"
                  : "Sí, desmarcar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default CycleCalendar;
