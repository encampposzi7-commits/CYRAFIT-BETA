import { useState } from "react";
import { motion } from "framer-motion";
import { Droplets, Plus, Minus } from "lucide-react";

const WaterTracker = () => {
  const [glasses, setGlasses] = useState(3);
  const goal = 8;
  const progress = Math.min(glasses / goal, 1);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="glass-card rounded-2xl p-5"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Droplets className="w-4 h-4 text-primary" />
          <h3 className="font-heading font-semibold text-foreground text-sm">Hidratación</h3>
        </div>
        <span className="text-xs text-muted-foreground font-medium">{glasses}/{goal} vasos</span>
      </div>

      <div className="relative h-3 bg-muted rounded-full overflow-hidden mb-4">
        <motion.div
          className="absolute inset-y-0 left-0 rounded-full gradient-primary"
          initial={{ width: 0 }}
          animate={{ width: `${progress * 100}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>

      <div className="flex items-center justify-center gap-6">
        <button
          onClick={() => setGlasses(Math.max(0, glasses - 1))}
          className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-secondary transition-colors"
        >
          <Minus className="w-4 h-4" />
        </button>
        <span className="text-2xl font-heading font-bold text-foreground">{glasses}</span>
        <button
          onClick={() => setGlasses(Math.min(15, glasses + 1))}
          className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
};

export default WaterTracker;
