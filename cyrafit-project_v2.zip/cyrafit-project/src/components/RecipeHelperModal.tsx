import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Send, ChefHat, Cookie, Drumstick } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Goal } from "@/lib/nutrition";

type CyclePhase = "menstrual" | "follicular" | "ovulatory" | "luteal" | string;

interface RecipeHelperModalProps {
  isOpen: boolean;
  onClose: () => void;
  goal: Goal;
  phase?: CyclePhase;
}

type CravingType = "sweet" | "salty";
type Step = "ask" | "type" | "pantry" | "result";

interface SnackSuggestion {
  name: string;
  why: string; // por qué encaja con tu fase
  required: string[]; // ingredientes que debes tener
  optional: string[]; // extras opcionales (no infaltables)
  steps: string[];
  macros: { calories: number; protein: number; carbs: number; fat: number };
}

// === Reglas del snack saludable ===
// Proteína: 15–20 g · Carbohidratos: ≤30 g · Grasas: ≤10 g
const SNACK_RULES = {
  proteinMin: 15,
  proteinMax: 20,
  carbsMax: 30,
  fatMax: 10,
};

function phaseTip(phase?: CyclePhase): string {
  switch (phase) {
    case "menstrual":
      return "Fase menstrual: prioriza hierro y proteína suave para reponer energía.";
    case "follicular":
      return "Fase folicular: tu sensibilidad a la insulina está alta — aprovecha proteína magra y carbos complejos.";
    case "ovulatory":
      return "Fase ovulatoria: energía pico, ideal para snacks ligeros y antioxidantes.";
    case "luteal":
      return "Fase lútea: aumentan los antojos. Proteína + grasa buena ayudan a saciar y estabilizar el ánimo.";
    default:
      return "Snack equilibrado que cuida tus hormonas.";
  }
}

function has(items: string[], ...keys: string[]) {
  return items.some(i => keys.some(k => i.includes(k)));
}

function generateSnack(pantry: string[], type: CravingType, phase?: CyclePhase): SnackSuggestion | null {
  const items = pantry.map(i => i.toLowerCase().trim()).filter(Boolean);
  const why = phaseTip(phase);

  if (type === "sweet") {
    // Yogurt + frutos
    if (has(items, "yogur", "yogurt") && has(items, "fruta", "frutilla", "berries", "plátano", "platano", "manzana", "arándano", "arandano")) {
      const optional: string[] = [];
      if (has(items, "avena")) optional.push("1 cda de avena");
      if (has(items, "almendra", "nuez", "maní", "mani")) optional.push("5 almendras o 1 nuez");
      if (has(items, "canela")) optional.push("una pizca de canela");
      return {
        name: "Bowl de yogurt griego con fruta",
        why,
        required: ["170 g de yogurt griego natural (≈18 g proteína)", "1/2 taza de fruta picada"],
        optional: optional.length ? optional : ["1 cdta de cacao puro", "ralladura de limón"],
        steps: [
          "Sirve el yogurt en un bowl.",
          "Agrega la fruta picada encima.",
          "Si quieres más textura, suma los opcionales sin pasarte de 30 g de carbos.",
        ],
        macros: { calories: 210, protein: 18, carbs: 22, fat: 4 },
      };
    }

    // Avena + proteína
    if (has(items, "avena") && (has(items, "leche", "bebida vegetal") || has(items, "yogur", "yogurt"))) {
      const base = has(items, "proteína", "proteina", "whey") ? "1 scoop de proteína (≈20 g)" : "170 g de yogurt griego (≈18 g proteína)";
      const optional: string[] = [];
      if (has(items, "plátano", "platano")) optional.push("1/2 plátano en rodajas");
      if (has(items, "canela")) optional.push("canela al gusto");
      if (has(items, "maní", "mani", "almendra")) optional.push("1 cdta de mantequilla de maní/almendra");
      return {
        name: "Avena overnight proteica",
        why,
        required: ["30 g de avena (≈20 g carbos)", base, "100 ml de leche o bebida vegetal"],
        optional: optional.length ? optional : ["esencia de vainilla", "cacao puro"],
        steps: [
          "Mezcla la avena con la leche y deja reposar 10 min (o toda la noche).",
          "Agrega el yogurt o la proteína y revuelve.",
          "Suma los opcionales que tengas sin sobrepasar 30 g de carbos.",
        ],
        macros: { calories: 280, protein: 19, carbs: 28, fat: 6 },
      };
    }

    // Cottage + fruta
    if (has(items, "cottage", "ricota") && has(items, "fruta", "frutilla", "berries", "manzana", "plátano", "platano")) {
      return {
        name: "Cottage con fruta y canela",
        why,
        required: ["150 g de cottage / ricota (≈17 g proteína)", "1/2 taza de fruta picada"],
        optional: [has(items, "canela") ? "canela" : "esencia de vainilla", "1 cdta de miel (solo si lo necesitas)"],
        steps: [
          "Sirve el cottage en un bowl.",
          "Acompaña con la fruta y los opcionales.",
        ],
        macros: { calories: 190, protein: 17, carbs: 18, fat: 4 },
      };
    }

    // Default dulce con huevos
    if (has(items, "huevo")) {
      return {
        name: "Tortita dulce de avena y claras",
        why,
        required: ["3 claras + 1 huevo entero (≈17 g proteína)", "20 g de avena", "canela al gusto"],
        optional: [
          has(items, "plátano", "platano") ? "1/2 plátano pisado" : "endulzante natural",
          has(items, "fruta", "frutilla", "berries") ? "frutillas para acompañar" : "ralladura de limón",
        ],
        steps: [
          "Bate las claras con el huevo, la avena y la canela.",
          "Cocina en sartén antiadherente 2 min por lado.",
          "Acompaña con los opcionales que tengas.",
        ],
        macros: { calories: 230, protein: 17, carbs: 20, fat: 6 },
      };
    }

    return null;
  }

  // SALADO
  if (type === "salty") {
    if (has(items, "huevo")) {
      const optional: string[] = [];
      if (has(items, "palta", "aguacate")) optional.push("1/4 de palta");
      if (has(items, "tomate")) optional.push("tomate cherry");
      if (has(items, "espinaca", "lechuga", "rúcula", "rucula")) optional.push("hojas verdes");
      return {
        name: "Muffins de huevo y verduras",
        why,
        required: ["3 huevos enteros (≈18 g proteína)", "verduras picadas (espinaca, pimiento o lo que tengas)", "pizca de sal y pimienta"],
        optional: optional.length ? optional : ["queso fresco rallado (10 g)"],
        steps: [
          "Bate los huevos con las verduras picadas y la sal.",
          "Vierte en moldes de muffin o sartén pequeño.",
          "Hornea 12 min a 180°C o cocina tapado en sartén 5 min.",
        ],
        macros: { calories: 230, protein: 18, carbs: 4, fat: 9 },
      };
    }

    if (has(items, "atún", "atun")) {
      const optional: string[] = [];
      if (has(items, "palta", "aguacate")) optional.push("1/4 de palta");
      if (has(items, "tomate")) optional.push("tomate cherry");
      if (has(items, "limón", "limon")) optional.push("jugo de limón");
      const carbs = has(items, "galleta de arroz", "arroz inflado", "pan integral") ? "2 galletas de arroz o 1 rebanada de pan integral (≈20 g carbos)" : "1/2 taza de quinoa o arroz cocido (≈20 g carbos)";
      return {
        name: "Bowl rápido de atún",
        why,
        required: ["1 lata de atún al agua escurrido (≈20 g proteína)", "hojas verdes a discreción", carbs],
        optional: optional.length ? optional : ["1 cdta de aceite de oliva", "pepino o pimiento picado"],
        steps: [
          "Escurre el atún y mézclalo con las verduras.",
          "Acompaña con los carbohidratos elegidos.",
          "Aliña con los opcionales que tengas en casa.",
        ],
        macros: { calories: 270, protein: 20, carbs: 22, fat: 6 },
      };
    }

    if (has(items, "pollo", "pechuga")) {
      const optional: string[] = [];
      if (has(items, "palta", "aguacate")) optional.push("1/4 de palta");
      if (has(items, "tomate")) optional.push("tomate cherry");
      return {
        name: "Wrap de pollo y vegetales",
        why,
        required: ["80 g de pollo cocido desmenuzado (≈19 g proteína)", "1 tortilla integral (≈25 g carbos)", "hojas verdes y verdura picada"],
        optional: optional.length ? optional : ["yogurt natural como aderezo", "mostaza Dijon"],
        steps: [
          "Calienta la tortilla unos segundos.",
          "Rellena con el pollo, las verduras y los opcionales.",
          "Enrolla y corta por la mitad.",
        ],
        macros: { calories: 290, protein: 20, carbs: 25, fat: 8 },
      };
    }

    if (has(items, "cottage", "ricota", "queso fresco")) {
      const optional: string[] = [];
      if (has(items, "tomate")) optional.push("tomate en rodajas");
      if (has(items, "orégano", "oregano")) optional.push("orégano");
      const base = has(items, "galleta de arroz", "pan integral") ? "2 galletas de arroz o 1 rebanada de pan integral" : "1 tostada integral";
      return {
        name: "Tostadas saladas con cottage",
        why,
        required: ["150 g de cottage / queso fresco (≈17 g proteína)", base + " (≈20 g carbos)", "pepino o pimiento picado"],
        optional: optional.length ? optional : ["aceite de oliva en spray", "ají molido"],
        steps: [
          "Unta el cottage sobre la tostada o galletas.",
          "Acompaña con las verduras picadas.",
          "Suma los opcionales para más sabor.",
        ],
        macros: { calories: 240, protein: 17, carbs: 22, fat: 5 },
      };
    }

    return null;
  }

  return null;
}

const RecipeHelperModal = ({ isOpen, onClose, goal, phase }: RecipeHelperModalProps) => {
  const [step, setStep] = useState<Step>("ask");
  const [cravingType, setCravingType] = useState<CravingType | null>(null);
  const [pantryText, setPantryText] = useState("");
  const [snack, setSnack] = useState<SnackSuggestion | null>(null);

  const reset = () => {
    setStep("ask");
    setCravingType(null);
    setPantryText("");
    setSnack(null);
    onClose();
  };

  const handleGenerate = () => {
    const items = pantryText.split(/[,\n]/).map(i => i.trim()).filter(Boolean);
    if (!cravingType || items.length === 0) return;
    const s = generateSnack(items, cravingType, phase);
    setSnack(s);
    setStep("result");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={reset} className="fixed inset-0 bg-black/60 z-[60]" />
          <div className="fixed inset-0 z-[61] flex items-center justify-center p-4 pointer-events-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="pointer-events-auto w-full max-w-lg max-h-[85vh] overflow-y-auto rounded-3xl bg-background shadow-2xl"
          >
            <div>
              <div className="flex justify-center pt-3 pb-1">
                <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
              </div>


              <div className="flex items-center justify-between px-5 py-3">
                <h2 className="font-heading font-bold text-lg text-foreground flex items-center gap-2">
                  <ChefHat className="w-5 h-5 text-primary" />
                  Cyra · snack inteligente
                </h2>
                <button onClick={reset} className="p-1.5 rounded-full bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* STEP 1 — antojos sí/no */}
              {step === "ask" && (
                <div className="px-5 pb-8 space-y-4">
                  <div className="bg-primary/5 rounded-xl p-4 text-center">
                    <p className="text-lg font-heading font-bold text-foreground">¿Sientes antojos hoy? 💕</p>
                    <p className="text-xs text-muted-foreground mt-1">{phaseTip(phase)}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={() => setStep("type")}
                      className="gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow"
                    >
                      Sí, ayúdame
                    </motion.button>
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={reset}
                      className="bg-secondary text-foreground font-heading font-bold py-4 rounded-2xl"
                    >
                      No, gracias
                    </motion.button>
                  </div>
                </div>
              )}

              {/* STEP 2 — dulce o salado */}
              {step === "type" && (
                <div className="px-5 pb-8 space-y-4">
                  <button onClick={() => setStep("ask")} className="text-xs text-primary font-medium">← Volver</button>
                  <p className="text-sm font-medium text-foreground text-center">¿Se te antoja dulce o salado?</p>
                  <div className="grid grid-cols-2 gap-3">
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={() => { setCravingType("sweet"); setStep("pantry"); }}
                      className="bg-rosa-light/30 border-2 border-primary/20 hover:border-primary p-5 rounded-2xl flex flex-col items-center gap-2"
                    >
                      <Cookie className="w-7 h-7 text-primary" />
                      <span className="font-heading font-bold text-foreground">Dulce</span>
                    </motion.button>
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={() => { setCravingType("salty"); setStep("pantry"); }}
                      className="bg-accent/20 border-2 border-accent/30 hover:border-accent p-5 rounded-2xl flex flex-col items-center gap-2"
                    >
                      <Drumstick className="w-7 h-7 text-accent" />
                      <span className="font-heading font-bold text-foreground">Salado</span>
                    </motion.button>
                  </div>
                </div>
              )}

              {/* STEP 3 — ingredientes */}
              {step === "pantry" && (
                <div className="px-5 pb-8 space-y-4">
                  <button onClick={() => setStep("type")} className="text-xs text-primary font-medium">← Volver</button>
                  <div className="bg-primary/5 rounded-xl p-3">
                    <p className="text-xs text-primary font-medium">
                      🥗 Antojo {cravingType === "sweet" ? "dulce" : "salado"} · snack equilibrado
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-1">
                      Buscaré una receta con {SNACK_RULES.proteinMin}–{SNACK_RULES.proteinMax} g de proteína, máx {SNACK_RULES.carbsMax} g de carbos y máx {SNACK_RULES.fatMax} g de grasa.
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      ¿Qué ingredientes tienes en casa?
                    </label>
                    <Textarea
                      value={pantryText}
                      onChange={e => setPantryText(e.target.value)}
                      placeholder={cravingType === "sweet"
                        ? "Ej: yogurt griego, avena, plátano, canela, frutillas..."
                        : "Ej: huevos, atún, tomate, palta, pan integral..."}
                      className="min-h-[100px] text-sm"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">
                      Separa con comas o saltos de línea
                    </p>
                  </div>
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={handleGenerate}
                    disabled={!pantryText.trim()}
                    className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    Dame una idea
                  </motion.button>
                </div>
              )}

              {/* STEP 4 — resultado */}
              {step === "result" && (
                <div className="px-5 pb-8 space-y-4">
                  <button onClick={() => setStep("pantry")} className="text-xs text-primary font-medium">← Cambiar ingredientes</button>

                  {snack ? (
                    <div className="glass-card rounded-2xl p-4 space-y-3">
                      <div>
                        <h3 className="font-heading font-bold text-foreground">{snack.name}</h3>
                        <p className="text-[11px] text-primary mt-1">{snack.why}</p>
                      </div>

                      <div className="grid grid-cols-4 gap-2">
                        <div className="bg-primary/10 rounded-xl p-2 text-center">
                          <p className="text-sm font-bold text-primary">{snack.macros.calories}</p>
                          <p className="text-[9px] text-muted-foreground">kcal</p>
                        </div>
                        <div className="bg-primary/10 rounded-xl p-2 text-center">
                          <p className="text-sm font-bold text-foreground">{snack.macros.protein}g</p>
                          <p className="text-[9px] text-muted-foreground">Prot</p>
                        </div>
                        <div className="bg-accent/10 rounded-xl p-2 text-center">
                          <p className="text-sm font-bold text-foreground">{snack.macros.carbs}g</p>
                          <p className="text-[9px] text-muted-foreground">CHO</p>
                        </div>
                        <div className="bg-rosa-light/20 rounded-xl p-2 text-center">
                          <p className="text-sm font-bold text-foreground">{snack.macros.fat}g</p>
                          <p className="text-[9px] text-muted-foreground">Grasa</p>
                        </div>
                      </div>

                      <div>
                        <p className="text-xs font-semibold text-foreground mb-1.5">🛒 Necesitas:</p>
                        {snack.required.map((r, i) => (
                          <p key={i} className="text-[11px] text-muted-foreground mb-0.5">• {r}</p>
                        ))}
                      </div>

                      {snack.optional.length > 0 && (
                        <div>
                          <p className="text-xs font-semibold text-foreground mb-1.5">✨ Opcionales (si los tienes):</p>
                          {snack.optional.map((r, i) => (
                            <p key={i} className="text-[11px] text-muted-foreground mb-0.5">• {r}</p>
                          ))}
                        </div>
                      )}

                      <div>
                        <p className="text-xs font-semibold text-foreground mb-1.5">👩‍🍳 Preparación:</p>
                        {snack.steps.map((s, i) => (
                          <p key={i} className="text-[11px] text-muted-foreground mb-0.5">{i + 1}. {s}</p>
                        ))}
                      </div>

                      <div className="bg-accent/10 rounded-lg p-2.5">
                        <p className="text-[10px] text-accent font-medium">
                          💡 Regla del snack saludable: 15–20 g proteína · ≤30 g carbos · ≤10 g grasa.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="glass-card rounded-2xl p-5 text-center space-y-2">
                      <p className="text-sm font-medium text-foreground">Con esos ingredientes no logro armar un snack que cumpla las reglas 😔</p>
                      <p className="text-xs text-muted-foreground">
                        Prueba añadir una fuente de proteína magra (huevos, yogurt griego, cottage, atún, pollo, proteína whey).
                      </p>
                    </div>
                  )}

                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setStep("pantry")}
                    className="w-full bg-secondary text-foreground font-heading font-bold py-3 rounded-2xl"
                  >
                    🔄 Probar otros ingredientes
                  </motion.button>
                </div>
              )}
            </div>
          </motion.div>
          </div>
        </>

      )}
    </AnimatePresence>
  );
};

export default RecipeHelperModal;
