import { useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { LayoutDashboard, MessageCircle, Smartphone } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useIsAdmin } from "@/hooks/useIsAdmin";

const SESSION_KEY_ADMIN_CHOICE = "cyra_admin_choice";

/**
 * Floating dock visible only to paula@cyrafit.com (admin).
 * - Toggles between /admin (dashboard) and / (app).
 * - Quick access to /community (foro).
 */
const PaulaQuickDock = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { isAdmin } = useIsAdmin();

  const isPaula = user?.email?.toLowerCase() === "paula@cyrafit.com";
  if (!user || !isAdmin || !isPaula) return null;

  const inAdmin = location.pathname.startsWith("/admin");
  const inCommunity = location.pathname.startsWith("/community");

  const goAdmin = () => {
    sessionStorage.setItem(SESSION_KEY_ADMIN_CHOICE, "admin");
    navigate("/admin");
  };
  const goApp = () => {
    sessionStorage.setItem(SESSION_KEY_ADMIN_CHOICE, "app");
    navigate("/");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed right-4 z-40 flex flex-col gap-2"
      style={{ bottom: inAdmin || inCommunity ? "1rem" : "5.5rem" }}
    >



      {/* Toggle admin / app */}
      {inAdmin ? (
        <button
          onClick={goApp}
          className="w-12 h-12 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:scale-105 transition"
          title="Ver la aplicación"
          aria-label="Cambiar a la aplicación"
        >
          <Smartphone className="w-5 h-5" />
        </button>
      ) : (
        <button
          onClick={goAdmin}
          className="w-12 h-12 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:scale-105 transition"
          title="Panel de administración"
          aria-label="Cambiar al panel de administración"
        >
          <LayoutDashboard className="w-5 h-5" />
        </button>
      )}
    </motion.div>
  );
};

export default PaulaQuickDock;
