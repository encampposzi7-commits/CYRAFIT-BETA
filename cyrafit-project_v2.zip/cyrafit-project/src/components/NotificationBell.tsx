import { useNavigate } from "react-router-dom";
import { Bell, Check, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { useCommunityNotifications } from "@/hooks/useCommunityNotifications";

const NotificationBell = () => {
  const navigate = useNavigate();
  const { items, unreadCount, markAllRead, markRead, clearAll } = useCommunityNotifications();

  const handleClick = async (n: (typeof items)[number]) => {
    await markRead(n.id);
    if (n.post_id) navigate(`/community/${n.post_id}`);
  };

  return (
    <Popover onOpenChange={(open) => open && markAllRead()}>
      <PopoverTrigger asChild>
        <button
          className="relative w-9 h-9 rounded-full bg-secondary/40 flex items-center justify-center hover:bg-secondary transition"
          aria-label="Notificaciones"
        >
          <Bell className="w-4 h-4 text-foreground" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between px-3 py-2 border-b border-border">
          <p className="text-sm font-semibold">Notificaciones</p>
          {items.length > 0 && (
            <button
              onClick={clearAll}
              className="text-[11px] text-muted-foreground hover:text-destructive inline-flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Limpiar
            </button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {items.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-8 px-4">
              No tienes notificaciones todavía.
            </p>
          ) : (
            items.map((n) => (
              <button
                key={n.id}
                onClick={() => handleClick(n)}
                className={`w-full text-left px-3 py-2.5 border-b border-border/50 hover:bg-secondary/30 transition flex items-start gap-2 ${
                  n.read ? "opacity-70" : "bg-primary/5"
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                    n.read ? "bg-transparent" : "bg-primary"
                  }`}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground line-clamp-2">{n.title}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {formatDistanceToNow(new Date(n.created_at), { addSuffix: true, locale: es })}
                  </p>
                </div>
                {n.read && <Check className="w-3 h-3 text-muted-foreground flex-shrink-0 mt-1" />}
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationBell;
