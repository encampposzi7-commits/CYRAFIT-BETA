import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft, Ruler, Weight, Calendar, Flame, Target, CheckCircle2, User } from "lucide-react";
import {
  NutritionProfile,
  ActivityLevel,
  Goal,
  ACTIVITY_LABELS,
  GOAL_LABELS,
  calculateBmi,
  getBmiCategory,
  getBmiLabel,
} from "@/lib/nutrition";

interface Props {
  onComplete: (profile: NutritionProfile) => void;
  initial?: NutritionProfile | null;
  /** Pre-filled name from the registered user profile. When provided, the name step is skipped. */
  presetName?: string;
}

const NutritionProfileSetup = ({ onComplete, initial, presetName }: Props) => {
  const resolvedName = (presetName?.trim() || initial?.name || "").trim();
  // Always skip the name step in the nutrition setup — the user already
  // provided their name during onboarding/registration.
  const skipName = true;

  const [step, setStep] = useState(1);
  const [name, setName] = useState(resolvedName);
  const [age, setAge] = useState(initial?.age || 28);
  const [heightCm, setHeightCm] = useState(initial?.heightCm || 165);
  const [weightKg, setWeightKg] = useState(initial?.weightKg || 62);
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(initial?.activityLevel || "moderate");
  const [goal, setGoal] = useState<Goal>(initial?.goal || "recomposition");
  const [fatLossType, setFatLossType] = useState<"light" | "moderate">("light");

  const bmi = calculateBmi(weightKg, heightCm);
  const bmiCat = getBmiCategory(bmi);
  const isNormal = bmiCat === "normal" || bmiCat === "underweight";

  const allSteps = [
    { icon: User, label: "Nombre" },
    { icon: Calendar, label: "Edad" },
    { icon: Ruler, label: "Estatura" },
    { icon: Weight, label: "Peso" },
    { icon: Flame, label: "Actividad" },
    { icon: Target, label: "Objetivo" },
  ];
  const steps = skipName ? allSteps.slice(1) : allSteps;

  const canProceed = () => {
    if (step === 0) return name.trim().length >= 2;
    if (step === 1) return age >= 14 && age <= 80;
    if (step === 2) return heightCm >= 120 && heightCm <= 220;
    if (step === 3) return weightKg >= 30 && weightKg <= 250;
    return true;
  };

  const handleFinish = () => {
    let finalGoal: Goal = goal;
    if (goal === "fat_loss_light" || goal === "fat_loss_moderate") {
      finalGoal = fatLossType === "light" ? "fat_loss_light" : "fat_loss_moderate";
    }
    onComplete({ name: name.trim(), age, heightCm, weightKg, activityLevel, goal: finalGoal });
  };

  const totalSteps = 6;
  const firstStep = skipName ? 1 : 0;
  const visibleStepIndex = step - firstStep;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-6 space-y-5"
    >
      <div className="text-center">
        <h2 className="font-heading font-bold text-lg text-foreground">Configurar perfil nutricional</h2>
        <p className="text-xs text-muted-foreground mt-1">
          {skipName && resolvedName
            ? `Hola ${resolvedName} 💕 Calculamos tus kcal y macros con Mifflin-St Jeor`
            : "Calculamos tus kcal y macros con el método Mifflin-St Jeor"}
        </p>
      </div>

      {/* Progress dots */}
      <div className="flex justify-center gap-2">
        {steps.map((s, i) => (
          <div
            key={i}
            className={`w-2 h-2 rounded-full transition-colors ${
              i === visibleStepIndex ? "bg-primary" : i < visibleStepIndex ? "bg-primary/50" : "bg-muted"
            }`}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="name" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-4">
            <div className="text-center">
              <User className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">¿Cómo te llamas?</p>
              <p className="text-xs text-muted-foreground mt-1">Cyra, tu coach virtual, te guiará por nombre 💕</p>
            </div>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Tu nombre"
              className="w-full text-center text-2xl font-heading font-bold text-foreground bg-secondary/50 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-primary"
            />
          </motion.div>
        )}

        {step === 1 && (
          <motion.div key="age" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-4">
            <div className="text-center">
              <Calendar className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">¿Cuántos años tienes?</p>
            </div>
            <div className="flex items-center justify-center gap-4">
              <button onClick={() => setAge(Math.max(14, age - 1))} className="w-10 h-10 rounded-full bg-secondary text-foreground font-bold text-lg flex items-center justify-center">−</button>
              <span className="text-4xl font-heading font-bold text-foreground w-20 text-center">{age}</span>
              <button onClick={() => setAge(Math.min(80, age + 1))} className="w-10 h-10 rounded-full bg-secondary text-foreground font-bold text-lg flex items-center justify-center">+</button>
            </div>
            <p className="text-xs text-muted-foreground text-center">años</p>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="height" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-4">
            <div className="text-center">
              <Ruler className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">¿Cuál es tu estatura?</p>
            </div>
            <div className="flex items-center justify-center gap-4">
              <button onClick={() => setHeightCm(Math.max(120, heightCm - 1))} className="w-10 h-10 rounded-full bg-secondary text-foreground font-bold text-lg flex items-center justify-center">−</button>
              <span className="text-4xl font-heading font-bold text-foreground w-20 text-center">{heightCm}</span>
              <button onClick={() => setHeightCm(Math.min(220, heightCm + 1))} className="w-10 h-10 rounded-full bg-secondary text-foreground font-bold text-lg flex items-center justify-center">+</button>
            </div>
            <p className="text-xs text-muted-foreground text-center">cm</p>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div key="weight" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-4">
            <div className="text-center">
              <Weight className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">¿Cuál es tu peso actual?</p>
            </div>
            <div className="flex items-center justify-center gap-4">
              <button onClick={() => setWeightKg(Math.max(30, parseFloat((weightKg - 0.5).toFixed(1))))} className="w-10 h-10 rounded-full bg-secondary text-foreground font-bold text-lg flex items-center justify-center">−</button>
              <span className="text-4xl font-heading font-bold text-foreground w-24 text-center">{weightKg}</span>
              <button onClick={() => setWeightKg(Math.min(250, parseFloat((weightKg + 0.5).toFixed(1))))} className="w-10 h-10 rounded-full bg-secondary text-foreground font-bold text-lg flex items-center justify-center">+</button>
            </div>
            <p className="text-xs text-muted-foreground text-center">kg</p>
            <div className="text-center mt-2">
              <span className={`text-xs font-medium px-3 py-1 rounded-full ${
                bmiCat === 'normal' ? 'bg-green-100 text-green-700' :
                bmiCat === 'overweight' ? 'bg-yellow-100 text-yellow-700' :
                bmiCat === 'obese' ? 'bg-red-100 text-red-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                IMC: {bmi.toFixed(1)} · {getBmiLabel(bmiCat)}
              </span>
            </div>
          </motion.div>
        )}

        {step === 4 && (
          <motion.div key="activity" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-3">
            <div className="text-center">
              <Flame className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">Nivel de actividad física</p>
            </div>
            <div className="space-y-2">
              {(Object.entries(ACTIVITY_LABELS) as [ActivityLevel, string][]).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setActivityLevel(key)}
                  className={`w-full p-3 rounded-xl text-left text-sm transition-all ${
                    activityLevel === key
                      ? "bg-primary/15 border-2 border-primary text-foreground font-semibold"
                      : "bg-secondary/50 border-2 border-transparent text-muted-foreground"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === 5 && (
          <motion.div key="goal" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-3">
            <div className="text-center">
              <Target className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">¿Cuál es tu objetivo?</p>
            </div>
            <div className="space-y-2">
              <button
                onClick={() => setGoal("fat_loss_light")}
                className={`w-full p-3 rounded-xl text-left text-sm transition-all ${
                  goal === "fat_loss_light" || goal === "fat_loss_moderate"
                    ? "bg-primary/15 border-2 border-primary text-foreground font-semibold"
                    : "bg-secondary/50 border-2 border-transparent text-muted-foreground"
                }`}
              >
                🔥 Pérdida de grasa
              </button>

              {(goal === "fat_loss_light" || goal === "fat_loss_moderate") && (
                <div className="ml-4 space-y-2">
                  <button
                    onClick={() => { setGoal("fat_loss_light"); setFatLossType("light"); }}
                    className={`w-full p-2.5 rounded-lg text-left text-xs transition-all ${
                      fatLossType === "light"
                        ? "bg-accent/20 border border-accent text-foreground font-medium"
                        : "bg-muted/50 border border-transparent text-muted-foreground"
                    }`}
                  >
                    Ligera (−300 kcal de carbos)
                  </button>
                  <button
                    onClick={() => { setGoal("fat_loss_moderate"); setFatLossType("moderate"); }}
                    className={`w-full p-2.5 rounded-lg text-left text-xs transition-all ${
                      fatLossType === "moderate"
                        ? "bg-accent/20 border border-accent text-foreground font-medium"
                        : "bg-muted/50 border border-transparent text-muted-foreground"
                    }`}
                  >
                    Moderada (−500 kcal de carbos)
                  </button>
                </div>
              )}

              <button
                onClick={() => setGoal("recomposition")}
                className={`w-full p-3 rounded-xl text-left text-sm transition-all ${
                  goal === "recomposition"
                    ? "bg-primary/15 border-2 border-primary text-foreground font-semibold"
                    : "bg-secondary/50 border-2 border-transparent text-muted-foreground"
                }`}
              >
                💪 Recomposición corporal
              </button>

              {isNormal && (
                <button
                  onClick={() => setGoal("muscle_gain")}
                  className={`w-full p-3 rounded-xl text-left text-sm transition-all ${
                    goal === "muscle_gain"
                      ? "bg-primary/15 border-2 border-primary text-foreground font-semibold"
                      : "bg-secondary/50 border-2 border-transparent text-muted-foreground"
                  }`}
                >
                  🏋️ Aumento de masa muscular
                </button>
              )}

              {!isNormal && (
                <p className="text-xs text-muted-foreground italic px-2">
                  El aumento de masa muscular está disponible solo para normopeso.
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex justify-between pt-2">
        {step > firstStep ? (
          <button
            onClick={() => setStep(step - 1)}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Atrás
          </button>
        ) : (
          <div />
        )}

        {step < totalSteps - 1 ? (
          <button
            onClick={() => canProceed() && setStep(step + 1)}
            disabled={!canProceed()}
            className="flex items-center gap-1 text-sm font-semibold text-primary hover:text-primary/80 transition-colors disabled:opacity-40"
          >
            Siguiente <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleFinish}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" /> Calcular
          </button>
        )}
      </div>
    </motion.div>
  );
};

export default NutritionProfileSetup;
