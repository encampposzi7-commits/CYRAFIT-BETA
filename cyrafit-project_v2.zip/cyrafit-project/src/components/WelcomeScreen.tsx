import { motion } from "framer-motion";
import cyraAvatar from "@/assets/cyra-avatar.png";

interface WelcomeScreenProps {
  onStart: () => void;
}

const WelcomeScreen = ({ onStart }: WelcomeScreenProps) => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-sm w-full text-center space-y-6"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="w-28 h-28 mx-auto rounded-full overflow-hidden shadow-glow border-4 border-primary/20"
        >
          <img src={cyraAvatar} alt="Cyra - Tu coach de entrenamiento" className="w-full h-full object-cover" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="space-y-1"
        >
          <h1 className="text-5xl font-heading font-bold text-primary tracking-tight">
            Cyrafit
          </h1>
          <p className="text-xs font-body italic text-muted-foreground tracking-widest uppercase">
            by Paula Perez
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="space-y-2 pt-2"
        >
          <p className="text-sm text-muted-foreground leading-relaxed">
            La forma inteligente de entrenar según tu cuerpo.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Personaliza tu entrenamiento, entiende tu ciclo y avanza con intención.
          </p>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          whileTap={{ scale: 0.97 }}
          onClick={onStart}
          className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow text-lg"
        >
          👉 Empezar mi proceso
        </motion.button>
      </motion.div>
    </div>
  );
};

export default WelcomeScreen;
