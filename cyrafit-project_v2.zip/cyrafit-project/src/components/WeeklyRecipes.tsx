import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChefHat, ChevronDown, ChevronUp, Sparkles } from "lucide-react";
import cyraAvatar from "@/assets/cyra-avatar.png";

interface WeeklyRecipe {
  name: string;
  type: "salada" | "dulce";
  emoji: string;
  ingredients: { name: string; amount: string; note?: string }[];
  steps: string[];
  macros: { calories: number; protein: number; carbs: number; fat: number };
  tip: string;
}

const WEEKLY_RECIPES: WeeklyRecipe[][] = [
  // Week set 1
  [
    {
      name: "Wraps de lechuga con pollo thai",
      type: "salada",
      emoji: "🥬",
      ingredients: [
        { name: "Pechuga de pollo", amount: "150g crudo", note: "≈120g cocido" },
        { name: "Hojas de lechuga costina", amount: "4 hojas grandes" },
        { name: "Zanahoria rallada", amount: "80g" },
        { name: "Maní tostado", amount: "15g" },
        { name: "Salsa de soya baja en sodio", amount: "1 cda" },
        { name: "Limón + jengibre rallado", amount: "al gusto" },
      ],
      steps: [
        "Cocina el pollo a la plancha y desmenuza.",
        "Mezcla con zanahoria rallada, soya y limón.",
        "Rellena las hojas de lechuga con la mezcla.",
        "Espolvorea maní triturado encima.",
      ],
      macros: { calories: 310, protein: 38, carbs: 12, fat: 13 },
      tip: "Sin CHO densos. Ideal para cena en déficit o mantención.",
    },
    {
      name: "Panqueques proteicos de avena y plátano",
      type: "dulce",
      emoji: "🥞",
      ingredients: [
        { name: "Avena instantánea", amount: "40g (crudo)" },
        { name: "Plátano maduro", amount: "1/2 unidad (50g)" },
        { name: "Claras de huevo", amount: "3 unidades" },
        { name: "Proteína en polvo (opcional)", amount: "15g" },
        { name: "Canela", amount: "al gusto" },
        { name: "Frutos rojos (frutillas/arándanos)", amount: "50g" },
      ],
      steps: [
        "Licúa avena, plátano, claras y canela.",
        "Cocina en sartén antiadherente a fuego bajo.",
        "Voltea cuando burbujee la superficie.",
        "Sirve con frutos rojos encima.",
      ],
      macros: { calories: 280, protein: 25, carbs: 35, fat: 4 },
      tip: "Ideal para desayuno pre-entreno. Rico en carbos de absorción lenta.",
    },
  ],
  // Week set 2
  [
    {
      name: "Bowl de salmón teriyaki con coliflor",
      type: "salada",
      emoji: "🐟",
      ingredients: [
        { name: "Salmón fresco", amount: "150g crudo", note: "≈120g cocido" },
        { name: "Coliflor rallada (arroz)", amount: "200g" },
        { name: "Pepino", amount: "80g" },
        { name: "Palta", amount: "1/4 unidad (40g)" },
        { name: "Salsa de soya + miel", amount: "1 cda c/u" },
        { name: "Sésamo", amount: "5g" },
      ],
      steps: [
        "Saltea la coliflor rallada como base (reemplaza arroz).",
        "Cocina el salmón con salsa teriyaki casera.",
        "Arma el bowl: coliflor, salmón, pepino y palta.",
        "Espolvorea sésamo.",
      ],
      macros: { calories: 380, protein: 35, carbs: 15, fat: 20 },
      tip: "La coliflor reemplaza el arroz: menos CHO, más volumen.",
    },
    {
      name: "Mousse fitness de chocolate y palta",
      type: "dulce",
      emoji: "🍫",
      ingredients: [
        { name: "Palta madura", amount: "1/2 unidad (80g)" },
        { name: "Cacao amargo en polvo", amount: "15g" },
        { name: "Endulzante (stevia/monk fruit)", amount: "al gusto" },
        { name: "Leche de almendras", amount: "30ml" },
        { name: "Frutos rojos para decorar", amount: "30g" },
      ],
      steps: [
        "Procesa la palta con cacao, endulzante y leche.",
        "Mezcla hasta obtener textura cremosa.",
        "Refrigera 30 min.",
        "Sirve con frutos rojos.",
      ],
      macros: { calories: 220, protein: 4, carbs: 12, fat: 18 },
      tip: "Postre alto en grasas saludables. Sin azúcar añadida.",
    },
  ],
  // Week set 3
  [
    {
      name: "Tortilla española fitness de zapallo",
      type: "salada",
      emoji: "🥚",
      ingredients: [
        { name: "Huevos enteros", amount: "2 unidades" },
        { name: "Claras de huevo", amount: "3 unidades" },
        { name: "Zapallo italiano", amount: "200g" },
        { name: "Cebolla", amount: "1/2 unidad" },
        { name: "Aceite de oliva", amount: "1 cdta" },
        { name: "Queso de cabra", amount: "20g" },
      ],
      steps: [
        "Lamina el zapallo y cebolla finamente.",
        "Saltea en sartén con aceite a fuego medio.",
        "Bate huevos + claras y vierte sobre las verduras.",
        "Cocina tapado a fuego bajo 8-10 min, voltea y termina.",
        "Añade queso de cabra desmenuzado.",
      ],
      macros: { calories: 290, protein: 30, carbs: 8, fat: 15 },
      tip: "Sin papa = menos CHO. El zapallo da cremosidad similar.",
    },
    {
      name: "Nice cream de plátano y mantequilla de maní",
      type: "dulce",
      emoji: "🍌",
      ingredients: [
        { name: "Plátano congelado", amount: "1 unidad (100g)" },
        { name: "Mantequilla de maní natural", amount: "15g" },
        { name: "Cacao amargo", amount: "5g (opcional)" },
        { name: "Leche de almendras", amount: "30ml" },
      ],
      steps: [
        "Congela el plátano cortado en rodajas (mínimo 4h).",
        "Procesa con la leche hasta textura cremosa.",
        "Agrega mantequilla de maní y cacao.",
        "Sirve inmediatamente.",
      ],
      macros: { calories: 210, protein: 5, carbs: 30, fat: 9 },
      tip: "Helado natural sin azúcar añadida. Ideal post-entreno.",
    },
  ],
  // Week set 4
  [
    {
      name: "Pimentones rellenos de pavo y quinoa",
      type: "salada",
      emoji: "🫑",
      ingredients: [
        { name: "Pimentones grandes", amount: "2 unidades" },
        { name: "Carne de pavo molida", amount: "150g crudo", note: "≈120g cocido" },
        { name: "Quinoa", amount: "20g crudo", note: "≈60g cocido (15g CHO)" },
        { name: "Tomate", amount: "1 unidad picada" },
        { name: "Comino + pimentón", amount: "al gusto" },
        { name: "Queso rallado light", amount: "20g" },
      ],
      steps: [
        "Cocina la quinoa y el pavo molido por separado.",
        "Mezcla pavo con quinoa, tomate y especias.",
        "Rellena los pimentones cortados por la mitad.",
        "Gratina 15 min con queso rallado encima.",
      ],
      macros: { calories: 340, protein: 36, carbs: 22, fat: 11 },
      tip: "Quinoa cocida: ~60g = 15g CHO. Perfecto para mantención.",
    },
    {
      name: "Bolitas energéticas de avena y coco",
      type: "dulce",
      emoji: "🥥",
      ingredients: [
        { name: "Avena", amount: "50g" },
        { name: "Mantequilla de maní", amount: "30g" },
        { name: "Miel o endulzante", amount: "15g" },
        { name: "Coco rallado", amount: "15g" },
        { name: "Chips de chocolate 70%", amount: "10g" },
      ],
      steps: [
        "Mezcla avena, mantequilla de maní y miel.",
        "Agrega coco rallado y chips de chocolate.",
        "Forma bolitas del tamaño de una nuez.",
        "Refrigera 1 hora antes de comer.",
      ],
      macros: { calories: 250, protein: 8, carbs: 28, fat: 13 },
      tip: "Snack portátil. 2 bolitas = porción ideal pre-entreno.",
    },
  ],
];

function getWeekIndex(): number {
  const now = new Date();
  const weekOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));
  return weekOfYear % WEEKLY_RECIPES.length;
}

const WeeklyRecipes = () => {
  const weekIdx = useMemo(() => getWeekIndex(), []);
  const recipes = WEEKLY_RECIPES[weekIdx];
  const [expandedIdx, setExpandedIdx] = useState<number | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-5"
    >
      <div className="flex items-center gap-2 mb-1">
        <Sparkles className="w-4 h-4 text-primary" />
        <h3 className="font-heading font-semibold text-sm text-foreground">Inspiración de la semana</h3>
      </div>
      <p className="text-[10px] text-muted-foreground mb-3">
        2 recetas fitness con ingredientes accesibles en Chile 🇨🇱
      </p>

      <div className="space-y-2">
        {recipes.map((recipe, idx) => (
          <div key={idx} className="rounded-xl overflow-hidden border border-border/30">
            <button
              onClick={() => setExpandedIdx(expandedIdx === idx ? null : idx)}
              className="w-full p-3 flex items-center justify-between text-left hover:bg-secondary/30 transition-colors"
            >
              <div className="flex items-center gap-2">
                <span className="text-lg">{recipe.emoji}</span>
                <div>
                  <p className="text-sm font-semibold text-foreground">{recipe.name}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {recipe.type === "salada" ? "🍽️ Salada" : "🍰 Dulce"} · {recipe.macros.calories} kcal
                  </p>
                </div>
              </div>
              {expandedIdx === idx ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </button>

            <AnimatePresence>
              {expandedIdx === idx && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="px-3 pb-3 space-y-2">
                    <div className="grid grid-cols-4 gap-1.5">
                      <div className="bg-primary/10 rounded-lg p-1.5 text-center">
                        <p className="text-xs font-bold text-primary">{recipe.macros.calories}</p>
                        <p className="text-[8px] text-muted-foreground">kcal</p>
                      </div>
                      <div className="bg-primary/10 rounded-lg p-1.5 text-center">
                        <p className="text-xs font-bold text-foreground">{recipe.macros.protein}g</p>
                        <p className="text-[8px] text-muted-foreground">Prot</p>
                      </div>
                      <div className="bg-accent/10 rounded-lg p-1.5 text-center">
                        <p className="text-xs font-bold text-foreground">{recipe.macros.carbs}g</p>
                        <p className="text-[8px] text-muted-foreground">CHO</p>
                      </div>
                      <div className="bg-rosa-light/20 rounded-lg p-1.5 text-center">
                        <p className="text-xs font-bold text-foreground">{recipe.macros.fat}g</p>
                        <p className="text-[8px] text-muted-foreground">Grasa</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-[10px] font-semibold text-foreground mb-1">🛒 Ingredientes:</p>
                      {recipe.ingredients.map((ing, i) => (
                        <div key={i} className="text-[11px] text-muted-foreground">
                          <span>• {ing.name}: {ing.amount}</span>
                          {ing.note && <span className="text-primary font-medium ml-1">({ing.note})</span>}
                        </div>
                      ))}
                    </div>

                    <div>
                      <p className="text-[10px] font-semibold text-foreground mb-1">👩‍🍳 Preparación:</p>
                      {recipe.steps.map((s, i) => (
                        <p key={i} className="text-[11px] text-muted-foreground">{i + 1}. {s}</p>
                      ))}
                    </div>

                    <div className="bg-primary/5 rounded-lg p-2">
                      <p className="text-[10px] text-primary font-medium">💡 {recipe.tip}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default WeeklyRecipes;
