import { useEffect, useMemo, useState } from "react";

const CYRA_FLOAT_DISMISSED_KEY = "cyra_phase_float_dismissed";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { PhaseInfo, CyclePhase } from "@/lib/cycle";
import { getPhaseMessage, getPostpartumMessage } from "@/lib/cyraVoice";
import cyraAvatar from "@/assets/cyra-avatar.png";

interface CyraPhaseFloatProps {
  phaseInfo: PhaseInfo;
  cycleDay: number;
  phase?: CyclePhase;
  isPostpartum?: boolean;
  pendingPeriodStart?: boolean;
}

function getTrainingCategory(intensity: string): { label: string; emoji: string } {
  const lower = intensity.toLowerCase();
  if (lower === "baja" || lower === "moderada") {
    return { label: "Cyra Flow", emoji: "🧘‍♀️" };
  }
  return { label: "Cyra Power", emoji: "💪" };
}

const CyraPhaseFloat = ({ phaseInfo, cycleDay, phase, isPostpartum, pendingPeriodStart }: CyraPhaseFloatProps) => {
  const [expanded, setExpanded] = useState(() => {
    if (typeof window === "undefined") return true;
    return sessionStorage.getItem(CYRA_FLOAT_DISMISSED_KEY) !== "1";
  });

  const dismiss = () => {
    setExpanded(false);
    try { sessionStorage.setItem(CYRA_FLOAT_DISMISSED_KEY, "1"); } catch {}
  };

  const reopen = () => {
    setExpanded(true);
    try { sessionStorage.removeItem(CYRA_FLOAT_DISMISSED_KEY); } catch {}
  };
  const training = getTrainingCategory(phaseInfo.intensity);

  // Mensaje empático rotativo (estable por día) según fase o post parto
  const message = useMemo(() => {
    if (pendingPeriodStart) {
      return "Tu cuerpo podría estar entrando a una nueva fase hoy. Marca tu periodo en el calendario para actualizar tus recomendaciones.";
    }
    if (isPostpartum) return getPostpartumMessage("headline");
    if (phase) return getPhaseMessage(phase, "headline");
    return phaseInfo.trainingTip;
  }, [pendingPeriodStart, phase, isPostpartum, phaseInfo.trainingTip]);



  if (!expanded) {
    return (
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        onClick={reopen}
        className="fixed top-20 right-4 z-40 w-12 h-12 rounded-full overflow-hidden shadow-glow border-2 border-primary/30"
      >
        <img src={cyraAvatar} alt="Cyra" className="w-full h-full object-cover" />
      </motion.button>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.9 }}
        className="fixed top-20 right-4 left-4 z-40 max-w-sm mx-auto"
      >
        <div className="glass-card rounded-2xl p-4 shadow-glow border border-primary/15">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border-2 border-primary/20">
              <img src={cyraAvatar} alt="Cyra" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-primary">Cyra te dice:</p>
                <button onClick={dismiss} className="p-1 rounded-full hover:bg-muted">
                  <X className="w-3.5 h-3.5 text-muted-foreground" />
                </button>
              </div>
              <p className="text-sm font-heading font-bold text-foreground mt-1">
                {pendingPeriodStart
                  ? "🌸 Posible día 1 — esperando confirmación"
                  : isPostpartum
                    ? "🤱 Recuperación post parto"
                    : `${phaseInfo.emoji} Fase ${phaseInfo.name} · Día ${cycleDay}`}
              </p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                {message}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-full ${phaseInfo.bgColor} ${phaseInfo.color}`}>
                  {training.emoji} {training.label} · Intensidad {phaseInfo.intensity}
                </span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default CyraPhaseFloat;
