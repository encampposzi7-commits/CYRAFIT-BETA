import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles, AlertTriangle, ExternalLink, Loader2, ShieldCheck } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { usePremium } from "@/hooks/usePremium";
import { setTestPremium } from "@/lib/billing";
import { toast } from "@/hooks/use-toast";
import { Capacitor } from "@capacitor/core";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpgradeClick?: () => void;
}

const formatDate = (iso?: string | null) => {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleDateString("es-CL", { year: "numeric", month: "long", day: "numeric" });
  } catch {
    return "—";
  }
};

const ManageSubscriptionDialog = ({ open, onOpenChange, onUpgradeClick }: Props) => {
  const { user } = useAuth();
  const { isPremium, source, expiresAt } = usePremium();
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [working, setWorking] = useState(false);

  const isNative = Capacitor.isNativePlatform();
  const isTestPremium = isPremium && source === "test";
  const isPaidPremium = isPremium && source !== "test";

  const handleCancelTest = async () => {
    if (!user) return;
    setWorking(true);
    const res = await setTestPremium(user.id, false);
    setWorking(false);
    if (!res.success) {
      toast({ title: "No se pudo cancelar", description: res.error ?? "Intenta de nuevo." });
      return;
    }
    toast({ title: "Suscripción de prueba cancelada" });
    setConfirmCancel(false);
    onOpenChange(false);
  };

  const handleOpenPlayStore = () => {
    // Deep-link a la pantalla de suscripciones del usuario en Play Store
    const url = "https://play.google.com/store/account/subscriptions";
    if (isNative) {
      window.open(url, "_system");
    } else {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) setConfirmCancel(false); onOpenChange(v); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Administrar suscripción
          </DialogTitle>
          <DialogDescription>
            {isPremium
              ? "Revisa el estado de tu suscripción y gestiona la renovación."
              : "Aún no tienes una suscripción Premium activa."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          {/* Estado actual */}
          <div className="rounded-2xl border border-border bg-secondary/30 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Estado</span>
              <span className={`text-sm font-semibold ${isPremium ? "text-primary" : "text-muted-foreground"}`}>
                {isPremium ? (isTestPremium ? "Premium (prueba)" : "Premium activo") : "Gratuito"}
              </span>
            </div>
            {isPremium && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Origen</span>
                  <span className="text-sm font-medium text-foreground">
                    {source === "google_play" ? "Google Play" : source === "test" ? "Modo prueba" : source ?? "—"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Renueva / vence</span>
                  <span className="text-sm font-medium text-foreground">{formatDate(expiresAt)}</span>
                </div>
              </>
            )}
          </div>

          {/* Sin suscripción */}
          {!isPremium && (
            <Button
              className="w-full"
              onClick={() => {
                onOpenChange(false);
                onUpgradeClick?.();
              }}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Suscribirme a Premium
            </Button>
          )}

          {/* Suscripción real (Google Play) */}
          {isPaidPremium && (
            <>
              <div className="rounded-xl bg-primary/5 border border-primary/20 p-3 flex gap-2">
                <ShieldCheck className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <p className="text-xs text-foreground leading-relaxed">
                  Tu suscripción se gestiona a través de <strong>Google Play</strong>. Para cancelar la renovación
                  automática, abre la sección de Suscripciones en tu cuenta de Google.
                </p>
              </div>
              <Button variant="outline" className="w-full" onClick={handleOpenPlayStore}>
                <ExternalLink className="w-4 h-4 mr-2" />
                Gestionar en Google Play
              </Button>
              <p className="text-[11px] text-muted-foreground text-center leading-snug">
                Mantendrás acceso Premium hasta el final del periodo facturado, incluso después de cancelar.
              </p>
            </>
          )}

          {/* Suscripción de prueba */}
          {isTestPremium && (
            <>
              {!confirmCancel ? (
                <Button variant="outline" className="w-full" onClick={() => setConfirmCancel(true)}>
                  Dar de baja Premium de prueba
                </Button>
              ) : (
                <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4 space-y-3">
                  <div className="flex gap-2">
                    <AlertTriangle className="w-5 h-5 text-destructive shrink-0" />
                    <p className="text-sm text-foreground">
                      ¿Seguro que quieres cancelar tu Premium de prueba? Perderás el acceso a las funciones avanzadas.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1" onClick={() => setConfirmCancel(false)} disabled={working}>
                      Mantener
                    </Button>
                    <Button variant="destructive" className="flex-1" onClick={handleCancelTest} disabled={working}>
                      {working ? <Loader2 className="w-4 h-4 animate-spin" /> : "Sí, cancelar"}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ManageSubscriptionDialog;
