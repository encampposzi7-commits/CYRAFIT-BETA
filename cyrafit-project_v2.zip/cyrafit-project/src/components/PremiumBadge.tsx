import { Sparkles } from "lucide-react";
import { usePremium } from "@/hooks/usePremium";

/**
 * Small pill that shows the user's subscription tier.
 * Used in profile / settings header.
 */
const PremiumBadge = ({ className = "" }: { className?: string }) => {
  const { isPremium, source, loading } = usePremium();
  if (loading) return null;

  if (!isPremium) {
    return (
      <span className={`inline-flex items-center gap-1 text-[10px] font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full ${className}`}>
        Plan gratis
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-bold text-primary-foreground gradient-primary px-2 py-0.5 rounded-full ${className}`}>
      <Sparkles className="w-2.5 h-2.5" />
      Premium{source === "test" ? " · test" : ""}
    </span>
  );
};

export default PremiumBadge;
