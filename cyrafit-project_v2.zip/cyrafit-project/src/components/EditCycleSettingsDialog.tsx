import { useState, useEffect } from "react";
import { format } from "date-fns";
import { CalendarIcon, Sparkles, Baby, Flower2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useCycleData } from "@/hooks/useCycleData";
import { CycleMode } from "@/lib/cycle";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

const EditCycleSettingsDialog = ({ open, onOpenChange }: Props) => {
  const { settings, saveSettings, logPeriodStart, lastPeriodDate } = useCycleData();
  const { toast } = useToast();

  const [mode, setMode] = useState<CycleMode>(settings.mode);
  const [cycleLen, setCycleLen] = useState(settings.avgCycleLength);
  const [periodLen, setPeriodLen] = useState(settings.avgPeriodLength);
  const [postpartumDate, setPostpartumDate] = useState<Date | undefined>(
    settings.postpartumStartDate ?? undefined,
  );
  const [trackPp, setTrackPp] = useState(!!settings.trackPeriodPostpartum);
  const [newPeriod, setNewPeriod] = useState<Date | undefined>();
  const [calOpen, setCalOpen] = useState(false);
  const [ppCalOpen, setPpCalOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setMode(settings.mode);
      setCycleLen(settings.avgCycleLength);
      setPeriodLen(settings.avgPeriodLength);
      setPostpartumDate(settings.postpartumStartDate ?? undefined);
      setTrackPp(!!settings.trackPeriodPostpartum);
      setNewPeriod(undefined);
    }
  }, [open, settings]);

  const handleSave = async () => {
    setSaving(true);
    const { error } = await saveSettings({
      mode,
      avgCycleLength: cycleLen,
      avgPeriodLength: periodLen,
      postpartumStartDate: mode === "postpartum" ? postpartumDate ?? null : null,
      trackPeriodPostpartum: mode === "postpartum" ? trackPp : false,
    });
    if (error) {
      setSaving(false);
      toast({ title: "Error", description: error, variant: "destructive" });
      return;
    }
    if (newPeriod) {
      await logPeriodStart(newPeriod);
    }
    setSaving(false);
    toast({ title: "Ciclo actualizado ✨" });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Datos del ciclo</DialogTitle>
          <DialogDescription>
            Ajusta tu ciclo cuando cambie. Yo recalculo tus fases automáticamente.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setMode("cycle")}
              className={cn(
                "p-3 rounded-2xl border-2 text-left transition-all",
                mode === "cycle" ? "border-primary bg-primary/10" : "border-border bg-secondary/30",
              )}
            >
              <Flower2 className="w-4 h-4 text-primary mb-1" />
              <p className="text-xs font-bold text-foreground">Ciclo activo</p>
            </button>
            <button
              type="button"
              onClick={() => setMode("postpartum")}
              className={cn(
                "p-3 rounded-2xl border-2 text-left transition-all",
                mode === "postpartum" ? "border-primary bg-primary/10" : "border-border bg-secondary/30",
              )}
            >
              <Baby className="w-4 h-4 text-primary mb-1" />
              <p className="text-xs font-bold text-foreground">Post parto</p>
            </button>
          </div>

          {mode === "postpartum" && (
            <div className="space-y-3 bg-secondary/30 rounded-2xl p-3">
              <label className="text-xs font-medium text-muted-foreground">Fecha del parto</label>
              <Popover open={ppCalOpen} onOpenChange={setPpCalOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {postpartumDate ? format(postpartumDate, "dd/MM/yyyy") : "Seleccionar"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={postpartumDate}
                    onSelect={(d) => {
                      if (d) {
                        setPostpartumDate(d);
                        setPpCalOpen(false);
                      }
                    }}
                    disabled={(date) => {
                      const sixMonthsAgo = new Date();
                      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
                      return date > new Date() || date < sixMonthsAgo;
                    }}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>

              <div className="flex items-center justify-between gap-2">
                <p className="text-xs font-semibold text-foreground">¿Trackear ciclo en paralelo?</p>
                <Switch checked={trackPp} onCheckedChange={setTrackPp} />
              </div>
            </div>
          )}

          {(mode === "cycle" || trackPp) && (
            <>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-muted-foreground">Duración del ciclo</span>
                  <span className="font-bold text-primary">{cycleLen} días</span>
                </div>
                <Slider value={[cycleLen]} min={21} max={40} step={1} onValueChange={(v) => setCycleLen(v[0])} />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-muted-foreground">Duración de la menstruación</span>
                  <span className="font-bold text-primary">{periodLen} días</span>
                </div>
                <Slider value={[periodLen]} min={2} max={10} step={1} onValueChange={(v) => setPeriodLen(v[0])} />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">
                  Registrar nueva fecha de menstruación (opcional)
                </label>
                <Popover open={calOpen} onOpenChange={setCalOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newPeriod
                        ? format(newPeriod, "dd/MM/yyyy")
                        : lastPeriodDate
                          ? `Última: ${format(lastPeriodDate, "dd/MM/yyyy")}`
                          : "Seleccionar"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={newPeriod}
                      onSelect={(d) => {
                        if (d) {
                          setNewPeriod(d);
                          setCalOpen(false);
                        }
                      }}
                      disabled={(date) => date > new Date()}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </>
          )}

          <Button
            onClick={handleSave}
            disabled={saving}
            className="w-full gradient-primary text-primary-foreground font-bold rounded-2xl py-5"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            {saving ? "Guardando..." : "Guardar cambios"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditCycleSettingsDialog;
