import { useState } from "react";
import { motion } from "framer-motion";
import { User, Calendar } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import cyraAvatar from "@/assets/cyra-avatar.png";

const OnboardingProfile = ({ onComplete }: { onComplete: () => void }) => {
  const { saveProfile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const calcAge = (dateStr: string) => {
    const birth = new Date(dateStr);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age;
  };

  const age = birthDate ? calcAge(birthDate) : null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (loading) return;

    const trimmedName = name.trim();

    if (!trimmedName || !birthDate) return;

    setLoading(true);
    setSaveError(null);

    console.info("[Onboarding] Submitting onboarding profile", {
      name: trimmedName,
      birth_date: birthDate,
    });

    try {
      const { error } = await saveProfile({
        name: trimmedName,
        birth_date: birthDate,
      });

      if (error) {
        const message = typeof error === "string"
          ? error
          : (error as any)?.message || "No se pudo guardar tu perfil. Intenta de nuevo.";

        console.error("[Onboarding] Profile submit failed", { message, error });
        setSaveError(message);
        toast({
          title: "Error",
          description: message,
          variant: "destructive",
        });
        return;
      }

      console.info("[Onboarding] Profile saved, redirecting to home");
      toast({ title: `¡Bienvenida, ${trimmedName}! 💗`, description: "Tu perfil fue creado con éxito." });
      onComplete();
      navigate("/", { replace: true });
    } catch (error) {
      const message = error instanceof Error
        ? error.message
        : "No se pudo guardar tu perfil. Intenta de nuevo.";

      console.error("[Onboarding] Unexpected submit error", error);
      setSaveError(message);
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-sm w-full space-y-6"
      >
        <div className="text-center space-y-3">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="w-20 h-20 mx-auto rounded-full overflow-hidden shadow-glow border-3 border-primary/20"
          >
            <img src={cyraAvatar} alt="Cyra" className="w-full h-full object-cover" />
          </motion.div>
          <h2 className="text-2xl font-heading font-bold text-foreground">
            Cuéntame de ti 💗
          </h2>
          <p className="text-sm text-muted-foreground">
            Necesito unos datos para personalizar tu experiencia.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground ml-1">
              Nombre o apodo
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="¿Cómo te llamo?"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10 rounded-xl h-12 bg-secondary/30 border-border/50"
                required
                maxLength={30}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground ml-1">
              Fecha de nacimiento
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="pl-10 rounded-xl h-12 bg-secondary/30 border-border/50"
                required
                max={new Date().toISOString().split("T")[0]}
              />
            </div>
            {age !== null && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-xs text-primary font-medium ml-1"
              >
                ✨ Tienes {age} años — usaré esto para tus recomendaciones
              </motion.p>
            )}
          </div>

          <motion.button
            whileTap={{ scale: 0.97 }}
            type="submit"
            disabled={loading || !name.trim() || !birthDate}
            className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow text-base disabled:opacity-50"
          >
            {loading ? "Guardando..." : "Continuar 💫"}
          </motion.button>

          {saveError && (
            <p className="text-sm text-destructive text-center" role="alert">
              {saveError}
            </p>
          )}
        </form>
      </motion.div>
    </div>
  );
};

export default OnboardingProfile;
