import { motion } from "framer-motion";
import { CyclePhase, PHASES } from "@/lib/cycle";

interface CycleRingProps {
  cycleDay: number;
  phase: CyclePhase;
}

const CycleRing = ({ cycleDay, phase }: CycleRingProps) => {
  const phaseInfo = PHASES[phase];
  const progress = cycleDay / 28;

  const segments = [
    { phase: 'menstrual' as const, start: 0, end: 5/28, color: '#b84c65' },
    { phase: 'follicular' as const, start: 5/28, end: 13/28, color: '#f7838d' },
    { phase: 'ovulatory' as const, start: 13/28, end: 16/28, color: '#fcc0c5' },
    { phase: 'luteal' as const, start: 16/28, end: 1, color: '#e8b4bc' },
  ];

  const radius = 90;
  const strokeWidth = 10;
  const circumference = 2 * Math.PI * radius;

  return (
    <div className="relative flex items-center justify-center">
      <svg width="220" height="220" viewBox="0 0 220 220" className="transform -rotate-90">
        {segments.map((seg) => {
          const startAngle = seg.start * circumference;
          const segLength = (seg.end - seg.start) * circumference;
          const isActive = seg.phase === phase;
          return (
            <circle
              key={seg.phase}
              cx="110"
              cy="110"
              r={radius}
              fill="none"
              stroke={seg.color}
              strokeWidth={isActive ? strokeWidth + 4 : strokeWidth}
              strokeDasharray={`${segLength - 3} ${circumference - segLength + 3}`}
              strokeDashoffset={-startAngle}
              strokeLinecap="round"
              opacity={isActive ? 1 : 0.35}
              className="transition-all duration-500"
            />
          );
        })}
        {/* Indicator dot */}
        <motion.circle
          cx={110 + radius * Math.cos(2 * Math.PI * progress - Math.PI / 2)}
          cy={110 + radius * Math.sin(2 * Math.PI * progress - Math.PI / 2)}
          r="7"
          fill="hsl(var(--primary))"
          stroke="hsl(var(--background))"
          strokeWidth="3"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: "spring" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center text-center">
        <motion.span
          className="text-4xl"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
        >
          {phaseInfo.emoji}
        </motion.span>
        <span className="text-3xl font-heading font-bold text-foreground mt-1">
          Día {cycleDay}
        </span>
        <span className="text-sm text-muted-foreground font-medium">
          {phaseInfo.name}
        </span>
      </div>
    </div>
  );
};

export default CycleRing;
