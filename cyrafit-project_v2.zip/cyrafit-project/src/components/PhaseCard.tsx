import { motion } from "framer-motion";
import { PhaseInfo, CyclePhase } from "@/lib/cycle";
import { Sparkles, Dumbbell, Apple, Heart } from "lucide-react";
import { getPhaseMessage, getPostpartumMessage } from "@/lib/cyraVoice";

interface PhaseCardProps {
  phase: PhaseInfo;
  cyclePhase?: CyclePhase;
  isPostpartum?: boolean;
}

const PhaseCard = ({ phase, cyclePhase, isPostpartum }: PhaseCardProps) => {
  const emotion = isPostpartum
    ? getPostpartumMessage("emotion", 1)
    : cyclePhase
      ? getPhaseMessage(cyclePhase, "emotion", 1)
      : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="glass-card rounded-2xl p-5 space-y-4"
    >
      <div className="flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-primary" />
        <h3 className="font-heading font-semibold text-foreground text-sm">
          Tu cuerpo hoy
        </h3>
      </div>
      <p className="text-sm text-muted-foreground leading-relaxed">
        {phase.description}
      </p>
      {emotion && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-primary/8 border border-primary/15">
          <Heart className="w-4 h-4 text-primary mt-0.5 shrink-0" />
          <p className="text-xs text-foreground leading-relaxed italic">{emotion}</p>
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        {phase.symptoms.map((s) => (
          <span
            key={s}
            className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full font-medium"
          >
            {s}
          </span>
        ))}
      </div>

      <div className="space-y-3 pt-2">
        <div className="flex items-start gap-3 p-3 rounded-xl bg-secondary/50">
          <Dumbbell className="w-4 h-4 text-primary mt-0.5 shrink-0" />
          <div>
            <p className="text-xs font-semibold text-foreground">{phase.trainingType}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{phase.trainingTip}</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-3 rounded-xl bg-secondary/50">
          <Apple className="w-4 h-4 text-accent mt-0.5 shrink-0" />
          <div>
            <p className="text-xs font-semibold text-foreground">Nutrición</p>
            <p className="text-xs text-muted-foreground mt-0.5">{phase.nutritionTip}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PhaseCard;
