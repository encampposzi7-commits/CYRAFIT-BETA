import { useState } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { CalendarIcon, Sparkles, Baby, Flower2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useCycleData } from "@/hooks/useCycleData";
import { CycleMode } from "@/lib/cycle";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import cyraAvatar from "@/assets/cyra-avatar.png";

const OnboardingCycle = ({ onComplete }: { onComplete: () => void }) => {
  const { saveSettings, logPeriodStart } = useCycleData();
  const { toast } = useToast();

  const [mode, setMode] = useState<CycleMode>("cycle");
  const [lastPeriod, setLastPeriod] = useState<Date | undefined>();
  const [postpartumDate, setPostpartumDate] = useState<Date | undefined>();
  const [cycleLen, setCycleLen] = useState(28);
  const [periodLen, setPeriodLen] = useState(5);
  const [trackPostpartum, setTrackPostpartum] = useState(false);
  const [calOpen, setCalOpen] = useState(false);
  const [ppCalOpen, setPpCalOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const canSubmit =
    mode === "cycle"
      ? !!lastPeriod
      : !!postpartumDate && (!trackPostpartum || !!lastPeriod);

  const handleSubmit = async () => {
    if (!canSubmit || saving) return;
    setSaving(true);
    const { error } = await saveSettings({
      mode,
      avgCycleLength: cycleLen,
      avgPeriodLength: periodLen,
      postpartumStartDate: mode === "postpartum" ? postpartumDate ?? null : null,
      trackPeriodPostpartum: mode === "postpartum" ? trackPostpartum : false,
    });
    if (error) {
      setSaving(false);
      toast({ title: "Error", description: error, variant: "destructive" });
      return;
    }
    if (lastPeriod && (mode === "cycle" || trackPostpartum)) {
      await logPeriodStart(lastPeriod);
    }
    setSaving(false);
    toast({ title: "¡Listo! ✨", description: "Tu ciclo quedó configurado." });
    onComplete();
  };

  return (
    <div className="min-h-screen bg-background flex items-start justify-center px-5 py-10 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-sm w-full space-y-6"
      >
        <div className="text-center space-y-3">
          <div className="w-20 h-20 mx-auto rounded-full overflow-hidden shadow-glow border-2 border-primary/20">
            <img src={cyraAvatar} alt="Cyra" className="w-full h-full object-cover" />
          </div>
          <h2 className="text-2xl font-heading font-bold text-foreground">Configura tu ciclo 🌸</h2>
          <p className="text-sm text-muted-foreground">
            Personalizo cada entrenamiento y recomendación según tu cuerpo.
          </p>
        </div>

        {/* Mode selector */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setMode("cycle")}
            className={cn(
              "p-3 rounded-2xl border-2 text-left transition-all",
              mode === "cycle" ? "border-primary bg-primary/10" : "border-border bg-secondary/30",
            )}
          >
            <Flower2 className="w-5 h-5 text-primary mb-1" />
            <p className="text-xs font-bold text-foreground">Ciclo activo</p>
            <p className="text-[10px] text-muted-foreground">Menstrúo regularmente</p>
          </button>
          <button
            type="button"
            onClick={() => setMode("postpartum")}
            className={cn(
              "p-3 rounded-2xl border-2 text-left transition-all",
              mode === "postpartum" ? "border-primary bg-primary/10" : "border-border bg-secondary/30",
            )}
          >
            <Baby className="w-5 h-5 text-primary mb-1" />
            <p className="text-xs font-bold text-foreground">Post parto</p>
            <p className="text-[10px] text-muted-foreground">Hasta 6 meses</p>
          </button>
        </div>

        {mode === "postpartum" && (
          <div className="space-y-3 glass-card rounded-2xl p-4">
            <label className="text-xs font-medium text-muted-foreground">Fecha del parto</label>
            <Popover open={ppCalOpen} onOpenChange={setPpCalOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {postpartumDate ? format(postpartumDate, "dd/MM/yyyy") : "Seleccionar fecha"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="center">
                <Calendar
                  mode="single"
                  selected={postpartumDate}
                  onSelect={(d) => {
                    if (d) {
                      setPostpartumDate(d);
                      setPpCalOpen(false);
                    }
                  }}
                  disabled={(date) => {
                    const sixMonthsAgo = new Date();
                    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
                    return date > new Date() || date < sixMonthsAgo;
                  }}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>

            <div className="flex items-center justify-between gap-2 pt-2">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-foreground">¿Ya volvió tu menstruación?</p>
                <p className="text-[10px] text-muted-foreground">Si quieres, trackeamos tu ciclo en paralelo.</p>
              </div>
              <Switch checked={trackPostpartum} onCheckedChange={setTrackPostpartum} />
            </div>
          </div>
        )}

        {(mode === "cycle" || trackPostpartum) && (
          <div className="space-y-4 glass-card rounded-2xl p-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Fecha del último periodo</label>
              <Popover open={calOpen} onOpenChange={setCalOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {lastPeriod ? format(lastPeriod, "dd/MM/yyyy") : "Seleccionar fecha"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="center">
                  <Calendar
                    mode="single"
                    selected={lastPeriod}
                    onSelect={(d) => {
                      if (d) {
                        setLastPeriod(d);
                        setCalOpen(false);
                      }
                    }}
                    disabled={(date) => date > new Date()}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-medium text-muted-foreground">Duración promedio del ciclo</span>
                <span className="font-bold text-primary">{cycleLen} días</span>
              </div>
              <Slider value={[cycleLen]} min={21} max={40} step={1} onValueChange={(v) => setCycleLen(v[0])} />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-medium text-muted-foreground">Duración de la menstruación</span>
                <span className="font-bold text-primary">{periodLen} días</span>
              </div>
              <Slider value={[periodLen]} min={2} max={10} step={1} onValueChange={(v) => setPeriodLen(v[0])} />
            </div>
          </div>
        )}

        <Button
          onClick={handleSubmit}
          disabled={!canSubmit || saving}
          className="w-full gradient-primary text-primary-foreground font-heading font-bold py-6 rounded-2xl shadow-glow text-base disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          {saving ? "Guardando..." : "Comenzar 💫"}
        </Button>
      </motion.div>
    </div>
  );
};

export default OnboardingCycle;
