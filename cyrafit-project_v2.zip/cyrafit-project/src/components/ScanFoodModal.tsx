import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Camera, Upload, Plus, Minus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { FoodLogEntry, MEAL_LABELS, getTodayKey } from "@/lib/foodDatabase";

interface ScanFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (entry: FoodLogEntry) => void;
  defaultMeal?: string;
}

const ScanFoodModal = ({ isOpen, onClose, onAdd, defaultMeal }: ScanFoodModalProps) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [step, setStep] = useState<"capture" | "manual">("capture");
  const [mealType, setMealType] = useState(defaultMeal || "lunch");

  // Manual entry after "scanning"
  const [foodName, setFoodName] = useState("");
  const [servingSize, setServingSize] = useState(100);
  const [servings, setServings] = useState(1);
  const [calories, setCalories] = useState(0);
  const [protein, setProtein] = useState(0);
  const [carbs, setCarbs] = useState(0);
  const [fat, setFat] = useState(0);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
      setStep("manual");
    };
    reader.readAsDataURL(file);
  };

  const totalCals = Math.round(calories * servings);
  const totalProtein = Math.round(protein * servings * 10) / 10;
  const totalCarbs = Math.round(carbs * servings * 10) / 10;
  const totalFat = Math.round(fat * servings * 10) / 10;

  const handleAdd = () => {
    if (!foodName.trim()) return;
    const entry: FoodLogEntry = {
      id: crypto.randomUUID(),
      foodId: `scanned_${Date.now()}`,
      foodName: foodName.trim(),
      mealType: mealType as FoodLogEntry["mealType"],
      quantity: servings,
      unit: "portion",
      portionLabel: `${servingSize}g`,
      gramsConsumed: servingSize * servings,
      calories: totalCals,
      protein: totalProtein,
      carbs: totalCarbs,
      fat: totalFat,
      timestamp: Date.now(),
      date: getTodayKey(),
    };
    onAdd(entry);
    handleReset();
  };

  const handleReset = () => {
    setStep("capture");
    setImagePreview(null);
    setFoodName("");
    setServingSize(100);
    setServings(1);
    setCalories(0);
    setProtein(0);
    setCarbs(0);
    setFat(0);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={handleReset} className="fixed inset-0 bg-black/60 z-50" />
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 max-h-[90vh] overflow-y-auto rounded-t-3xl bg-background"
          >
            <div className="max-w-lg mx-auto">
              <div className="flex justify-center pt-3 pb-1">
                <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
              </div>

              <div className="flex items-center justify-between px-5 py-3">
                <h2 className="font-heading font-bold text-lg text-foreground">
                  {step === "capture" ? "Escanear alimento" : "Datos nutricionales"}
                </h2>
                <button onClick={handleReset} className="p-1.5 rounded-full bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Meal selector */}
              <div className="px-5 mb-3">
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {Object.entries(MEAL_LABELS).map(([key, label]) => (
                    <button
                      key={key}
                      onClick={() => setMealType(key)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                        mealType === key
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {step === "capture" && (
                <div className="px-5 pb-8 space-y-4">
                  <div className="glass-card rounded-2xl p-8 text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                      <Camera className="w-8 h-8 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-heading font-bold text-foreground">Fotografía la etiqueta</h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        Toma una foto de la tabla nutricional del producto y luego ingresa los datos manualmente.
                      </p>
                    </div>

                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      className="hidden"
                      onChange={handleFileChange}
                    />

                    <div className="flex gap-3">
                      <button
                        onClick={() => fileRef.current?.click()}
                        className="flex-1 gradient-primary text-primary-foreground font-semibold py-3 rounded-xl flex items-center justify-center gap-2 text-sm"
                      >
                        <Camera className="w-4 h-4" /> Tomar foto
                      </button>
                      <button
                        onClick={() => {
                          if (fileRef.current) {
                            fileRef.current.removeAttribute('capture');
                            fileRef.current.click();
                            fileRef.current.setAttribute('capture', 'environment');
                          }
                        }}
                        className="flex-1 bg-secondary text-foreground font-semibold py-3 rounded-xl flex items-center justify-center gap-2 text-sm"
                      >
                        <Upload className="w-4 h-4" /> Galería
                      </button>
                    </div>

                    <button
                      onClick={() => setStep("manual")}
                      className="text-xs text-primary font-medium"
                    >
                      O ingresar datos manualmente →
                    </button>
                  </div>
                </div>
              )}

              {step === "manual" && (
                <div className="px-5 pb-8 space-y-4">
                  {imagePreview && (
                    <div className="rounded-2xl overflow-hidden max-h-40">
                      <img src={imagePreview} alt="Etiqueta" className="w-full h-full object-cover" />
                    </div>
                  )}

                  <p className="text-xs text-muted-foreground">
                    Ingresa los datos de la etiqueta nutricional por porción:
                  </p>

                  {/* Food name */}
                  <div className="glass-card rounded-xl p-3 space-y-1">
                    <label className="text-xs text-muted-foreground font-medium">Nombre del alimento</label>
                    <Input value={foodName} onChange={e => setFoodName(e.target.value)} placeholder="Ej: Galletas integrales" className="h-9" />
                  </div>

                  {/* Serving size */}
                  <div className="glass-card rounded-xl p-3 space-y-1">
                    <label className="text-xs text-muted-foreground font-medium">Tamaño porción (g)</label>
                    <Input type="number" value={servingSize} onChange={e => setServingSize(Math.max(1, parseInt(e.target.value) || 0))} className="h-9" min={1} />
                  </div>

                  {/* Nutritional values per serving */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="glass-card rounded-xl p-3 space-y-1">
                      <label className="text-xs text-muted-foreground font-medium">Calorías (kcal)</label>
                      <Input type="number" value={calories} onChange={e => setCalories(Math.max(0, parseInt(e.target.value) || 0))} className="h-9" min={0} />
                    </div>
                    <div className="glass-card rounded-xl p-3 space-y-1">
                      <label className="text-xs text-muted-foreground font-medium">Proteína (g)</label>
                      <Input type="number" value={protein} onChange={e => setProtein(Math.max(0, parseFloat(e.target.value) || 0))} className="h-9" min={0} step={0.1} />
                    </div>
                    <div className="glass-card rounded-xl p-3 space-y-1">
                      <label className="text-xs text-muted-foreground font-medium">Carbohidratos (g)</label>
                      <Input type="number" value={carbs} onChange={e => setCarbs(Math.max(0, parseFloat(e.target.value) || 0))} className="h-9" min={0} step={0.1} />
                    </div>
                    <div className="glass-card rounded-xl p-3 space-y-1">
                      <label className="text-xs text-muted-foreground font-medium">Grasa (g)</label>
                      <Input type="number" value={fat} onChange={e => setFat(Math.max(0, parseFloat(e.target.value) || 0))} className="h-9" min={0} step={0.1} />
                    </div>
                  </div>

                  {/* How many servings */}
                  <div className="glass-card rounded-xl p-4">
                    <p className="text-xs text-muted-foreground font-medium mb-2">¿Cuántas porciones consumes?</p>
                    <div className="flex items-center justify-center gap-4">
                      <button onClick={() => setServings(Math.max(0.5, servings - 0.5))} className="w-10 h-10 rounded-full bg-muted text-foreground font-bold flex items-center justify-center">
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="text-3xl font-heading font-bold text-foreground w-16 text-center">{servings}</span>
                      <button onClick={() => setServings(servings + 0.5)} className="w-10 h-10 rounded-full bg-muted text-foreground font-bold flex items-center justify-center">
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Totals preview */}
                  <div className="grid grid-cols-4 gap-2">
                    <div className="bg-primary/10 rounded-xl p-2.5 text-center">
                      <p className="text-base font-bold text-primary">{totalCals}</p>
                      <p className="text-[10px] text-muted-foreground">kcal</p>
                    </div>
                    <div className="bg-primary/10 rounded-xl p-2.5 text-center">
                      <p className="text-base font-bold text-foreground">{totalProtein}g</p>
                      <p className="text-[10px] text-muted-foreground">Prot</p>
                    </div>
                    <div className="bg-accent/10 rounded-xl p-2.5 text-center">
                      <p className="text-base font-bold text-foreground">{totalCarbs}g</p>
                      <p className="text-[10px] text-muted-foreground">Carbs</p>
                    </div>
                    <div className="bg-rosa-light/20 rounded-xl p-2.5 text-center">
                      <p className="text-base font-bold text-foreground">{totalFat}g</p>
                      <p className="text-[10px] text-muted-foreground">Grasa</p>
                    </div>
                  </div>

                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={handleAdd}
                    disabled={!foodName.trim()}
                    className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow disabled:opacity-50"
                  >
                    ✅ Añadir a {MEAL_LABELS[mealType]}
                  </motion.button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ScanFoodModal;
