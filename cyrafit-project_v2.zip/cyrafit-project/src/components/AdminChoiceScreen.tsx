import { motion } from "framer-motion";
import { Shield, Sparkles } from "lucide-react";

interface AdminChoiceScreenProps {
  name?: string;
  onChoose: (choice: "admin" | "app") => void;
}

const AdminChoiceScreen = ({ name, onChoose }: AdminChoiceScreenProps) => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-sm w-full space-y-8"
      >
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-heading font-bold text-foreground">
            Hola{name ? `, ${name}` : ""} 👋
          </h2>
          <p className="text-sm text-muted-foreground">
            ¿A dónde quieres entrar hoy?
          </p>
        </div>

        <div className="space-y-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => onChoose("admin")}
            className="w-full glass-card rounded-2xl p-5 flex items-center gap-4 text-left hover:shadow-glow transition-shadow"
          >
            <div className="w-12 h-12 rounded-2xl gradient-primary flex items-center justify-center shrink-0">
              <Shield className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <p className="font-heading font-bold text-foreground">
                Panel de administración
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Usuarios, suscripciones y contenido
              </p>
            </div>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => onChoose("app")}
            className="w-full glass-card rounded-2xl p-5 flex items-center gap-4 text-left hover:shadow-glow transition-shadow"
          >
            <div className="w-12 h-12 rounded-2xl bg-accent/20 flex items-center justify-center shrink-0">
              <Sparkles className="w-6 h-6 text-accent-foreground" />
            </div>
            <div className="flex-1">
              <p className="font-heading font-bold text-foreground">
                Acceso a la aplicación
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Entrar como usuaria a Cyra
              </p>
            </div>
          </motion.button>
        </div>

        <p className="text-center text-xs text-muted-foreground">
          Puedes cambiar entre vistas desde el menú de ajustes.
        </p>
      </motion.div>
    </div>
  );
};

export default AdminChoiceScreen;
