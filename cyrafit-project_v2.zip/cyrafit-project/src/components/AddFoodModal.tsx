import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Search, Plus, Minus, Apple, ChevronRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  FoodItem,
  FoodLogEntry,
  FOOD_DATABASE,
  MEAL_LABELS,
  calculateFoodMacros,
  getTodayKey,
} from "@/lib/foodDatabase";

interface AddFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (entry: FoodLogEntry) => void;
  defaultMeal?: string;
}

type ViewState = "search" | "detail";

const CATEGORIES = [...new Set(FOOD_DATABASE.map(f => f.category))];

const AddFoodModal = ({ isOpen, onClose, onAdd, defaultMeal }: AddFoodModalProps) => {
  const [view, setView] = useState<ViewState>("search");
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [mealType, setMealType] = useState(defaultMeal || "lunch");
  const [unit, setUnit] = useState<"g" | "portion">("portion");
  const [quantity, setQuantity] = useState(1);
  const [grams, setGrams] = useState(100);

  const filteredFoods = useMemo(() => {
    let list = FOOD_DATABASE;
    if (selectedCategory) list = list.filter(f => f.category === selectedCategory);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(f => f.name.toLowerCase().includes(q));
    }
    return list;
  }, [search, selectedCategory]);

  const gramsConsumed = unit === "portion" && selectedFood
    ? quantity * selectedFood.portionWeightG
    : grams;

  const macros = selectedFood ? calculateFoodMacros(selectedFood, gramsConsumed) : null;

  const handleSelectFood = (food: FoodItem) => {
    setSelectedFood(food);
    setUnit("portion");
    setQuantity(1);
    setGrams(food.defaultPortionG);
    setView("detail");
  };

  const handleAdd = () => {
    if (!selectedFood || !macros) return;
    const entry: FoodLogEntry = {
      id: crypto.randomUUID(),
      foodId: selectedFood.id,
      foodName: selectedFood.name,
      mealType: mealType as FoodLogEntry["mealType"],
      quantity,
      unit,
      portionLabel: selectedFood.portionLabel,
      gramsConsumed,
      calories: macros.calories,
      protein: macros.protein,
      carbs: macros.carbs,
      fat: macros.fat,
      timestamp: Date.now(),
      date: getTodayKey(),
    };
    onAdd(entry);
    handleReset();
  };

  const handleReset = () => {
    setView("search");
    setSelectedFood(null);
    setSearch("");
    setSelectedCategory(null);
    setQuantity(1);
    setGrams(100);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={handleReset} className="fixed inset-0 bg-black/60 z-50" />
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 max-h-[90vh] overflow-y-auto rounded-t-3xl bg-background"
          >
            <div className="max-w-lg mx-auto">
              <div className="flex justify-center pt-3 pb-1">
                <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
              </div>

              <div className="flex items-center justify-between px-5 py-3">
                <h2 className="font-heading font-bold text-lg text-foreground">
                  {view === "search" ? "Añadir alimento" : selectedFood?.name}
                </h2>
                <button onClick={handleReset} className="p-1.5 rounded-full bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {view === "search" && (
                <div className="px-5 pb-8 space-y-4">
                  {/* Meal selector */}
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {Object.entries(MEAL_LABELS).map(([key, label]) => (
                      <button
                        key={key}
                        onClick={() => setMealType(key)}
                        className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                          mealType === key
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-muted-foreground"
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>

                  {/* Search */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      placeholder="Buscar alimento..."
                      className="pl-9 h-10"
                    />
                  </div>

                  {/* Category filters */}
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    <button
                      onClick={() => setSelectedCategory(null)}
                      className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                        !selectedCategory ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      Todos
                    </button>
                    {CATEGORIES.map(cat => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                          selectedCategory === cat ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  {/* Food list */}
                  <div className="space-y-1 max-h-[45vh] overflow-y-auto">
                    {filteredFoods.map(food => (
                      <button
                        key={food.id}
                        onClick={() => handleSelectFood(food)}
                        className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/50 transition-colors text-left"
                      >
                        <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center shrink-0">
                          <Apple className="w-4 h-4 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-foreground truncate">{food.name}</p>
                          <p className="text-[10px] text-muted-foreground">
                            {food.caloriesPer100g} kcal/100g · P:{food.proteinPer100g}g · C:{food.carbsPer100g}g · G:{food.fatPer100g}g
                          </p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                      </button>
                    ))}
                    {filteredFoods.length === 0 && (
                      <p className="text-center text-sm text-muted-foreground py-8">No se encontraron alimentos</p>
                    )}
                  </div>
                </div>
              )}

              {view === "detail" && selectedFood && macros && (
                <div className="px-5 pb-8 space-y-4">
                  <button onClick={() => setView("search")} className="text-xs text-primary font-medium">← Volver a buscar</button>

                  {/* Unit toggle */}
                  <div className="flex gap-2 bg-card rounded-2xl p-1.5">
                    <button
                      onClick={() => setUnit("portion")}
                      className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${
                        unit === "portion" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Porciones ({selectedFood.portionLabel})
                    </button>
                    <button
                      onClick={() => setUnit("g")}
                      className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${
                        unit === "g" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Gramos
                    </button>
                  </div>

                  {/* Quantity */}
                  {unit === "portion" ? (
                    <div className="glass-card rounded-xl p-4">
                      <p className="text-xs text-muted-foreground font-medium mb-2">Cantidad ({selectedFood.portionLabel} = {selectedFood.portionWeightG}g)</p>
                      <div className="flex items-center justify-center gap-4">
                        <button onClick={() => setQuantity(Math.max(0.5, quantity - 0.5))} className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center">
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-3xl font-heading font-bold text-foreground w-16 text-center">{quantity}</span>
                        <button onClick={() => setQuantity(quantity + 0.5)} className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center">
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-muted-foreground text-center mt-1">= {gramsConsumed}g</p>
                    </div>
                  ) : (
                    <div className="glass-card rounded-xl p-4">
                      <p className="text-xs text-muted-foreground font-medium mb-2">Gramos</p>
                      <div className="flex items-center justify-center gap-4">
                        <button onClick={() => setGrams(Math.max(10, grams - 10))} className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center">
                          <Minus className="w-4 h-4" />
                        </button>
                        <Input
                          type="number"
                          value={grams}
                          onChange={e => setGrams(Math.max(1, parseInt(e.target.value) || 0))}
                          className="text-center text-2xl font-bold w-24 h-12"
                          min={1}
                        />
                        <button onClick={() => setGrams(grams + 10)} className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center">
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Macros preview */}
                  <div className="grid grid-cols-4 gap-2">
                    <div className="bg-primary/10 rounded-xl p-3 text-center">
                      <p className="text-lg font-bold text-primary">{macros.calories}</p>
                      <p className="text-[10px] text-muted-foreground">kcal</p>
                    </div>
                    <div className="bg-primary/10 rounded-xl p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{macros.protein}g</p>
                      <p className="text-[10px] text-muted-foreground">Proteína</p>
                    </div>
                    <div className="bg-accent/10 rounded-xl p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{macros.carbs}g</p>
                      <p className="text-[10px] text-muted-foreground">Carbos</p>
                    </div>
                    <div className="bg-rosa-light/20 rounded-xl p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{macros.fat}g</p>
                      <p className="text-[10px] text-muted-foreground">Grasa</p>
                    </div>
                  </div>

                  {/* Add button */}
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={handleAdd}
                    className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow"
                  >
                    ✅ Añadir a {MEAL_LABELS[mealType]}
                  </motion.button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AddFoodModal;
