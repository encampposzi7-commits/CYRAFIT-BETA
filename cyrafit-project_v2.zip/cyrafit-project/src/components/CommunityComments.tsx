import { useEffect, useRef, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { Image as ImageIcon, Reply, Send, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { uploadCommunityImage } from "@/lib/communityUpload";

type Comment = {
  id: string;
  post_id: string;
  user_id: string;
  parent_id: string | null;
  content: string;
  image_url: string | null;
  created_at: string;
};

type ProfileLite = { id: string; name: string | null; email: string | null };

interface Props {
  postId: string;
}

const CommunityComments = ({ postId }: Props) => {
  const { user } = useAuth();
  const { isAdmin } = useIsAdmin();
  const [comments, setComments] = useState<Comment[]>([]);
  const [profiles, setProfiles] = useState<Record<string, ProfileLite>>({});
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [replyTo, setReplyTo] = useState<Comment | null>(null);
  const [sending, setSending] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = async () => {
    const { data } = await supabase
      .from("community_comments")
      .select("*")
      .eq("post_id", postId)
      .order("created_at", { ascending: true });
    const list = (data ?? []) as Comment[];
    setComments(list);

    const ids = Array.from(new Set(list.map((c) => c.user_id)));
    if (ids.length > 0) {
      const { data: profs } = await supabase
        .from("profile")
        .select("id, name, email")
        .in("id", ids);
      const map: Record<string, ProfileLite> = {};
      (profs ?? []).forEach((p) => (map[p.id] = p as ProfileLite));
      setProfiles(map);
    }
  };

  useEffect(() => {
    void load();
    const channel = supabase
      .channel(`comments-${postId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "community_comments", filter: `post_id=eq.${postId}` },
        load,
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [postId]);

  const pickImage = (file: File | null) => {
    setImage(file);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(file ? URL.createObjectURL(file) : null);
  };

  const clearForm = () => {
    setContent("");
    pickImage(null);
    setReplyTo(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const submit = async () => {
    if (!user || !content.trim()) return;
    setSending(true);
    let image_url: string | null = null;
    if (image) {
      const res = await uploadCommunityImage(user.id, image, "comments");
      if (res.error) {
        setSending(false);
        return toast.error(res.error);
      }
      image_url = res.url;
    }
    const { error } = await supabase.from("community_comments").insert({
      post_id: postId,
      user_id: user.id,
      parent_id: replyTo?.id ?? null,
      content: content.trim(),
      image_url,
    });
    setSending(false);
    if (error) return toast.error(error.message);
    clearForm();
  };

  const remove = async (c: Comment) => {
    if (!confirm("¿Eliminar este comentario?")) return;
    const { error } = await supabase.from("community_comments").delete().eq("id", c.id);
    if (error) toast.error(error.message);
  };

  const rootComments = comments.filter((c) => !c.parent_id);
  const repliesOf = (id: string) => comments.filter((c) => c.parent_id === id);

  const renderAuthor = (uid: string) => {
    const p = profiles[uid];
    return p?.name || p?.email?.split("@")[0] || "Usuaria";
  };

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold text-foreground">
        Comentarios ({comments.length})
      </h3>

      {/* Composer */}
      {user && (
        <div className="glass-card rounded-2xl p-3 space-y-2">
          {replyTo && (
            <div className="flex items-center justify-between text-[11px] bg-secondary/40 rounded-lg px-2 py-1">
              <span className="text-muted-foreground">
                Respondiendo a{" "}
                <span className="font-semibold text-foreground">{renderAuthor(replyTo.user_id)}</span>
              </span>
              <button onClick={() => setReplyTo(null)} className="text-muted-foreground">
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Escribe un comentario..."
            rows={2}
            maxLength={2000}
            className="resize-none"
          />
          {previewUrl && (
            <div className="relative inline-block">
              <img src={previewUrl} alt="preview" className="max-h-32 rounded-lg" />
              <button
                onClick={() => pickImage(null)}
                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <div className="flex items-center justify-between">
            <button
              onClick={() => fileRef.current?.click()}
              className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1"
            >
              <ImageIcon className="w-4 h-4" /> Adjuntar imagen
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => pickImage(e.target.files?.[0] ?? null)}
            />
            <Button size="sm" onClick={submit} disabled={sending || !content.trim()}>
              <Send className="w-4 h-4 mr-1" />
              {sending ? "Enviando..." : "Comentar"}
            </Button>
          </div>
        </div>
      )}

      {/* List */}
      <div className="space-y-3">
        {rootComments.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-4">
            Aún no hay comentarios. ¡Sé la primera en escribir!
          </p>
        )}
        {rootComments.map((c) => (
          <div key={c.id} className="glass-card rounded-2xl p-3 space-y-2">
            <CommentBody
              c={c}
              authorName={renderAuthor(c.user_id)}
              canDelete={user?.id === c.user_id || isAdmin}
              onReply={() => setReplyTo(c)}
              onDelete={() => remove(c)}
            />
            {repliesOf(c.id).map((r) => (
              <div
                key={r.id}
                className="ml-6 mt-2 pl-3 border-l-2 border-primary/20 space-y-1"
              >
                <CommentBody
                  c={r}
                  authorName={renderAuthor(r.user_id)}
                  canDelete={user?.id === r.user_id || isAdmin}
                  onReply={() => setReplyTo(c)}
                  onDelete={() => remove(r)}
                  isReply
                />
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

const CommentBody = ({
  c,
  authorName,
  canDelete,
  onReply,
  onDelete,
  isReply,
}: {
  c: Comment;
  authorName: string;
  canDelete: boolean;
  onReply: () => void;
  onDelete: () => void;
  isReply?: boolean;
}) => (
  <div>
    <div className="flex items-center justify-between">
      <p className="text-xs font-semibold text-foreground">{authorName}</p>
      <p className="text-[10px] text-muted-foreground">
        {formatDistanceToNow(new Date(c.created_at), { addSuffix: true, locale: es })}
      </p>
    </div>
    <p className="text-sm text-foreground/90 mt-1 whitespace-pre-wrap">{c.content}</p>
    {c.image_url && (
      <img
        src={c.image_url}
        alt="adjunto"
        className="mt-2 max-h-64 rounded-lg border border-border"
      />
    )}
    <div className="flex items-center gap-3 mt-2">
      {!isReply && (
        <button
          onClick={onReply}
          className="text-[11px] text-muted-foreground hover:text-primary inline-flex items-center gap-1"
        >
          <Reply className="w-3 h-3" /> Responder
        </button>
      )}
      {canDelete && (
        <button
          onClick={onDelete}
          className="text-[11px] text-muted-foreground hover:text-destructive inline-flex items-center gap-1"
        >
          <Trash2 className="w-3 h-3" /> Eliminar
        </button>
      )}
    </div>
  </div>
);

export default CommunityComments;
