import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import NutritionProfileSetup from "@/components/NutritionProfileSetup";
import { loadNutritionProfile, saveNutritionProfile, NutritionProfile } from "@/lib/nutrition";
import { useAuth } from "@/contexts/AuthContext";
import { Target } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const EditNutritionGoalDialog = ({ open, onOpenChange }: Props) => {
  const { profile: authProfile } = useAuth();
  const initial = open ? loadNutritionProfile() : null;

  const handleComplete = (p: NutritionProfile) => {
    saveNutritionProfile(p);
    toast({ title: "Objetivo actualizado", description: "Tus calorías y macros se recalcularon." });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Objetivo nutricional
          </DialogTitle>
          <DialogDescription>
            Ajusta tus datos para recalcular calorías y macros diarios.
          </DialogDescription>
        </DialogHeader>

        <div className="pt-2">
          <NutritionProfileSetup
            onComplete={handleComplete}
            initial={initial}
            presetName={authProfile?.name ?? undefined}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditNutritionGoalDialog;
