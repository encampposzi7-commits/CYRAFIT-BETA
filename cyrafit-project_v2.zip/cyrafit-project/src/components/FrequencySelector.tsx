import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar, Dumbbell, ArrowLeft, GraduationCap, Star, Zap, Trophy, Lock, Baby } from "lucide-react";

const STORAGE_KEY_PP_OVERRIDE = "lunafit_postpartum_override";
import { TrainingFrequency, TrainingLevel, LEVEL_LABELS, LEVEL_DESCRIPTIONS } from "@/lib/training";
import BottomNav from "@/components/BottomNav";
import PremiumModal from "@/components/PremiumModal";
import { usePremium } from "@/hooks/usePremium";

interface FrequencySelectorProps {
  onSelect: (freq: TrainingFrequency, level: TrainingLevel) => void;
}

const levelOptions: { level: TrainingLevel; icon: React.ReactNode; emoji: string; tips: string[] }[] = [
  {
    level: "beginner",
    icon: <Star className="w-5 h-5 text-primary" />,
    emoji: "🌱",
    tips: [
      "Técnica y movimientos básicos",
      "Adaptación neuromuscular",
      "Máquinas guiadas y peso corporal",
      "Evitar ejercicios complejos o de alto impacto",
    ],
  },
  {
    level: "intermediate",
    icon: <Zap className="w-5 h-5 text-primary" />,
    emoji: "💪",
    tips: [
      "Progresión de cargas",
      "Mayor variedad de ejercicios",
      "Pesos libres y compuestos",
      "Estructura planificada",
    ],
  },
  {
    level: "advanced",
    icon: <Trophy className="w-5 h-5 text-primary" />,
    emoji: "🔥",
    tips: [
      "Periodización y optimización",
      "Ejercicios complejos y pesados",
      "Técnicas avanzadas (drop sets, supersets)",
      "Énfasis en recuperación estratégica",
    ],
  },
];

const freqOptions: { freq: TrainingFrequency; label: string; desc: string; split: string }[] = [
  {
    freq: 3,
    label: "3 días / semana",
    desc: "Ideal para principiantes o agendas ocupadas",
    split: "2× Full Body + 1× Core y Estabilidad",
  },
  {
    freq: 4,
    label: "4 días / semana",
    desc: "Balance perfecto entre volumen y recuperación",
    split: "2× Tren Inferior + 2× Tren Superior",
  },
  {
    freq: 5,
    label: "5 días / semana",
    desc: "Para quienes buscan máximo progreso",
    split: "2× Tren Inferior + 2× Tren Superior + 1× Core",
  },
];

const FrequencySelector = ({ onSelect }: FrequencySelectorProps) => {
  const [step, setStep] = useState<"level" | "frequency">("level");
  const [selectedLevel, setSelectedLevel] = useState<TrainingLevel | null>(null);
  const [showPremium, setShowPremium] = useState(false);
  const [postpartumOn, setPostpartumOn] = useState<boolean>(
    () => localStorage.getItem(STORAGE_KEY_PP_OVERRIDE) === "1"
  );
  const { isPremium } = usePremium();

  const togglePostpartum = () => {
    const next = !postpartumOn;
    setPostpartumOn(next);
    if (next) localStorage.setItem(STORAGE_KEY_PP_OVERRIDE, "1");
    else localStorage.removeItem(STORAGE_KEY_PP_OVERRIDE);
  };

  const handleLevelSelect = (level: TrainingLevel) => {
    if ((level === "intermediate" || level === "advanced") && !isPremium) {
      setShowPremium(true);
      return;
    }
    setSelectedLevel(level);
    setStep("frequency");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col pb-24">
      <div className="gradient-warm pt-14 pb-8 px-5">
        <div className="max-w-lg mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-16 h-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-4"
          >
            {step === "level" ? (
              <GraduationCap className="w-8 h-8 text-primary-foreground" />
            ) : (
              <Calendar className="w-8 h-8 text-primary-foreground" />
            )}
          </motion.div>
          <h1 className="text-2xl font-heading font-bold text-foreground">
            {step === "level" ? "¿Cuál es tu nivel?" : "¿Cuántos días entrenas?"}
          </h1>
          <p className="text-sm text-muted-foreground mt-2">
            {step === "level"
              ? "Selecciona tu experiencia para ajustar los ejercicios a tu nivel."
              : "Selecciona tu frecuencia semanal. Puedes cambiarla en cualquier momento."}
          </p>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 py-6 space-y-3 flex-1">
        <AnimatePresence mode="wait">
          {step === "level" && (
            <motion.div
              key="level"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-3"
            >
              <button
                onClick={togglePostpartum}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-semibold transition-all border ${
                  postpartumOn
                    ? "bg-primary text-primary-foreground border-primary shadow-soft"
                    : "bg-card text-foreground border-border hover:bg-secondary/50"
                }`}
              >
                <Baby className="w-4 h-4" />
                {postpartumOn ? "Entrenamiento Post Parto activado" : "Estoy en post parto (activar modo)"}
              </button>
              {postpartumOn && (
                <p className="text-[11px] text-muted-foreground text-center px-2 -mt-1">
                  El nivel se ajusta automáticamente a recuperación suave. Elige cualquier opción para continuar a la frecuencia semanal.
                </p>
              )}
              {levelOptions.map((opt, i) => {
                const locked = (opt.level === "intermediate" || opt.level === "advanced") && !isPremium;
                return (
                  <motion.button
                    key={opt.level}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    onClick={() => handleLevelSelect(opt.level)}
                    className="relative w-full glass-card rounded-2xl p-5 text-left hover:shadow-soft transition-all active:scale-[0.98] group"
                  >
                    {locked && (
                      <span className="absolute top-3 right-3 inline-flex items-center gap-1 text-[10px] font-bold text-primary-foreground gradient-primary px-2 py-0.5 rounded-full">
                        <Lock className="w-2.5 h-2.5" /> Premium
                      </span>
                    )}
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center shrink-0 group-hover:bg-primary/10 transition-colors text-2xl">
                        {opt.emoji}
                      </div>
                      <div className="flex-1">
                        <p className="font-heading font-bold text-foreground text-base">
                          {LEVEL_LABELS[opt.level]}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {LEVEL_DESCRIPTIONS[opt.level]}
                        </p>
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {opt.tips.map((tip) => (
                            <span
                              key={tip}
                              className="text-[10px] bg-secondary text-secondary-foreground px-2 py-0.5 rounded-full"
                            >
                              {tip}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </motion.div>
          )}

          {step === "frequency" && selectedLevel && (
            <motion.div
              key="frequency"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-3"
            >
              <button
                onClick={() => setStep("level")}
                className="flex items-center gap-1 text-sm text-primary font-medium mb-2"
              >
                <ArrowLeft className="w-4 h-4" /> Cambiar nivel ({LEVEL_LABELS[selectedLevel]})
              </button>

              {freqOptions.map((opt, i) => (
                <motion.button
                  key={opt.freq}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => onSelect(opt.freq, selectedLevel)}
                  className="w-full glass-card rounded-2xl p-5 text-left hover:shadow-soft transition-all active:scale-[0.98] group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center shrink-0 group-hover:bg-primary/10 transition-colors">
                      <Dumbbell className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-heading font-bold text-foreground text-base">
                        {opt.label}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">{opt.desc}</p>
                      <p className="text-xs text-primary font-semibold mt-1.5">{opt.split}</p>
                    </div>
                  </div>
                </motion.button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <PremiumModal
        open={showPremium}
        onOpenChange={setShowPremium}
        reason="Los entrenamientos intermedio y avanzado son parte de Cyrafit Premium. Empieza gratis con el nivel principiante cuando quieras."
      />
      <BottomNav />
    </div>
  );
};

export default FrequencySelector;
