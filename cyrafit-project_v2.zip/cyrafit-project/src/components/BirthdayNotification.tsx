import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";

const BirthdayNotification = () => {
  const { profile } = useAuth();
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!profile?.birth_date) return;

    const today = new Date();
    const birth = new Date(profile.birth_date);

    if (today.getMonth() === birth.getMonth() && today.getDate() === birth.getDate()) {
      const key = `cyra_birthday_${today.getFullYear()}`;
      if (!localStorage.getItem(key)) {
        setShow(true);
        localStorage.setItem(key, "true");
      }
    }
  }, [profile]);

  if (!show) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: -20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: -20 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm"
        onClick={() => setShow(false)}
      >
        <motion.div
          initial={{ y: 30 }}
          animate={{ y: 0 }}
          className="bg-card rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl border border-primary/20"
          onClick={(e) => e.stopPropagation()}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="text-6xl mb-4"
          >
            🎉
          </motion.div>
          <h2 className="text-2xl font-heading font-bold text-foreground mb-3">
            ¡Feliz cumpleaños!
          </h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-2">
            Hoy celebramos tu progreso 💗 sigue brillando en este nuevo ciclo ✨
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            Estamos contigo en cada paso que des 💫 — <span className="text-primary font-semibold">Equipo Cyra</span>
          </p>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => setShow(false)}
            className="gradient-primary text-primary-foreground font-heading font-bold py-3 px-8 rounded-2xl shadow-glow"
          >
            ¡Gracias! 🥰
          </motion.button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default BirthdayNotification;
