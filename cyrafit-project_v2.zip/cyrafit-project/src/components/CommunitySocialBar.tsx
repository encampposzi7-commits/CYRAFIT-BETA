import { useEffect, useState } from "react";
import { Instagram, Youtube, Globe, Music2, Save } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export type SocialLinks = {
  instagram_url: string | null;
  youtube_url: string | null;
  tiktok_url: string | null;
  website_url: string | null;
};

const empty: SocialLinks = {
  instagram_url: null,
  youtube_url: null,
  tiktok_url: null,
  website_url: null,
};

const CommunitySocialBar = () => {
  const { isAdmin } = useIsAdmin();
  const [links, setLinks] = useState<SocialLinks>(empty);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<SocialLinks>(empty);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const { data } = await supabase
      .from("admin_settings")
      .select("instagram_url, youtube_url, tiktok_url, website_url")
      .eq("id", 1)
      .maybeSingle();
    if (data) {
      setLinks(data as SocialLinks);
      setForm(data as SocialLinks);
    }
  };

  useEffect(() => {
    void load();
    const channel = supabase
      .channel("admin-settings")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "admin_settings" },
        load,
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("admin_settings")
      .update({
        instagram_url: form.instagram_url?.trim() || null,
        youtube_url: form.youtube_url?.trim() || null,
        tiktok_url: form.tiktok_url?.trim() || null,
        website_url: form.website_url?.trim() || null,
      })
      .eq("id", 1);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Enlaces actualizados");
    setOpen(false);
  };

  const items: { key: keyof SocialLinks; icon: typeof Instagram; label: string }[] = [
    { key: "instagram_url", icon: Instagram, label: "Instagram" },
    { key: "youtube_url", icon: Youtube, label: "YouTube" },
    { key: "tiktok_url", icon: Music2, label: "TikTok" },
    { key: "website_url", icon: Globe, label: "Sitio web" },
  ];

  const visible = items.filter((i) => !!links[i.key]);

  if (visible.length === 0 && !isAdmin) return null;

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {visible.map(({ key, icon: Icon, label }) => (
        <a
          key={key}
          href={links[key] as string}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full bg-secondary/40 text-foreground hover:bg-secondary transition"
          title={label}
        >
          <Icon className="w-3.5 h-3.5 text-primary" />
          {label}
        </a>
      ))}

      {isAdmin && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <button className="text-[11px] text-primary font-semibold hover:underline px-2 py-1">
              {visible.length === 0 ? "+ Añadir mis redes" : "Editar"}
            </button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Mis redes sociales</DialogTitle>
              <DialogDescription>
                Estos enlaces aparecen en la cabecera de la comunidad para que tus usuarias te
                sigan.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              {items.map(({ key, icon: Icon, label }) => (
                <label key={key} className="block text-xs">
                  <span className="inline-flex items-center gap-1.5 text-muted-foreground mb-1">
                    <Icon className="w-3.5 h-3.5" /> {label}
                  </span>
                  <Input
                    type="url"
                    placeholder={`https://${label.toLowerCase()}.com/...`}
                    value={form[key] ?? ""}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                    maxLength={400}
                  />
                </label>
              ))}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>
                Cancelar
              </Button>
              <Button onClick={save} disabled={saving}>
                <Save className="w-4 h-4 mr-1" />
                {saving ? "Guardando..." : "Guardar"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default CommunitySocialBar;
