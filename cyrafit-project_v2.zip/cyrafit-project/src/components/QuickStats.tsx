import { motion } from "framer-motion";
import { Flame, Footprints, Moon } from "lucide-react";

const stats = [
  { icon: Flame, label: "Calorías", value: "1,420", unit: "kcal" },
  { icon: Footprints, label: "Pasos", value: "6,230", unit: "" },
  { icon: Moon, label: "Sueño", value: "7.5", unit: "hrs" },
];

const QuickStats = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="grid grid-cols-3 gap-3"
    >
      {stats.map((stat, i) => (
        <div key={stat.label} className="glass-card rounded-2xl p-3 text-center">
          <stat.icon className="w-4 h-4 mx-auto text-primary mb-1.5" />
          <p className="text-lg font-heading font-bold text-foreground">{stat.value}</p>
          <p className="text-[10px] text-muted-foreground font-medium">{stat.unit || stat.label}</p>
        </div>
      ))}
    </motion.div>
  );
};

export default QuickStats;
