import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Play, Weight, BarChart3, Repeat, Gauge } from "lucide-react";
import { Exercise, ExerciseLog } from "@/lib/training";
import { resolveExerciseVideo, useExerciseVideosVersion } from "@/lib/exerciseVideos";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";

interface ExerciseDetailModalProps {
  exercise: Exercise;
  isOpen: boolean;
  onClose: () => void;
  onSave: (log: ExerciseLog) => void;
  existingLog?: ExerciseLog;
  targetRPE?: { min: number; max: number; label: string };
}

const RPE_LABELS: Record<number, string> = {
  1: "Muy fácil",
  2: "Fácil",
  3: "Ligero",
  4: "Moderado",
  5: "Algo difícil",
  6: "Difícil",
  7: "Muy difícil",
  8: "Intenso",
  9: "Casi al fallo",
  10: "Máximo esfuerzo",
};

const RPE_COLORS: Record<number, string> = {
  1: "bg-green-400",
  2: "bg-green-400",
  3: "bg-green-500",
  4: "bg-yellow-400",
  5: "bg-yellow-500",
  6: "bg-orange-400",
  7: "bg-orange-500",
  8: "bg-red-400",
  9: "bg-red-500",
  10: "bg-red-600",
};

const ExerciseDetailModal = ({ exercise, isOpen, onClose, onSave, existingLog, targetRPE }: ExerciseDetailModalProps) => {
  const [weight, setWeight] = useState(existingLog?.weight ?? 0);
  const [actualSets, setActualSets] = useState(existingLog?.actualSets ?? exercise.sets);
  const [actualReps, setActualReps] = useState(existingLog?.actualReps ?? exercise.reps);
  const [rpe, setRpe] = useState(existingLog?.rpe ?? (targetRPE ? Math.round((targetRPE.min + targetRPE.max) / 2) : 5));
  const [showVideo, setShowVideo] = useState(false);
  useExerciseVideosVersion();

  const handleSave = () => {
    onSave({ weight, actualSets, actualReps, rpe });
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 z-50"
          />
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 max-h-[92vh] overflow-y-auto rounded-t-3xl bg-background"
          >
            <div className="max-w-lg mx-auto">
              {/* Handle bar */}
              <div className="flex justify-center pt-3 pb-1">
                <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
              </div>

              {/* Header */}
              <div className="flex items-center justify-between px-5 py-3">
                <h2 className="font-heading font-bold text-lg text-foreground">{exercise.name}</h2>
                <button onClick={onClose} className="p-1.5 rounded-full bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Video demo - YouTube o Vimeo */}
              <div className="px-5 mb-4">
                {(() => {
                  const video = resolveExerciseVideo(exercise.name, exercise.videoId);
                  if (!video) {
                    return (
                      <div className="w-full rounded-2xl bg-muted aspect-video flex items-center justify-center">
                        <p className="text-sm text-muted-foreground">Video no disponible</p>
                      </div>
                    );
                  }

                  const thumbUrl =
                    video.source === "youtube"
                      ? `https://img.youtube.com/vi/${video.id}/hqdefault.jpg`
                      : `https://vumbnail.com/${video.id}.jpg`;

                  const embedUrl =
                    video.source === "youtube"
                      ? `https://www.youtube.com/embed/${video.id}?autoplay=1&rel=0&modestbranding=1&playsinline=1`
                      : `https://player.vimeo.com/video/${video.id}?autoplay=1&loop=1&title=0&byline=0&portrait=0`;

                  if (!showVideo) {
                    return (
                      <button
                        onClick={() => setShowVideo(true)}
                        className="w-full relative rounded-2xl overflow-hidden bg-muted aspect-video flex items-center justify-center group"
                      >
                        <img
                          src={thumbUrl}
                          alt={`Demo de ${exercise.name}`}
                          className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = "none";
                          }}
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-14 h-14 rounded-full bg-primary/90 flex items-center justify-center shadow-glow">
                            <Play className="w-6 h-6 text-primary-foreground ml-0.5" />
                          </div>
                        </div>
                        <span className="absolute bottom-2 left-3 text-xs font-medium text-white bg-black/50 px-2 py-0.5 rounded-full">
                          ▶ Ver demostración
                        </span>
                      </button>
                    );
                  }

                  return (
                    <div className="w-full rounded-2xl overflow-hidden aspect-video">
                      <iframe
                        src={embedUrl}
                        title={`Demo de ${exercise.name}`}
                        className="w-full h-full"
                        allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  );
                })()}
              </div>

              {/* Prescribed info */}
              <div className="px-5 mb-4">
                <div className="flex gap-2">
                  {[
                    { label: "Series", value: exercise.sets.toString() },
                    { label: "Reps", value: exercise.reps },
                    { label: "Descanso", value: exercise.rest },
                  ].map((item) => (
                    <div key={item.label} className="flex-1 bg-secondary rounded-xl p-3 text-center">
                      <p className="text-[10px] text-muted-foreground font-medium uppercase">{item.label}</p>
                      <p className="text-sm font-bold text-foreground mt-0.5">{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* Tempo guide */}
                {exercise.tempo && (
                  <div className="mt-3 rounded-xl border border-primary/20 bg-primary/5 p-3">
                    <p className="text-[11px] font-bold text-primary uppercase tracking-wider">
                      🎯 Tempo {exercise.tempo}
                    </p>
                    <p className="text-xs text-foreground/80 mt-1 leading-relaxed">
                      Formato bajada-pausa-subida (segundos). La técnica manda sobre el número de repeticiones — si pierdes el tempo, baja la tensión de la banda o termina la serie.
                    </p>
                  </div>
                )}

                {exercise.note && (
                  <div className="mt-2 text-xs text-muted-foreground leading-relaxed px-1">
                    💡 {exercise.note}
                  </div>
                )}
              </div>

              {/* Log form */}
              <div className="px-5 space-y-4 pb-8">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Registrar rendimiento
                </h3>

                {/* Weight */}
                <div className="glass-card rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <Weight className="w-4 h-4 text-primary" />
                    <label className="text-sm font-medium text-foreground">Peso (kg)</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setWeight(Math.max(0, weight - 2.5))}
                      className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center active:scale-95 transition-transform"
                    >
                      −
                    </button>
                    <Input
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="text-center text-lg font-bold flex-1 h-10"
                      min={0}
                      step={0.5}
                    />
                    <button
                      onClick={() => setWeight(weight + 2.5)}
                      className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center active:scale-95 transition-transform"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Actual sets */}
                <div className="glass-card rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-primary" />
                    <label className="text-sm font-medium text-foreground">Series realizadas</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setActualSets(Math.max(1, actualSets - 1))}
                      className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center active:scale-95 transition-transform"
                    >
                      −
                    </button>
                    <span className="flex-1 text-center text-lg font-bold text-foreground">{actualSets}</span>
                    <button
                      onClick={() => setActualSets(actualSets + 1)}
                      className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-lg flex items-center justify-center active:scale-95 transition-transform"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Actual reps */}
                <div className="glass-card rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <Repeat className="w-4 h-4 text-primary" />
                    <label className="text-sm font-medium text-foreground">Repeticiones realizadas</label>
                  </div>
                  <Input
                    type="text"
                    value={actualReps}
                    onChange={(e) => setActualReps(e.target.value)}
                    placeholder="Ej: 12, 10, 8"
                    className="h-10"
                  />
                </div>

                {/* RPE */}
                <div className="glass-card rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 justify-between">
                    <div className="flex items-center gap-2">
                      <Gauge className="w-4 h-4 text-primary" />
                      <label className="text-sm font-medium text-foreground">Esfuerzo percibido (RPE)</label>
                    </div>
                    {targetRPE && (
                      <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-semibold">
                        Objetivo {targetRPE.min}–{targetRPE.max}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-3xl font-bold text-foreground">{rpe}</span>
                    <span className={`text-xs font-semibold px-3 py-1 rounded-full text-white ${RPE_COLORS[rpe]}`}>
                      {RPE_LABELS[rpe]}
                    </span>
                  </div>
                  <Slider
                    value={[rpe]}
                    onValueChange={(val) => setRpe(val[0])}
                    min={1}
                    max={10}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-[10px] text-muted-foreground">
                    <span>1 Fácil</span>
                    <span>10 Máximo</span>
                  </div>
                </div>

                {/* Save button */}
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={handleSave}
                  className="w-full gradient-primary text-primary-foreground font-heading font-bold py-4 rounded-2xl shadow-glow"
                >
                  ✅ Guardar y completar
                </motion.button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ExerciseDetailModal;
