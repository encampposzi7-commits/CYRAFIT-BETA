import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, PartyPopper } from "lucide-react";
import { TrainingFrequency } from "@/lib/training";

interface TrainingCelebrationProps {
  frequency: TrainingFrequency;
  completedDays: Record<number, boolean>;
  weekPlanTypes: string[];
}

const STORAGE_KEY_CELEBRATION = "lunafit_celebration_history";
const STORAGE_KEY_STREAK = "lunafit_streak_data";

interface CelebrationHistory {
  lastCelebratedWeek: string;
  failedWeeksCount: number;
}

function getWeekKey(): string {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const weekNum = Math.ceil(((now.getTime() - start.getTime()) / 86400000 + start.getDay() + 1) / 7);
  return `${now.getFullYear()}-W${weekNum}`;
}

function loadCelebrationHistory(): CelebrationHistory {
  const raw = localStorage.getItem(STORAGE_KEY_CELEBRATION);
  if (!raw) return { lastCelebratedWeek: "", failedWeeksCount: 0 };
  try { return JSON.parse(raw); } catch { return { lastCelebratedWeek: "", failedWeeksCount: 0 }; }
}

function saveCelebrationHistory(h: CelebrationHistory) {
  localStorage.setItem(STORAGE_KEY_CELEBRATION, JSON.stringify(h));
}

function getUserName(): string {
  try {
    const profile = localStorage.getItem("lunafit_nutrition_profile");
    if (profile) {
      const p = JSON.parse(profile);
      if (p.name) return p.name;
    }
  } catch {}
  return "Campeona";
}

// Dispatch event when training day is completed for Progress sync
function dispatchTrainingComplete() {
  window.dispatchEvent(new CustomEvent("cyra_training_complete"));
}

function getMessage(frequency: TrainingFrequency, name: string): { title: string; body: string } {
  if (frequency === 3) {
    return {
      title: `🎉 ¡Felicidades, ${name}! 🎉`,
      body: `Completaste tus 3 días de entrenamiento 💪\n\nEstás dando el paso más importante: crear el hábito. No se trata de hacerlo perfecto, sino de estar presente y cumplir.\n\nCada día que viniste, incluso con cansancio o pocas ganas, suma más de lo que imaginas 🔥\n\nSigue así… esto recién comienza 🚀\n\n— Equipo Cyra`,
    };
  }
  if (frequency === 4) {
    return {
      title: `🚀 ¡Increíble, ${name}! 🚀`,
      body: `Completaste tus 4 días de entrenamiento 💪🔥\n\nTu constancia ya se está notando. No es casualidad, es resultado de elegirte a ti misma cada día.\n\nEstás más fuerte, más enfocada y más cerca de tu objetivo 👊\n\nSigue así, vas por un camino que pocos mantienen 💯\n\n— Equipo Cyra`,
    };
  }
  return {
    title: `🔥 ¡Nivel imparable, ${name}! 🔥`,
    body: `Completaste tus 5 días de entrenamiento 💪\n\nEsto ya no es motivación… es disciplina real. Estás construyendo un estilo de vida que marca la diferencia 🧠⚡\n\nMuy pocos llegan a este nivel de compromiso, y tú lo estás logrando 👏\n\nSigue así, porque aquí es donde empiezan los resultados grandes 💥\n\n— Equipo Cyra`,
  };
}

const TrainingCelebration = ({ frequency, completedDays, weekPlanTypes }: TrainingCelebrationProps) => {
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState<{ title: string; body: string } | null>(null);

  useEffect(() => {
    // Count completed training days (not rest days)
    const trainingDayIndices = weekPlanTypes
      .map((type, i) => (type !== "rest" ? i : -1))
      .filter(i => i >= 0);
    
    const completedTrainingDays = trainingDayIndices.filter(i => completedDays[i]).length;
    
    if (completedTrainingDays >= frequency) {
      const history = loadCelebrationHistory();
      const weekKey = getWeekKey();
      
      // Show if first time this week OR if they failed 2+ weeks and now succeeded
      const isFirstTime = history.lastCelebratedWeek === "";
      const isAfterFailStreak = history.failedWeeksCount >= 2;
      const alreadyCelebratedThisWeek = history.lastCelebratedWeek === weekKey;
      
      if (!alreadyCelebratedThisWeek && (isFirstTime || isAfterFailStreak || history.lastCelebratedWeek !== weekKey)) {
        const name = getUserName();
        setMessage(getMessage(frequency, name));
        setShow(true);
        saveCelebrationHistory({ lastCelebratedWeek: weekKey, failedWeeksCount: 0 });
      }
    }
  }, [completedDays, frequency, weekPlanTypes]);

  return (
    <AnimatePresence>
      {show && message && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShow(false)}
            className="fixed inset-0 bg-black/60 z-50"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="fixed inset-x-4 top-1/2 -translate-y-1/2 z-50 max-w-md mx-auto bg-background rounded-3xl p-6 shadow-2xl"
          >
            <button
              onClick={() => setShow(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-muted text-muted-foreground"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="w-20 h-20 rounded-full gradient-primary flex items-center justify-center mx-auto"
              >
                <PartyPopper className="w-10 h-10 text-primary-foreground" />
              </motion.div>

              <h2 className="font-heading font-bold text-xl text-foreground">
                {message.title}
              </h2>

              <div className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                {message.body}
              </div>

              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => setShow(false)}
                className="w-full gradient-primary text-primary-foreground font-heading font-bold py-3 rounded-2xl shadow-glow"
              >
                ¡Vamos por más! 💪
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default TrainingCelebration;
