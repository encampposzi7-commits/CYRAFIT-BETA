import { useState, type ReactNode } from "react";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import PremiumModal from "@/components/PremiumModal";
import { usePremium } from "@/hooks/usePremium";

interface PremiumGateProps {
  /** Content shown only to premium users */
  children: ReactNode;
  /** Title shown on the locked card */
  title?: string;
  /** Reason shown inside the upgrade modal */
  reason?: string;
  /** Render mode: 'card' (full block) or 'inline' (small lock chip) */
  variant?: "card" | "inline";
}

/**
 * Wraps premium-only UI. Shows an upgrade card to free users
 * and renders the children when premium.
 */
const PremiumGate = ({ children, title, reason, variant = "card" }: PremiumGateProps) => {
  const { isPremium, loading } = usePremium();
  const [open, setOpen] = useState(false);

  if (loading) return null;
  if (isPremium) return <>{children}</>;

  if (variant === "inline") {
    return (
      <>
        <button
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full"
        >
          <Lock className="w-3 h-3" />
          Premium
        </button>
        <PremiumModal open={open} onOpenChange={setOpen} reason={reason} />
      </>
    );
  }

  return (
    <>
      <div className="glass-card rounded-2xl p-5 text-center space-y-3 border-2 border-dashed border-primary/30">
        <div className="w-12 h-12 mx-auto rounded-2xl gradient-primary flex items-center justify-center">
          <Lock className="w-5 h-5 text-primary-foreground" />
        </div>
        <div>
          <h3 className="font-heading font-semibold text-foreground">
            {title ?? "Función Premium"}
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            {reason ?? "Desbloquea esta sección con Cyrafit Premium."}
          </p>
        </div>
        <Button
          onClick={() => setOpen(true)}
          className="w-full h-10 rounded-xl gradient-primary text-primary-foreground hover:opacity-90"
        >
          ✨ Hazte Premium
        </Button>
      </div>
      <PremiumModal open={open} onOpenChange={setOpen} reason={reason} />
    </>
  );
};

export default PremiumGate;
