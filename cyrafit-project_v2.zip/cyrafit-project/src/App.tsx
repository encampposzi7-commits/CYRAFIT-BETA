import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import BirthdayNotification from "@/components/BirthdayNotification";
import PaulaQuickDock from "@/components/PaulaQuickDock";
import BiometricGate from "@/components/BiometricGate";

import Index from "./pages/Index";
import Training from "./pages/Training";
import Nutrition from "./pages/Nutrition";
import Progress from "./pages/Progress";
import SettingsPage from "./pages/SettingsPage";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";
import AdminPage from "./pages/Admin";
import AdminVideos from "./pages/AdminVideos";
import Community from "./pages/Community";
import CommunityPost from "./pages/CommunityPost";
import { useEffect } from "react";
import { loadExerciseVideos } from "@/lib/exerciseVideos";

const queryClient = new QueryClient();

// App root component
const App = () => {
  useEffect(() => { void loadExerciseVideos(); }, []);
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BiometricGate>
            <BirthdayNotification />
            <BrowserRouter>
              <PaulaQuickDock />
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/training" element={<Training />} />
                <Route path="/nutrition" element={<Nutrition />} />
                <Route path="/progress" element={<Progress />} />
                <Route path="/settings" element={<SettingsPage />} />
                <Route path="/reset-password" element={<ResetPassword />} />
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/admin/videos" element={<AdminVideos />} />
                <Route path="/community" element={<Community />} />
                <Route path="/community/:id" element={<CommunityPost />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </BiometricGate>
        </TooltipProvider>

      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
