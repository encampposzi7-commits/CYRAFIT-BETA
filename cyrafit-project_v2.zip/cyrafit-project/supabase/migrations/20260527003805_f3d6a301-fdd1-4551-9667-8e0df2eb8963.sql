CREATE TABLE public.exercise_videos (
  exercise_name TEXT PRIMARY KEY,
  source TEXT NOT NULL CHECK (source IN ('youtube','vimeo')),
  video_id TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by UUID
);

GRANT SELECT ON public.exercise_videos TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.exercise_videos TO authenticated;
GRANT ALL ON public.exercise_videos TO service_role;

ALTER TABLE public.exercise_videos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone signed in can read videos"
ON public.exercise_videos FOR SELECT
TO authenticated USING (true);

CREATE POLICY "Admins insert videos"
ON public.exercise_videos FOR INSERT
TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update videos"
ON public.exercise_videos FOR UPDATE
TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins delete videos"
ON public.exercise_videos FOR DELETE
TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER trg_exercise_videos_updated
BEFORE UPDATE ON public.exercise_videos
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();