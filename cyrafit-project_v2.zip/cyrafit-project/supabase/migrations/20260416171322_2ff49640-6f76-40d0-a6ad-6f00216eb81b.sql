-- Create profile table if it doesn't exist (referenced in AuthContext)
CREATE TABLE IF NOT EXISTS public.profile (
  id UUID NOT NULL PRIMARY KEY,
  email TEXT,
  name TEXT,
  birth_date DATE,
  is_premium BOOLEAN NOT NULL DEFAULT false,
  premium_source TEXT,
  premium_expires_at TIMESTAMPTZ,
  premium_updated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Add premium columns if profile already exists without them
ALTER TABLE public.profile ADD COLUMN IF NOT EXISTS is_premium BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE public.profile ADD COLUMN IF NOT EXISTS premium_source TEXT;
ALTER TABLE public.profile ADD COLUMN IF NOT EXISTS premium_expires_at TIMESTAMPTZ;
ALTER TABLE public.profile ADD COLUMN IF NOT EXISTS premium_updated_at TIMESTAMPTZ;

-- Enable RLS
ALTER TABLE public.profile ENABLE ROW LEVEL SECURITY;

-- Drop and recreate policies idempotently
DROP POLICY IF EXISTS "Users can read own profile" ON public.profile;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profile;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profile;

CREATE POLICY "Users can read own profile"
  ON public.profile FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profile FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profile FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- IMPORTANT: Users cannot directly update is_premium via app (only via secure function below)
-- This prevents privilege escalation attacks where a user could set is_premium = true.
-- Recreate UPDATE policy to exclude premium fields:
DROP POLICY IF EXISTS "Users can update own profile" ON public.profile;
CREATE POLICY "Users can update own profile non-premium fields"
  ON public.profile FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND is_premium = (SELECT is_premium FROM public.profile WHERE id = auth.uid())
    AND premium_source IS NOT DISTINCT FROM (SELECT premium_source FROM public.profile WHERE id = auth.uid())
    AND premium_expires_at IS NOT DISTINCT FROM (SELECT premium_expires_at FROM public.profile WHERE id = auth.uid())
  );

-- Create subscriptions table (audit log of all subscription events)
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  provider TEXT NOT NULL DEFAULT 'google_play',
  product_id TEXT,
  purchase_token TEXT,
  status TEXT NOT NULL DEFAULT 'inactive',
  started_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  is_test BOOLEAN NOT NULL DEFAULT false,
  raw_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can read own subscriptions" ON public.subscriptions;
CREATE POLICY "Users can read own subscriptions"
  ON public.subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Only service role / SECURITY DEFINER functions can insert/update subscriptions.

-- Secure function to set premium status (used by test mode + future Google Play webhook)
CREATE OR REPLACE FUNCTION public.set_premium_status(
  _user_id UUID,
  _is_premium BOOLEAN,
  _source TEXT DEFAULT 'test',
  _expires_at TIMESTAMPTZ DEFAULT NULL,
  _product_id TEXT DEFAULT NULL,
  _purchase_token TEXT DEFAULT NULL,
  _is_test BOOLEAN DEFAULT true
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only allow user to toggle their own status (test mode) OR service role
  IF auth.uid() IS DISTINCT FROM _user_id AND auth.role() <> 'service_role' THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  -- For test mode, only allow source = 'test'
  IF auth.uid() = _user_id AND _source <> 'test' THEN
    RAISE EXCEPTION 'Users can only set test premium';
  END IF;

  UPDATE public.profile
  SET is_premium = _is_premium,
      premium_source = _source,
      premium_expires_at = _expires_at,
      premium_updated_at = now()
  WHERE id = _user_id;

  INSERT INTO public.subscriptions (
    user_id, provider, product_id, purchase_token, status, started_at, expires_at, is_test
  )
  VALUES (
    _user_id,
    CASE WHEN _source = 'test' THEN 'test' ELSE 'google_play' END,
    _product_id,
    _purchase_token,
    CASE WHEN _is_premium THEN 'active' ELSE 'inactive' END,
    CASE WHEN _is_premium THEN now() ELSE NULL END,
    _expires_at,
    _is_test
  );

  RETURN true;
END;
$$;

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS update_profile_updated_at ON public.profile;
CREATE TRIGGER update_profile_updated_at
  BEFORE UPDATE ON public.profile
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_subscriptions_updated_at ON public.subscriptions;
CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();