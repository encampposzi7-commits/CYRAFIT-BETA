
-- ============ POSTS: nuevas columnas ============
ALTER TABLE public.community_posts
  ADD COLUMN IF NOT EXISTS image_url TEXT,
  ADD COLUMN IF NOT EXISTS excerpt TEXT;

-- ============ COMMENTS ============
CREATE TABLE public.community_comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  parent_id UUID REFERENCES public.community_comments(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  image_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_comments TO authenticated;
GRANT ALL ON public.community_comments TO service_role;

ALTER TABLE public.community_comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read comments"
ON public.community_comments FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users insert own comment"
ON public.community_comments FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own comment"
ON public.community_comments FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own comment or admin"
ON public.community_comments FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_community_comments_updated_at
BEFORE UPDATE ON public.community_comments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_community_comments_post ON public.community_comments (post_id, created_at);

-- ============ NOTIFICATIONS ============
CREATE TABLE public.community_notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('new_post','new_comment','comment_reply')),
  post_id UUID REFERENCES public.community_posts(id) ON DELETE CASCADE,
  comment_id UUID REFERENCES public.community_comments(id) ON DELETE CASCADE,
  actor_id UUID,
  title TEXT NOT NULL,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.community_notifications TO authenticated;
GRANT ALL ON public.community_notifications TO service_role;

ALTER TABLE public.community_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own notifications"
ON public.community_notifications FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users update own notifications"
ON public.community_notifications FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own notifications"
ON public.community_notifications FOR DELETE TO authenticated
USING (auth.uid() = user_id);

-- (insert is done by SECURITY DEFINER triggers; no explicit insert policy)

CREATE INDEX idx_community_notifications_user
  ON public.community_notifications (user_id, read, created_at DESC);

-- ============ ADMIN SETTINGS (singleton row) ============
CREATE TABLE public.admin_settings (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  instagram_url TEXT,
  youtube_url TEXT,
  tiktok_url TEXT,
  website_url TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO public.admin_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

GRANT SELECT ON public.admin_settings TO authenticated;
GRANT UPDATE ON public.admin_settings TO authenticated;
GRANT ALL ON public.admin_settings TO service_role;

ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read settings"
ON public.admin_settings FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins update settings"
ON public.admin_settings FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_admin_settings_updated_at
BEFORE UPDATE ON public.admin_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ STORAGE BUCKET ============
INSERT INTO storage.buckets (id, name, public)
VALUES ('community-media', 'community-media', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Community media public read"
ON storage.objects FOR SELECT
USING (bucket_id = 'community-media');

CREATE POLICY "Authenticated upload community media"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'community-media'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Owners delete own community media"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'community-media'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- ============ NOTIFICATION TRIGGERS ============

-- New post → notify every existing user
CREATE OR REPLACE FUNCTION public.notify_new_post()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.community_notifications (user_id, type, post_id, actor_id, title)
  SELECT p.id, 'new_post', NEW.id, NEW.author_id,
         'Nueva publicación: ' || NEW.title
  FROM public.profile p
  WHERE p.id <> NEW.author_id;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_new_post() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER community_posts_notify_new
AFTER INSERT ON public.community_posts
FOR EACH ROW EXECUTE FUNCTION public.notify_new_post();

-- New comment → notify post author (if not the same user). Reply → also notify parent comment author.
CREATE OR REPLACE FUNCTION public.notify_new_comment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_post_author UUID;
  v_post_title TEXT;
  v_parent_author UUID;
BEGIN
  SELECT author_id, title INTO v_post_author, v_post_title
  FROM public.community_posts WHERE id = NEW.post_id;

  -- Notify post author (typically admin) about any new comment, root or reply
  IF v_post_author IS NOT NULL AND v_post_author <> NEW.user_id THEN
    INSERT INTO public.community_notifications (user_id, type, post_id, comment_id, actor_id, title)
    VALUES (
      v_post_author, 'new_comment', NEW.post_id, NEW.id, NEW.user_id,
      'Nuevo comentario en: ' || COALESCE(v_post_title, '')
    );
  END IF;

  -- If it's a reply, notify the parent comment's author too
  IF NEW.parent_id IS NOT NULL THEN
    SELECT user_id INTO v_parent_author
    FROM public.community_comments WHERE id = NEW.parent_id;

    IF v_parent_author IS NOT NULL
       AND v_parent_author <> NEW.user_id
       AND v_parent_author <> v_post_author THEN
      INSERT INTO public.community_notifications (user_id, type, post_id, comment_id, actor_id, title)
      VALUES (
        v_parent_author, 'comment_reply', NEW.post_id, NEW.id, NEW.user_id,
        'Respondieron a tu comentario'
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_new_comment() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER community_comments_notify_new
AFTER INSERT ON public.community_comments
FOR EACH ROW EXECUTE FUNCTION public.notify_new_comment();
