
-- 1. Función segura para que un admin cambie premium de cualquier usuaria
CREATE OR REPLACE FUNCTION public.admin_set_premium(
  _user_id uuid,
  _is_premium boolean,
  _expires_at timestamptz DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  UPDATE public.profile
  SET is_premium = _is_premium,
      premium_source = 'admin',
      premium_expires_at = _expires_at,
      premium_updated_at = now()
  WHERE id = _user_id;

  INSERT INTO public.subscriptions (
    user_id, provider, status, started_at, expires_at, is_test
  ) VALUES (
    _user_id, 'admin',
    CASE WHEN _is_premium THEN 'active' ELSE 'inactive' END,
    CASE WHEN _is_premium THEN now() ELSE NULL END,
    _expires_at, false
  );

  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_set_premium(uuid, boolean, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_set_premium(uuid, boolean, timestamptz) TO authenticated;

-- 2. Función segura para eliminar usuaria (borra datos y auth.users)
CREATE OR REPLACE FUNCTION public.admin_delete_user(_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  -- No permitir auto-eliminación
  IF _user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;

  DELETE FROM public.subscriptions WHERE user_id = _user_id;
  DELETE FROM public.training_sessions WHERE user_id = _user_id;
  DELETE FROM public.app_sessions WHERE user_id = _user_id;
  DELETE FROM public.symptoms_logs WHERE user_id = _user_id;
  DELETE FROM public.period_logs WHERE user_id = _user_id;
  DELETE FROM public.cycle_settings WHERE user_id = _user_id;
  DELETE FROM public.progress WHERE user_id = _user_id;
  DELETE FROM public.user_roles WHERE user_id = _user_id;
  DELETE FROM public.profile WHERE id = _user_id;
  DELETE FROM auth.users WHERE id = _user_id;

  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_delete_user(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_delete_user(uuid) TO authenticated;
