
CREATE OR REPLACE FUNCTION public.auto_grant_admin()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF LOWER(NEW.email) = 'paula@cyrafit.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$function$;

-- Si la usuaria ya existe en auth.users, otórgale rol admin ahora
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role FROM auth.users
WHERE LOWER(email) = 'paula@cyrafit.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Quita el rol admin del correo antiguo (opcional, mantiene seguridad)
DELETE FROM public.user_roles
WHERE role = 'admin'
  AND user_id IN (SELECT id FROM auth.users WHERE LOWER(email) = 'paulafitnesspt@gmail.com');
