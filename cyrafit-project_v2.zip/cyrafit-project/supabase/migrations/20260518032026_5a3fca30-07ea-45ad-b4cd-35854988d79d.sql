
-- cycle_settings: one row per user
CREATE TABLE public.cycle_settings (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  avg_cycle_length INT NOT NULL DEFAULT 28 CHECK (avg_cycle_length BETWEEN 18 AND 60),
  avg_period_length INT NOT NULL DEFAULT 5 CHECK (avg_period_length BETWEEN 1 AND 15),
  mode TEXT NOT NULL DEFAULT 'cycle' CHECK (mode IN ('cycle','postpartum')),
  postpartum_start_date DATE,
  track_period_postpartum BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.cycle_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own cycle_settings" ON public.cycle_settings
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own cycle_settings" ON public.cycle_settings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own cycle_settings" ON public.cycle_settings
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own cycle_settings" ON public.cycle_settings
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TRIGGER cycle_settings_updated_at
  BEFORE UPDATE ON public.cycle_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- period_logs
CREATE TABLE public.period_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE,
  flow TEXT CHECK (flow IN ('light','medium','heavy')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX period_logs_user_date_idx ON public.period_logs(user_id, start_date DESC);

ALTER TABLE public.period_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own period_logs" ON public.period_logs
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own period_logs" ON public.period_logs
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own period_logs" ON public.period_logs
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own period_logs" ON public.period_logs
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- symptoms_logs (prepared for phase 3)
CREATE TABLE public.symptoms_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  type TEXT NOT NULL,
  value JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX symptoms_logs_user_date_idx ON public.symptoms_logs(user_id, date DESC);

ALTER TABLE public.symptoms_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own symptoms_logs" ON public.symptoms_logs
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own symptoms_logs" ON public.symptoms_logs
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own symptoms_logs" ON public.symptoms_logs
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own symptoms_logs" ON public.symptoms_logs
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
